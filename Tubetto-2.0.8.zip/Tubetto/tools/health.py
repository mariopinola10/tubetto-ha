#!/usr/bin/env python3
"""
Salute Tubetto — eseguito da GitHub Actions ogni 6 ore (workflow health.yml).

1. Legge le versioni aggiornate dei client InnerTube da yt-dlp (che segue YouTube da vicino).
2. Prova davvero ricerca, YouTube Music, classifiche, radio e riproduzione con la configurazione
   attuale e con quella candidata; pubblica la candidata solo se non funziona peggio.
3. Riordina i client del player mettendo per primi quelli che funzionano.
4. Scrive config/tubetto-config.json (letto dall'app ogni 3 ore) e config/tubetto-status.json
   (stato mostrato nell'app in "Stato servizio" e negli avvisi).

Solo libreria standard di Python.
"""
import copy
import datetime as dt
import glob
import json
import os
import re
import sys
import urllib.error
import urllib.request
import zipfile

CFG = "config/tubetto-config.json"
STATUS = "config/tubetto-status.json"
YTDLP_BASE = "https://raw.githubusercontent.com/yt-dlp/yt-dlp/master/yt_dlp/extractor/youtube/_base.py"
YT = "https://www.youtube.com"
YTM = "https://music.youtube.com"
WEB_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

# chiave Tubetto -> chiave yt-dlp
YTDLP_KEYS = {"WEB": "web", "WEB_REMIX": "web_music", "IOS": "ios", "ANDROID_VR": "android_vr", "ANDROID": "android"}
# campi del contesto che si possono aggiornare da yt-dlp (ANDROID: mai androidSdkVersion, pretende il PO token)
UPDATABLE_CTX = {"IOS": ["deviceModel", "osVersion"], "ANDROID_VR": ["osVersion"], "ANDROID": [], "WEB": [], "WEB_REMIX": []}

SAMPLE_VIDEOS = ["dQw4w9WgXcQ", "kJQP7kiw5Fk", "JGwWNGJdvx8"]
P_VIDEOS = "EgIQAQ=="
P_SONGS = "EgWKAQIIAWoMEA4QChADEAQQCRAF"

BOT_HINTS = ("bot", "sign in", "accedi", "confirm", "conferma")


def now_iso():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def http(url, data=None, headers=None, timeout=25):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read() if hasattr(e, "read") else b""
    except Exception as e:  # rete
        return 0, str(e).encode()


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def latest_zip():
    zips = glob.glob("Tubetto-*.zip")

    def ver(z):
        m = re.search(r"Tubetto-(\d+)\.(\d+)\.(\d+)\.zip", z)
        return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)

    return max(zips, key=ver) if zips else None


def read_from_zip(name_suffix):
    z = latest_zip()
    if not z:
        return None
    with zipfile.ZipFile(z) as zf:
        for n in zf.namelist():
            if n.endswith(name_suffix):
                return zf.read(n).decode("utf-8")
    return None


# ------------------------------------------------------------------ InnerTube

def innertube(client, endpoint, payload, origin=YT):
    body = dict(payload)
    ctx = {"clientName": client["clientName"], "clientVersion": client["version"], "hl": "it", "gl": "IT"}
    ctx.update(client.get("context", {}))
    body["context"] = {"client": ctx, "user": {"lockedSafetyMode": False}, "request": {"useSsl": True}}
    headers = {
        "Content-Type": "application/json",
        "User-Agent": client.get("userAgent") or WEB_UA,
        "X-YouTube-Client-Name": str(client["nameId"]),
        "X-YouTube-Client-Version": client["version"],
        "Accept-Language": "it-IT,it;q=0.9",
    }
    if client["clientName"].startswith("WEB"):
        headers["Origin"] = origin
        headers["Referer"] = origin + "/"
    st, raw = http(f"{origin}/youtubei/v1/{endpoint}?prettyPrint=false", json.dumps(body).encode(), headers)
    if st != 200:
        raise RuntimeError(f"HTTP {st}")
    return raw.decode("utf-8", "replace")


def count(text, needle):
    return text.count(needle)


def check(name, fn, critical=False):
    try:
        ok, detail = fn()
        state = "ok" if ok else "fail"
    except Exception as e:
        detail = str(e)[:200]
        # HTTP 0 = il server di GitHub non raggiunge YouTube: non dice nulla sul servizio
        # HTTP 0 = GitHub non raggiunge YouTube; HTTP 403 sulle API = IP di GitHub bloccato.
        # In entrambi i casi non dice nulla su come va a casa: non verificabile.
        state = "inconclusive" if detail.startswith("HTTP 0") or detail.startswith("HTTP 403") else "fail"
    return {"name": name, "state": state, "ok": state == "ok", "detail": detail, "critical": critical}


def api_checks(cfg):
    c = cfg["clients"]
    web, remix = c["WEB"], c["WEB_REMIX"]

    def search_web():
        t = innertube(web, "search", {"query": "vasco rossi", "params": P_VIDEOS})
        n = count(t, '"videoRenderer"') + count(t, '"lockupViewModel"')
        return n >= 3, f"{n} risultati"

    def search_music():
        t = innertube(remix, "search", {"query": "vasco rossi", "params": P_SONGS}, YTM)
        n = count(t, '"musicResponsiveListItemRenderer"')
        return n >= 3, f"{n} brani"

    def charts():
        t = innertube(remix, "browse", {"browseId": "FEmusic_charts", "formData": {"selectedValues": ["IT"]}}, YTM)
        n = count(t, '"musicResponsiveListItemRenderer"') + count(t, '"musicTwoRowItemRenderer"')
        return n >= 5, f"{n} elementi"

    def news():
        t = innertube(remix, "browse", {"browseId": "FEmusic_new_releases"}, YTM)
        n = len(set(re.findall(r'"browseId":"(MPRE[^"]+)"', t)))
        return n >= 3, f"{n} uscite"

    def radio():
        t = innertube(remix, "next", {"videoId": SAMPLE_VIDEOS[0], "playlistId": "RDAMVM" + SAMPLE_VIDEOS[0], "isAudioOnly": True}, YTM)
        n = count(t, '"playlistPanelVideoRenderer"')
        return n >= 3, f"{n} brani simili"

    return [
        check("Ricerca video (WEB)", search_web, critical=True),
        check("Ricerca brani YouTube Music", search_music, critical=True),
        check("Classifiche Italia", charts),
        check("Nuove uscite", news),
        check("Radio / brani simili", radio),
    ]


def player_score(client):
    """@return (punti 0..3, stato, dettaglio). stato = ok | fail | inconclusive (IP del datacenter bloccato)."""
    ok = 0
    bot = 0
    last = ""
    for vid in SAMPLE_VIDEOS:
        try:
            t = innertube(client, "player", {"videoId": vid, "contentCheckOk": True, "racyCheckOk": True})
            j = json.loads(t)
        except Exception as e:
            last = str(e)[:120]
            if last.startswith("HTTP 0") or last.startswith("HTTP 403"):
                bot += 1
            continue
        ps = j.get("playabilityStatus", {})
        status = ps.get("status")
        if status != "OK":
            reason = (ps.get("reason") or "") + " " + json.dumps(ps.get("errorScreen", ""))[:300]
            if status == "LOGIN_REQUIRED" or any(h in reason.lower() for h in BOT_HINTS):
                bot += 1
            last = f"{status}: {ps.get('reason', '')}"[:120]
            continue
        sd = j.get("streamingData", {})
        fmts = sd.get("adaptiveFormats", [])
        audio = [f for f in fmts if f.get("mimeType", "").startswith("audio/") and f.get("url")]
        # prima i link solo-audio, poi lo stream unico audio+video (es. itag 18) che l'app usa come riserva
        muxed = [f for f in sd.get("formats", []) if f.get("url")]
        candidates = audio[:1] + muxed[:1]
        if not candidates:
            last = "solo URL cifrati" if fmts else "nessun formato"
            continue
        played = False
        for f0 in candidates:
            # inizio, metà e fine: alcuni client danno solo i primi byte e poi 403
            clen = int(f0.get("contentLength") or 0)
            points = sorted({0, clen // 2, max(0, clen - 4096)}) if clen else [0]
            bad = 0
            for at in points:
                st, _ = http(f0["url"] + f"&range={at}-{at + 2047}", headers={"User-Agent": client.get("userAgent") or WEB_UA}, timeout=20)
                if st not in (200, 206):
                    bad = st
                    break
            if not bad:
                played = True
                break
            last = f"stream HTTP {bad}"
        if played:
            ok += 1
    if ok >= 2:
        return ok, "ok", f"{ok}/3 brani riproducibili"
    # nessun brano ok e almeno un blocco "bot"/403 dall'IP di GitHub: non dice nulla su casa
    if bot >= 1 and ok == 0:
        return 0, "inconclusive", "IP di GitHub bloccato da YouTube (sul telefono può funzionare)"
    return ok, "fail", last or "non riproducibile"


# ------------------------------------------------------------------ yt-dlp

def ytdlp_candidates(cfg):
    st, raw = http(YTDLP_BASE)
    if st != 200:
        return None, f"yt-dlp non raggiungibile (HTTP {st})"
    src = raw.decode("utf-8", "replace")
    cand = copy.deepcopy(cfg)
    changes = []
    for key, ykey in YTDLP_KEYS.items():
        m = re.search(r"^    '" + re.escape(ykey) + r"': \{", src, re.M)
        if not m:
            continue
        nxt = re.search(r"^    '[a-z0-9_]+': \{", src[m.end():], re.M)
        block = src[m.start(): m.end() + (nxt.start() if nxt else 3000)]

        def field(name):
            f = re.search(r"'" + name + r"': '([^']+)'", block)
            return f.group(1) if f else None

        c = cand["clients"].get(key)
        if not c:
            continue
        ver = field("clientVersion")
        if ver and ver != c["version"]:
            changes.append(f"{key} {c['version']} → {ver}")
            c["version"] = ver
        ua = field("userAgent")
        if ua and not key.startswith("WEB"):
            if key == "ANDROID":
                # stesso formato ma senza cambiare la versione di Android dichiarata
                ua = re.sub(r"youtube/[\d.]+", "youtube/" + c["version"], c["userAgent"])
            c["userAgent"] = ua
        for k in UPDATABLE_CTX.get(key, []):
            v = field(k)
            if v:
                c.setdefault("context", {})[k] = v
    return cand, (", ".join(changes) if changes else "nessuna versione nuova")


# ------------------------------------------------------------------ NewPipeExtractor

def newpipe_info():
    gradle = read_from_zip("app/build.gradle.kts") or ""
    m = re.search(r"NewPipeExtractor:(v?[\w.\-]+)\"", gradle)
    current = m.group(1) if m else ""
    headers = {"Accept": "application/vnd.github+json"}
    tok = os.environ.get("GITHUB_TOKEN")
    if tok:
        headers["Authorization"] = "Bearer " + tok
    st, raw = http("https://api.github.com/repos/TeamNewPipe/NewPipeExtractor/releases/latest", headers=headers)
    latest = json.loads(raw).get("tag_name", "") if st == 200 else ""
    return {"current": current, "latest": latest}


# ------------------------------------------------------------------ main

def main():
    os.makedirs("config", exist_ok=True)
    cfg = load_json(CFG)
    if not cfg:
        initial = read_from_zip("config/tubetto-config.json")
        cfg = json.loads(initial) if initial else None
    if not cfg or "clients" not in cfg:
        print("::error::Configurazione iniziale non trovata (config/tubetto-config.json nello zip)")
        sys.exit(1)
    prev = load_json(STATUS, {}) or {}

    # 1) candidata da yt-dlp
    cand, cand_note = ytdlp_candidates(cfg)
    print("yt-dlp:", cand_note)

    # 2) client del player: attuale vs candidato, per ognuno
    new_cfg = copy.deepcopy(cfg)
    player_results = {}
    for key in ["IOS", "ANDROID_VR", "ANDROID"]:
        cur = cfg["clients"][key]
        s_cur = player_score(cur)
        chosen, res = cur, s_cur
        if cand and cand["clients"][key] != cur:
            s_new = player_score(cand["clients"][key])
            print(f"{key}: attuale {s_cur} | candidato {s_new}")
            if s_new[0] > s_cur[0] or (s_new[0] == s_cur[0] and s_new[1] != "fail"):
                chosen, res = cand["clients"][key], s_new
        else:
            print(f"{key}: {s_cur}")
        new_cfg["clients"][key] = chosen
        player_results[key] = res

    # 3) client web: la candidata vince se le ricerche vanno almeno come prima
    base_checks = api_checks(new_cfg)
    if cand:
        trial = copy.deepcopy(new_cfg)
        trial["clients"]["WEB"] = cand["clients"]["WEB"]
        trial["clients"]["WEB_REMIX"] = cand["clients"]["WEB_REMIX"]
        if trial["clients"] != new_cfg["clients"]:
            trial_checks = api_checks(trial)
            n_trial = sum(c["ok"] for c in trial_checks)
            if n_trial > 0 and n_trial >= sum(c["ok"] for c in base_checks):
                new_cfg, base_checks = trial, trial_checks

    # rete di GitHub giù: nessuna modifica alla configurazione
    if all(c["state"] == "inconclusive" for c in base_checks):
        new_cfg = copy.deepcopy(cfg)

    # 4) ordine del player: prima chi funziona davvero
    conclusive = [k for k, r in player_results.items() if r[1] != "inconclusive"]
    if conclusive:
        old_order = cfg.get("playerOrder", ["IOS", "ANDROID_VR", "ANDROID"])
        rank = {"ok": 0, "inconclusive": 1, "fail": 2}
        new_cfg["playerOrder"] = sorted(old_order, key=lambda k: (rank[player_results[k][1]], -player_results[k][0], old_order.index(k)))

    # 5) stato
    checks = list(base_checks)
    for key in ["IOS", "ANDROID_VR", "ANDROID"]:
        pts, state, detail = player_results[key]
        checks.append({"name": f"Riproduzione client {key}", "state": state, "ok": state == "ok", "detail": detail, "critical": False})

    critical_fail = [c["name"] for c in checks if c["critical"] and c["state"] == "fail"]
    players = [r[1] for r in player_results.values()]
    if players and all(s == "fail" for s in players):
        critical_fail.append("Riproduzione (tutti i client)")
    any_fail = any(c["state"] == "fail" for c in checks)

    fails = (prev.get("criticalRuns", 0) + 1) if critical_fail else 0
    if critical_fail and fails >= 2:
        overall = "broken"
    elif critical_fail or any_fail:
        overall = "degraded"
    else:
        overall = "ok"

    if all(c["state"] == "inconclusive" for c in checks):
        overall, fails = prev.get("overall", "ok"), prev.get("criticalRuns", 0)

    since = prev.get("since") if prev.get("overall") == overall and prev.get("since") else now_iso()
    if all(c["state"] == "inconclusive" for c in checks):
        message = "Controllo non riuscito: il server di GitHub non ha raggiunto YouTube. Riprovo al prossimo giro."
    elif overall == "broken":
        message = ("Non funziona da almeno 2 controlli di fila: " + ", ".join(critical_fail) +
                   ". L'app usa i metodi di riserva (NewPipeExtractor) finché non arriva una correzione.")
    elif overall == "degraded":
        message = "Qualche metodo non risponde, gli altri lo sostituiscono."
    else:
        message = "Ricerca, YouTube Music e riproduzione funzionano."

    cfg_changed = json.dumps(new_cfg.get("clients"), sort_keys=True) != json.dumps(cfg.get("clients"), sort_keys=True) \
        or new_cfg.get("playerOrder") != cfg.get("playerOrder")
    adopted = [f"{k} {cfg['clients'][k]['version']} → {new_cfg['clients'][k]['version']}"
               for k in new_cfg["clients"] if new_cfg["clients"][k].get("version") != cfg["clients"].get(k, {}).get("version")]
    if cfg_changed:
        new_cfg["updated"] = now_iso()
        new_cfg["source"] = "aggiornata e testata da Salute Tubetto: " + (", ".join(adopted) or "nuovo ordine dei client")
        cand_note = ", ".join(adopted) or "nuovo ordine dei client"
        with open(CFG, "w", encoding="utf-8") as f:
            json.dump(new_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        print("Configurazione aggiornata:", cand_note)
    elif not os.path.exists(CFG):
        with open(CFG, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")

    status = {
        "checked": now_iso(),
        "overall": overall,
        "since": since,
        "criticalRuns": fails,
        "message": message,
        "configUpdated": new_cfg.get("updated", ""),
        "ytdlp": cand_note,
        "playerOrder": new_cfg.get("playerOrder", []),
        "checks": checks,
        "newpipe": newpipe_info(),
    }
    with open(STATUS, "w", encoding="utf-8") as f:
        json.dump(status, f, indent=2, ensure_ascii=False)
        f.write("\n")

    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        icon = {"ok": "✅", "degraded": "🟡", "broken": "🔴"}[overall]
        with open(summary, "a", encoding="utf-8") as f:
            f.write(f"## {icon} Tubetto: {overall}\n\n{message}\n\n")
            for c in checks:
                ic = {"ok": "✅", "fail": "❌", "inconclusive": "⚪"}[c["state"]]
                f.write(f"- {ic} {c['name']} — {c['detail']}\n")
            f.write(f"\nyt-dlp: {cand_note}\n")
    print(json.dumps(status, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
