package it.gerry.tubetto.playback

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter

/**
 * Buffer più ampio della configurazione standard di ExoPlayer (che tiene ~50 s):
 * fino a 2 minuti avanti e 30 s indietro, così cali di rete brevi (galleria, cambio cella
 * in auto, Wi-Fi debole) non fermano audio e video. Il brano successivo della coda viene
 * caricato in anticipo quando l'attuale è già tutto in memoria.
 */
@OptIn(UnstableApi::class)
object Buffering {

    /**
     * Su Fire TV partenza e ripresa aspettano un po' più di dati (3 s / 8 s) e la riserva è più ampia:
     * meglio un secondo in più all'avvio che micro-scatti e riavvii a raffica dell'audio.
     */
    fun loadControl(tv: Boolean = false): LoadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            /* minBufferMs = */ if (tv) 45_000 else 30_000,
            /* maxBufferMs = */ if (tv) 150_000 else 120_000,
            /* bufferForPlaybackMs = */ if (tv) 3_000 else 1_500,
            /* bufferForPlaybackAfterRebufferMs = */ if (tv) 8_000 else 4_000,
        )
        .setBackBuffer(30_000, true)
        .setPrioritizeTimeOverSizeThresholds(true)
        .build()

    /**
     * Stima di banda iniziale prudente (1,5 Mbit/s): i video partono subito in qualità
     * medio-bassa e poi ExoPlayer sale da solo appena misura la rete reale.
     */
    fun bandwidthMeter(context: Context): DefaultBandwidthMeter =
        DefaultBandwidthMeter.Builder(context)
            .setInitialBitrateEstimate(1_500_000L)
            .build()

    /** Qualità video massima in base alla rete: piena su Wi-Fi, 720p su dati mobili. */
    fun maxVideoHeight(context: Context): Int {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return 1080
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return 720
        val unmetered = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
        return if (unmetered) 1080 else 720
    }
}
