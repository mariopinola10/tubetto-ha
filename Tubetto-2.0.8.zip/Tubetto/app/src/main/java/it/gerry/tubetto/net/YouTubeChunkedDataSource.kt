package it.gerry.tubetto.net

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import java.io.IOException

/**
 * Scarica gli stream googlevideo a blocchi con il parametro &range=start-end
 * (come fanno i client ufficiali e NewPipe). Una singola richiesta aperta fino
 * alla fine del file viene rallentata o interrotta da YouTube.
 */
@OptIn(UnstableApi::class)
class YouTubeChunkedDataSource(private val upstream: HttpDataSource) : BaseDataSource(true) {

    class Factory(private val upstream: HttpDataSource.Factory) : DataSource.Factory {
        override fun createDataSource(): DataSource = YouTubeChunkedDataSource(upstream.createDataSource())
    }

    private var spec: DataSpec? = null
    private var passthrough = false
    private var opened = false
    private var position = 0L
    private var end = 0L
    private var chunkRemaining = 0L

    override fun open(dataSpec: DataSpec): Long {
        spec = dataSpec
        transferInitializing(dataSpec)
        val total = dataSpec.uri.getQueryParameter("clen")?.toLongOrNull()
        val isYt = dataSpec.uri.host?.endsWith("googlevideo.com") == true &&
            dataSpec.uri.path?.contains("videoplayback") == true && total != null

        val result: Long
        if (!isYt) {
            passthrough = true
            result = upstream.open(dataSpec)
        } else {
            passthrough = false
            position = dataSpec.position
            end = if (dataSpec.length != C.LENGTH_UNSET.toLong()) position + dataSpec.length else total!!
            if (position >= end) throw IOException("Posizione oltre la fine dello stream")
            openChunk()
            result = end - position
        }
        opened = true
        transferStarted(dataSpec)
        return result
    }

    private fun openChunk() {
        val s = spec!!
        val chunkEnd = minOf(position + CHUNK_SIZE, end) - 1
        val uri = withRange(s.uri, "$position-$chunkEnd")
        upstream.open(
            DataSpec.Builder()
                .setUri(uri)
                .setHttpRequestHeaders(s.httpRequestHeaders)
                .build()
        )
        chunkRemaining = chunkEnd - position + 1
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (passthrough) {
            val n = upstream.read(buffer, offset, length)
            if (n > 0) bytesTransferred(n)
            return n
        }
        if (position >= end) return C.RESULT_END_OF_INPUT
        if (chunkRemaining <= 0) {
            upstream.close()
            openChunk()
        }
        var n = upstream.read(buffer, offset, minOf(length.toLong(), chunkRemaining).toInt())
        if (n == C.RESULT_END_OF_INPUT) {
            // Blocco chiuso in anticipo dal server: riapri dalla posizione corrente
            upstream.close()
            openChunk()
            n = upstream.read(buffer, offset, minOf(length.toLong(), chunkRemaining).toInt())
            if (n == C.RESULT_END_OF_INPUT) throw IOException("Stream interrotto a $position/$end")
        }
        position += n
        chunkRemaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = upstream.uri

    override fun getResponseHeaders(): Map<String, List<String>> = upstream.responseHeaders

    override fun close() {
        try {
            upstream.close()
        } finally {
            if (opened) {
                opened = false
                transferEnded()
            }
            spec = null
        }
    }

    companion object {
        private const val CHUNK_SIZE = 10L * 1024 * 1024 // 10 MB

        private fun withRange(uri: Uri, range: String): Uri {
            val b = uri.buildUpon().clearQuery()
            for (name in uri.queryParameterNames) {
                if (name == "range") continue
                for (v in uri.getQueryParameters(name)) b.appendQueryParameter(name, v)
            }
            return b.appendQueryParameter("range", range).build()
        }
    }
}
