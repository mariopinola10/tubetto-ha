package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Profilo dell'utente su questo dispositivo: nome e generi preferiti scelti al primo avvio.
 * Gli artisti scelti finiscono tra gli "Artisti che segui" della libreria.
 */
object UserProfile {

    private lateinit var sp: SharedPreferences

    /** Generi proposti al primo avvio, con la ricerca usata per trovarne i brani. */
    val GENRES: List<Pair<String, String>> = listOf(
        "Pop italiano" to "pop italiano successi",
        "Rap italiano" to "rap italiano hit",
        "Musica napoletana" to "musica napoletana",
        "Cantautori" to "cantautori italiani",
        "Rock" to "rock classici",
        "Pop internazionale" to "pop hits",
        "Dance / Elettronica" to "dance hits",
        "Anni 80" to "hit anni 80",
        "Anni 90" to "hit anni 90",
        "R&B / Soul" to "rnb soul hits",
        "Latino / Reggaeton" to "reggaeton hits",
        "Indie" to "indie italiano",
        "Jazz" to "jazz classics",
        "Classica" to "musica classica famosa",
        "Relax / Lo-fi" to "lofi relax",
    )

    /** Artisti proposti al primo avvio. */
    val ARTISTS: List<String> = listOf(
        "Pino Daniele", "Geolier", "Vasco Rossi", "Jovanotti", "Ultimo", "Annalisa", "Elodie", "Mahmood",
        "Marco Mengoni", "Laura Pausini", "Tiziano Ferro", "Eros Ramazzotti", "Lucio Dalla", "Lucio Battisti",
        "Sfera Ebbasta", "Lazza", "Tananai", "Blanco", "Måneskin", "Rocco Hunt", "Liberato", "Gigi D'Alessio",
        "Coldplay", "Ed Sheeran", "Dua Lipa", "The Weeknd", "Taylor Swift", "Michael Jackson", "Queen", "Bruno Mars",
    )

    fun init(context: Context) {
        sp = context.applicationContext.getSharedPreferences("profile", Context.MODE_PRIVATE)
    }

    var name: String
        get() = sp.getString("name", "").orEmpty()
        set(v) = sp.edit().putString("name", v.trim()).apply()

    var genres: List<String>
        get() = sp.getString("genres", "").orEmpty().split("|").filter { it.isNotBlank() }
        set(v) = sp.edit().putString("genres", v.joinToString("|")).apply()

    var onboardingDone: Boolean
        get() = sp.getBoolean("onboarding", false)
        set(v) = sp.edit().putBoolean("onboarding", v).apply()

    /** Fire TV: la musica parte senza video (meno carico, niente salti audio); il video si apre a richiesta. */
    var tvMusicAudioOnly: Boolean
        get() = sp.getBoolean("tvAudio", true)
        set(v) = sp.edit().putBoolean("tvAudio", v).apply()

    /** Ricerche per i generi scelti (per "Per te" quando non c'è ancora cronologia). */
    fun genreQueries(): List<String> = genres.mapNotNull { g -> GENRES.firstOrNull { it.first == g }?.second }

    fun greeting(): String {
        val n = name.ifBlank { return "Buona musica 🎧" }
        return "Ciao $n 🎧"
    }
}
