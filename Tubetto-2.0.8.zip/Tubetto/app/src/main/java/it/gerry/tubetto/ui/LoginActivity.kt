package it.gerry.tubetto.ui

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.data.Account

/**
 * Pagina di accesso di Google dentro l'app. Quando l'accesso arriva su youtube.com
 * si salvano i cookie della sessione e la pagina si chiude. Password e codici restano
 * tra l'utente e Google: l'app non li vede.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var done = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1720"))
            fitsSystemWindows = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt())
        }
        bar.addView(TextView(this).apply {
            text = "Accedi a YouTube (meglio un account secondario)"
            setTextColor(Color.WHITE)
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        bar.addView(Button(this).apply {
            text = "Annulla"
            setOnClickListener { finish() }
        })
        root.addView(bar)

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)
        cm.removeAllCookies(null)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // Google blocca le WebView "dichiarate": ci presentiamo come Chrome
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                checkLogin(url)
            }
        }
        web.loadUrl(
            "https://accounts.google.com/ServiceLogin?service=youtube&passive=true&continue=" +
                android.net.Uri.encode("https://www.youtube.com/signin?action_handle_signin=true&next=https%3A%2F%2Fwww.youtube.com%2F")
        )
    }

    private fun checkLogin(url: String) {
        if (done) return
        val host = android.net.Uri.parse(url).host.orEmpty()
        if (!host.endsWith("youtube.com")) return
        CookieManager.getInstance().flush()
        val cookies = CookieManager.getInstance().getCookie("https://www.youtube.com").orEmpty()
        if ("SAPISID=" in cookies || "__Secure-3PAPISID=" in cookies) {
            done = true
            Account.save(cookies)
            Diagnostics.log("Accesso all'account YouTube eseguito")
            setResult(RESULT_OK)
            finish()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
