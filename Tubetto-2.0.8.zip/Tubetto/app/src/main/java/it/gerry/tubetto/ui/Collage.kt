package it.gerry.tubetto.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.util.LruCache
import android.widget.ImageView
import androidx.core.graphics.drawable.toBitmap
import coil.imageLoader
import coil.dispose
import coil.load
import coil.request.ImageRequest
import coil.request.SuccessResult
import it.gerry.tubetto.R
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.Library
import it.gerry.tubetto.data.ListenHistory
import it.gerry.tubetto.data.VideoItem
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch

/**
 * Copertine "a mosaico" come Spotify: per playlist, preferiti e mix senza un'immagine propria
 * si compone una griglia 2×2 con le copertine dei primi brani (1–3 brani: la copertina del primo).
 */
object Collage {

    private val cache = LruCache<String, Bitmap>(48)
    private val scope = MainScope()
    private const val SIZE = 360

    /** Copertine dei brani contenuti, oppure null se l'elemento ha già una sua immagine. */
    fun urlsFor(v: VideoItem): List<String>? {
        val songs: List<VideoItem> = when {
            v.id == ShelfAdapter.TILE_FAV -> Library.favorites().filter { it.kind == ItemKind.VIDEO }
            v.id == ShelfAdapter.TILE_MIX -> {
                val fav = Library.favorites().filter { it.kind == ItemKind.VIDEO }
                val top = ListenHistory.all().filter { it.music }.sortedByDescending { it.count }.map { it.toVideoItem() }
                // alterna preferiti e più ascoltati
                val out = mutableListOf<VideoItem>()
                for (i in 0 until 4) {
                    fav.getOrNull(i)?.let { out += it }
                    top.getOrNull(i)?.let { out += it }
                }
                out
            }
            v.id.startsWith(Library.LOCAL_PREFIX) -> Library.playlist(v.id.removePrefix(Library.LOCAL_PREFIX))
            else -> return null
        }
        return songs.map { coverOf(it) }.distinct().take(4)
    }

    /** Copertina quadrata: per i video YouTube "mqdefault" (16:9 senza bande nere, poi ritagliata). */
    fun coverOf(v: VideoItem): String {
        val u = v.thumbnailUrl?.ifBlank { null } ?: return "https://i.ytimg.com/vi/${v.id}/mqdefault.jpg"
        return u.replace("/hqdefault.jpg", "/mqdefault.jpg").replace("/sddefault.jpg", "/mqdefault.jpg")
    }

    /**
     * Mette nella [view] il mosaico dell'elemento.
     * @return false se l'elemento non è una raccolta o è vuota (il chiamante usa la sua grafica).
     */
    fun load(view: ImageView, v: VideoItem, placeholder: Drawable): Boolean {
        val urls = urlsFor(v) ?: return false
        if (urls.isEmpty()) return false
        if (urls.size < 4) {
            view.setTag(R.id.collage_key, null)
            view.load(urls.first()) {
                crossfade(true)
                placeholder(placeholder)
                error(placeholder)
            }
            return true
        }
        val key = urls.joinToString("|")
        // la vista può avere ancora in corso il caricamento della copertina di un altro elemento
        // (riciclata scorrendo): va annullato, altrimenti arriva dopo e copre il mosaico
        view.dispose()
        view.setTag(R.id.collage_key, key)
        cache.get(key)?.let {
            view.setImageBitmap(it)
            return true
        }
        view.setImageDrawable(placeholder)
        val ctx = view.context.applicationContext
        scope.launch {
            val parts = urls.map { u ->
                async {
                    val r = ctx.imageLoader.execute(
                        ImageRequest.Builder(ctx).data(u).size(SIZE / 2).allowHardware(false).build()
                    )
                    (r as? SuccessResult)?.drawable?.toBitmap()
                }
            }.awaitAll()
            if (parts.any { it == null }) {
                if (view.getTag(R.id.collage_key) == key) view.load(urls.first())
                return@launch
            }
            val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            val half = SIZE / 2
            parts.forEachIndexed { i, b ->
                val bmp = b ?: return@forEachIndexed
                val side = minOf(bmp.width, bmp.height)
                val src = Rect((bmp.width - side) / 2, (bmp.height - side) / 2, (bmp.width + side) / 2, (bmp.height + side) / 2)
                val x = (i % 2) * half
                val y = (i / 2) * half
                canvas.drawBitmap(bmp, src, Rect(x, y, x + half, y + half), paint)
            }
            cache.put(key, out)
            if (view.getTag(R.id.collage_key) == key) view.setImageBitmap(out)
        }
        return true
    }
}
