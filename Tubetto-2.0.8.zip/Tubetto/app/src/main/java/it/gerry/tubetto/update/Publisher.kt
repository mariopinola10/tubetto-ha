package it.gerry.tubetto.update

import android.content.Context
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

/**
 * Pubblicazione manuale per tutti: la build crea la release solo nel repo privato;
 * dall'app (amministratore) si sceglie quando copiarla nel repo pubblico "tubetto-releases",
 * avviando il workflow publish.yml.
 * Il token deve avere anche il permesso "Actions: Read and write" sul repo privato.
 */
class Publisher(context: Context) {

    data class State(val privateVersion: String?, val privateNotes: String, val publicVersion: String?, val running: Boolean)

    private val prefs = UpdatePrefs(context)

    private fun req(url: String) = Request.Builder().url(url)
        .header("Accept", "application/vnd.github+json")
        .header("X-GitHub-Api-Version", "2022-11-28")

    private fun Request.Builder.auth() = apply { header("Authorization", "Bearer ${prefs.token}") }

    private fun latestOf(repo: String, auth: Boolean): JSONObject? {
        val b = req("https://api.github.com/repos/$repo/releases/latest")
        if (auth) b.auth()
        Http.client.newCall(b.build()).execute().use { r ->
            if (r.code == 404) return null
            if (!r.isSuccessful) throw IOException("GitHub HTTP ${r.code} su $repo")
            return JSONObject(r.body!!.string())
        }
    }

    suspend fun state(): State = withContext(Dispatchers.IO) {
        if (prefs.token.isBlank() || !prefs.isConfigured) throw IOException("Serve il token GitHub (Impostazioni → GitHub)")
        val priv = latestOf(prefs.repo, auth = true)
        val pub = latestOf(UpdatePrefs.PUBLIC_RELEASES, auth = false)
        val running = runCatching {
            Http.client.newCall(
                req("https://api.github.com/repos/${prefs.repo}/actions/workflows/publish.yml/runs?per_page=1").auth().build()
            ).execute().use { r ->
                if (!r.isSuccessful) false
                else {
                    val runs = JSONObject(r.body!!.string()).optJSONArray("workflow_runs")
                    runs != null && runs.length() > 0 && runs.getJSONObject(0).optString("status") != "completed"
                }
            }
        }.getOrDefault(false)
        State(
            privateVersion = priv?.optString("tag_name")?.removePrefix("v"),
            privateNotes = priv?.optString("body").orEmpty(),
            publicVersion = pub?.optString("tag_name")?.removePrefix("v"),
            running = running,
        )
    }

    /** Avvia la pubblicazione della versione indicata. */
    suspend fun publish(version: String, notes: String) = withContext(Dispatchers.IO) {
        val branch = Http.client.newCall(req("https://api.github.com/repos/${prefs.repo}").auth().build()).execute().use { r ->
            if (!r.isSuccessful) throw IOException("GitHub HTTP ${r.code}")
            JSONObject(r.body!!.string()).optString("default_branch", "main")
        }
        val body = JSONObject()
            .put("ref", branch)
            .put("inputs", JSONObject().put("version", version).put("notes", notes))
            .toString().toRequestBody("application/json".toMediaType())
        Http.client.newCall(
            req("https://api.github.com/repos/${prefs.repo}/actions/workflows/publish.yml/dispatches").auth().post(body).build()
        ).execute().use { r ->
            when {
                r.code == 204 -> Unit
                r.code == 403 -> throw IOException("Il token non ha il permesso \"Actions: Read and write\" (HTTP 403)")
                r.code == 404 -> throw IOException("Workflow publish.yml non trovato nel repo (HTTP 404)")
                r.code == 422 -> throw IOException("GitHub ha rifiutato la richiesta (HTTP 422): ${r.body?.string()?.take(200)}")
                else -> throw IOException("GitHub HTTP ${r.code}")
            }
        }
    }
}
