package it.gerry.tubetto.ui

import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.shape.RelativeCornerSize
import com.google.android.material.shape.ShapeAppearanceModel
import it.gerry.tubetto.R
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.VideoItem

/** Una riga orizzontale della home ("I tuoi artisti", "Hit del momento"…). */
data class Shelf(
    val title: String,
    val items: List<VideoItem>,
    val style: Style = Style.SQUARE,
    /** Toccando un brano parte la coda con tutti i brani dello scaffale. */
    val queue: Boolean = true,
) {
    enum class Style { SQUARE, ROUND, WIDE }
}

/** Home a scaffali orizzontali, come Spotify. Funziona col dito e col telecomando. */
class ShelfAdapter(
    private val onClick: (VideoItem, Shelf) -> Unit,
    private val onLongClick: (VideoItem, View) -> Unit,
) : RecyclerView.Adapter<ShelfAdapter.RowHolder>() {

    var tvMode = false

    /** TV: altezza di una riga (px) perché ne stiano sempre due intere sullo schermo. 0 = dimensioni standard. */
    var tvRowHeightPx = 0
    var shelves: List<Shelf> = emptyList()
        private set

    fun submit(list: List<Shelf>) {
        shelves = list
        notifyDataSetChanged()
    }

    class RowHolder(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.shelfTitle)
        val list: RecyclerView = v.findViewById(R.id.shelfList)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val h = RowHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_shelf_row, parent, false))
        h.list.layoutManager = LinearLayoutManager(parent.context, LinearLayoutManager.HORIZONTAL, false)
        h.list.setHasFixedSize(false)
        if (tvMode) {
            // righe compatte: meno spazio tra titolo e copertine
            val d = parent.resources.displayMetrics.density
            h.itemView.setPadding(0, (6 * d).toInt(), 0, 0)
            h.title.setPadding((14 * d).toInt(), 0, (14 * d).toInt(), (4 * d).toInt())
            h.title.textSize = 18f
        }
        return h
    }

    override fun getItemCount() = shelves.size

    override fun onBindViewHolder(h: RowHolder, position: Int) {
        val shelf = shelves[position]
        h.title.text = shelf.title
        h.list.adapter = CardAdapter(shelf)
    }

    private inner class CardAdapter(private val shelf: Shelf) : RecyclerView.Adapter<CardAdapter.CardHolder>() {

        inner class CardHolder(v: View) : RecyclerView.ViewHolder(v) {
            val box: View = v.findViewById(R.id.cardImageBox)
            val image: ShapeableImageView = v.findViewById(R.id.cardImage)
            val badge: TextView = v.findViewById(R.id.cardBadge)
            val title: TextView = v.findViewById(R.id.cardTitle)
            val sub: TextView = v.findViewById(R.id.cardSub)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_shelf_card, parent, false)
            val h = CardHolder(v)
            val base = parent.resources.getDimensionPixelSize(R.dimen.shelf_card)
            val (w, ih) = when (shelf.style) {
                Shelf.Style.WIDE -> (base * 1.6f).toInt() to (base * 1.6f * 9 / 16).toInt()
                else -> base to base
            }
            var cw = w
            var ch = ih
            if (tvMode && tvRowHeightPx > 0) {
                // TV: titolo intero su due righe (niente "…" sui nomi normali), copertina = spazio che resta
                val d = parent.resources.displayMetrics.density
                h.title.maxLines = 2
                h.title.textSize = 15f
                h.sub.textSize = 12f
                val texts = (18f * parent.resources.displayMetrics.scaledDensityCompat() * 1.45f) +
                    h.title.textSize * 2 * 1.3f + h.sub.textSize * 1.4f
                val overhead = (texts + 6 * d + 4 * d + 8 * d + 6 * d + 12 * d).toInt()
                ch = (tvRowHeightPx - overhead).coerceAtLeast((60 * d).toInt())
                cw = if (shelf.style == Shelf.Style.WIDE) ch * 16 / 9
                // copertine quadrate/tonde: card più larga dell'immagine perché il nome ci stia tutto
                else maxOf(ch, (170 * d).toInt())
                val img = h.image.layoutParams as android.widget.FrameLayout.LayoutParams
                img.width = if (shelf.style == Shelf.Style.WIDE) ViewGroup.LayoutParams.MATCH_PARENT else ch
                img.gravity = android.view.Gravity.CENTER_HORIZONTAL
                h.image.layoutParams = img
            }
            v.layoutParams = v.layoutParams.apply { width = cw }
            h.box.layoutParams = h.box.layoutParams.apply { height = ch }
            h.image.shapeAppearanceModel = if (shelf.style == Shelf.Style.ROUND) {
                ShapeAppearanceModel.builder().setAllCornerSizes(RelativeCornerSize(0.5f)).build()
            } else {
                ShapeAppearanceModel.builder().setAllCornerSizes(8f * parent.resources.displayMetrics.density).build()
            }
            if (shelf.style == Shelf.Style.ROUND) {
                h.title.textAlignment = View.TEXT_ALIGNMENT_CENTER
                h.sub.textAlignment = View.TEXT_ALIGNMENT_CENTER
            }
            if (tvMode) {
                v.setOnFocusChangeListener { view, focused ->
                    view.animate().scaleX(if (focused) 1.08f else 1f).scaleY(if (focused) 1.08f else 1f).setDuration(120).start()
                    h.image.isSelected = focused
                }
            }
            return h
        }

        override fun getItemCount() = shelf.items.size

        override fun onBindViewHolder(h: CardHolder, position: Int) {
            val v = shelf.items[position]
            val tile = TILES[v.id]
            if (Collage.load(h.image, v, ColorDrawable(0xFFB8C7D9.toInt()))) {
                // Mosaico delle copertine; per Mix e Preferiti resta il simbolo nell'angolo
                h.badge.text = TILE_SYMBOLS[v.id].orEmpty()
                h.badge.visibility = if (tile != null) View.VISIBLE else View.GONE
            } else if (tile != null) {
                h.image.setTag(R.id.collage_key, null)
                // Riquadri speciali (Il mio mix, Brani che ti piacciono) con colore e simbolo
                h.image.setImageDrawable(
                    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tile.first, tile.second))
                )
                h.badge.text = TILE_SYMBOLS[v.id]
                h.badge.visibility = View.VISIBLE
            } else {
                h.badge.visibility = View.GONE
                h.image.setTag(R.id.collage_key, null)
                val url = v.thumbnailUrl?.ifBlank { null } ?: if (v.kind == ItemKind.VIDEO) v.thumbnail else null
                Placeholder.load(h.image, url, v)
            }
            h.title.text = v.title
            h.sub.text = when (v.kind) {
                ItemKind.ARTIST -> "Artista"
                ItemKind.CHANNEL -> "Canale"
                ItemKind.PLAYLIST -> listOf("Playlist", v.author).filter { it.isNotBlank() }.joinToString(" • ")
                else -> listOf(v.author, v.published).filter { it.isNotBlank() }.joinToString(" • ")
            }
            h.itemView.setOnClickListener { onClick(v, shelf) }
            h.itemView.setOnLongClickListener { onLongClick(v, it); true }
        }
    }

    companion object {
        const val TILE_MIX = "tile:mix"
        const val TILE_FAV = "tile:fav"
        private val TILES = mapOf(
            TILE_MIX to (0xFF7C4DFF.toInt() to 0xFF0A84D0.toInt()),
            TILE_FAV to (0xFF4F46E5.toInt() to 0xFF9DD9F3.toInt()),
        )
        private val TILE_SYMBOLS = mapOf(TILE_MIX to "✨", TILE_FAV to "♥")
    }
}

/** Fattore di scala dei testi (sp → px) senza API deprecate. */
private fun android.util.DisplayMetrics.scaledDensityCompat(): Float =
    android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP, 1f, this)
