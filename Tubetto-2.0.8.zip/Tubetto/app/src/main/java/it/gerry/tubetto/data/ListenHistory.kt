package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Listen(
    val id: String,
    val title: String,
    val author: String,
    val thumb: String,
    val music: Boolean,
    val count: Int,
    val last: Long,
) {
    fun toVideoItem() = VideoItem(id = id, title = title, author = author, duration = "", thumbnailUrl = thumb)
}

/** Cronologia d'ascolto persistente: base per "Per te" e per la Cronologia in Android Auto. */
object ListenHistory {
    private lateinit var sp: SharedPreferences
    private val items = LinkedHashMap<String, Listen>()

    /** Voci cancellate a mano (id → quando): la sincronizzazione non le fa ricomparire. */
    private val removed = HashMap<String, Long>()
    private var clearedAt = 0L

    /** Chiamato quando si registra un ascolto (sincronizzazione differita). */
    @Volatile var onChanged: (() -> Unit)? = null

    fun init(context: Context) {
        sp = context.getSharedPreferences("history", Context.MODE_PRIVATE)
        runCatching {
            val arr = JSONArray(sp.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val l = Listen(
                    o.getString("id"), o.optString("title"), o.optString("author"), o.optString("thumb"),
                    o.optBoolean("music"), o.optInt("count", 1), o.optLong("last"),
                )
                items[l.id] = l
            }
            val r = JSONObject(sp.getString("removed", "{}") ?: "{}")
            r.keys().forEach { k -> removed[k] = r.optLong(k) }
            clearedAt = sp.getLong("clearedAt", 0L)
        }
    }

    @Synchronized
    fun record(id: String, title: String, author: String, thumb: String, music: Boolean) {
        if (id.isBlank() || title.isBlank()) return
        val old = items[id]
        items[id] = Listen(id, title, author, thumb, music || old?.music == true, (old?.count ?: 0) + 1, System.currentTimeMillis())
        if (items.size > 400) {
            items.values.sortedBy { it.last }.take(items.size - 400).forEach { items.remove(it.id) }
        }
        save()
        onChanged?.invoke()
    }

    /** Ultimi ascolti in JSON (per la sincronizzazione). */
    @Synchronized
    fun exportJson(limit: Int = 300): JSONArray = JSONArray().apply {
        items.values.sortedByDescending { it.last }.take(limit).forEach {
            put(
                JSONObject().put("id", it.id).put("title", it.title).put("author", it.author)
                    .put("thumb", it.thumb).put("music", it.music).put("count", it.count).put("last", it.last)
            )
        }
    }

    /** Unisce la cronologia di un altro dispositivo: somma le informazioni, tiene l'ascolto più recente. */
    @Synchronized
    fun mergeJson(arr: JSONArray): Boolean {
        var changed = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isBlank()) continue
            val remote = Listen(
                id, o.optString("title"), o.optString("author"), o.optString("thumb"),
                o.optBoolean("music"), o.optInt("count", 1), o.optLong("last"),
            )
            // cancellato qui dopo l'ultimo ascolto remoto: non va riportato indietro
            if (remote.last <= maxOf(clearedAt, removed[id] ?: 0L)) continue
            val local = items[id]
            val merged = if (local == null) remote else local.copy(
                count = maxOf(local.count, remote.count),
                last = maxOf(local.last, remote.last),
                music = local.music || remote.music,
                title = local.title.ifBlank { remote.title },
                author = local.author.ifBlank { remote.author },
            )
            if (merged != local) {
                items[id] = merged
                changed = true
            }
        }
        if (changed) save()
        return changed
    }

    @Synchronized fun lastAt(id: String): Long = items[id]?.last ?: 0L

    /** Ultimo ascolto di un brano di questo artista (nome com'è nella cronologia). */
    @Synchronized fun lastByAuthor(name: String): Long =
        items.values.filter { MetaCleaner.cleanArtist(it.author).equals(name, true) || it.author.equals(name, true) }
            .maxOfOrNull { it.last } ?: 0L

    @Synchronized
    fun all(): List<Listen> = items.values.sortedByDescending { it.last }

    /** Toglie un elemento da "Visti/Ascoltati di recente" e dalla cronologia. */
    @Synchronized
    fun remove(id: String) {
        if (items.remove(id) == null) return
        removed[id] = System.currentTimeMillis()
        if (removed.size > 1000) removed.entries.sortedBy { it.value }.take(200).forEach { removed.remove(it.key) }
        save()
        onChanged?.invoke()
    }

    /** Cancella tutta la cronologia (anche i suggerimenti ripartono da zero). */
    @Synchronized
    fun clear() {
        items.clear()
        removed.clear()
        clearedAt = System.currentTimeMillis()
        save()
        onChanged?.invoke()
    }

    @Synchronized fun contains(id: String): Boolean = items.containsKey(id)

    /** Semi per i suggerimenti: frequenza + quanto di recente. */
    fun seeds(n: Int = 4, musicOnly: Boolean = false): List<Listen> {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val recent = all().filter { !musicOnly || it.music }.take(40)
        val scored = recent.sortedByDescending {
            val age = now - it.last
            it.count + when {
                age < 2 * day -> 4.0
                age < 7 * day -> 2.0
                age < 30 * day -> 0.5
                else -> 0.0
            }
        }
        // Sempre incluso l'ultimo ascolto, poi i più "pesanti", evitando lo stesso artista due volte
        val out = mutableListOf<Listen>()
        recent.firstOrNull()?.let { out += it }
        for (l in scored) {
            if (out.size >= n) break
            if (out.none { it.id == l.id || (it.author.isNotBlank() && it.author == l.author) }) out += l
        }
        return out
    }

    /** Artisti/canali più ascoltati (per proporre playlist e canali). */
    fun topArtists(n: Int = 4, musicOnly: Boolean = false): List<String> =
        all().filter { (!musicOnly || it.music) && it.author.isNotBlank() }
            .groupBy { it.author }
            .mapValues { (_, l) -> l.sumOf { it.count } + l.size }
            .entries.sortedByDescending { it.value }
            .take(n).map { it.key }

    private fun save() {
        val arr = JSONArray()
        items.values.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("author", it.author)
                    .put("thumb", it.thumb).put("music", it.music).put("count", it.count).put("last", it.last)
            )
        }
        sp.edit()
            .putString("items", arr.toString())
            .putString("removed", JSONObject(removed as Map<*, *>).toString())
            .putLong("clearedAt", clearedAt)
            .apply()
    }
}
