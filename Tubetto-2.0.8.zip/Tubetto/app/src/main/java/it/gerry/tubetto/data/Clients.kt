package it.gerry.tubetto.data

import it.gerry.tubetto.net.Http
import org.json.JSONObject

/**
 * Profili client InnerTube.
 *
 * I valori integrati qui sotto sono solo la base: all'avvio e ogni poche ore l'app legge
 * config/tubetto-config.json dal repository (aggiornato in automatico dal workflow
 * "Salute Tubetto" con le versioni di yt-dlp e testato prima di essere pubblicato).
 * Così quando YouTube cambia qualcosa non serve un nuovo APK.
 */
data class ClientProfile(
    val key: String,
    val clientName: String,
    val nameId: Int,
    val version: String,
    val userAgent: String,
    val context: Map<String, Any>,
)

object Clients {

    private val DEFAULTS: Map<String, ClientProfile> = listOf(
        ClientProfile(
            "WEB", "WEB", 1, "2.20251110.01.00", Http.WEB_USER_AGENT,
            mapOf("platform" to "DESKTOP"),
        ),
        // YouTube Music (ricerca brani, classifiche, radio)
        ClientProfile(
            "WEB_REMIX", "WEB_REMIX", 67, "1.20251110.01.00", Http.WEB_USER_AGENT,
            mapOf("platform" to "DESKTOP"),
        ),
        ClientProfile(
            "IOS", "IOS", 5, "20.10.4",
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            mapOf(
                "deviceMake" to "Apple", "deviceModel" to "iPhone16,2",
                "osName" to "iPhone", "osVersion" to "18.3.2.22D82", "platform" to "MOBILE",
            ),
        ),
        ClientProfile(
            "ANDROID_VR", "ANDROID_VR", 28, "1.65.10",
            "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            mapOf(
                "deviceMake" to "Oculus", "deviceModel" to "Quest 3", "androidSdkVersion" to 32,
                "osName" to "Android", "osVersion" to "12L", "platform" to "MOBILE",
            ),
        ),
        // Android SENZA androidSdkVersion: con quel campo YouTube pretende il PO token.
        ClientProfile(
            "ANDROID", "ANDROID", 3, "20.10.38",
            "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip",
            mapOf("osName" to "Android", "osVersion" to "14", "platform" to "MOBILE"),
        ),
    ).associateBy { it.key }

    private val DEFAULT_ORDER = listOf("IOS", "ANDROID_VR", "ANDROID")

    @Volatile private var profiles: Map<String, ClientProfile> = DEFAULTS
    @Volatile private var order: List<String> = DEFAULT_ORDER

    val WEB: ClientProfile get() = profiles["WEB"] ?: DEFAULTS.getValue("WEB")
    val WEB_REMIX: ClientProfile get() = profiles["WEB_REMIX"] ?: DEFAULTS.getValue("WEB_REMIX")
    val IOS: ClientProfile get() = profiles["IOS"] ?: DEFAULTS.getValue("IOS")
    val ANDROID_VR: ClientProfile get() = profiles["ANDROID_VR"] ?: DEFAULTS.getValue("ANDROID_VR")
    val ANDROID: ClientProfile get() = profiles["ANDROID"] ?: DEFAULTS.getValue("ANDROID")

    /** Ordine di tentativo per /player (poi fallback NewPipeExtractor). */
    val PLAYER_ORDER: List<ClientProfile>
        get() = order.mapNotNull { profiles[it] }.ifEmpty { DEFAULT_ORDER.map { DEFAULTS.getValue(it) } }

    /** Versioni in uso, per il rapporto "Stato servizio". */
    fun describe(): String =
        profiles.values.joinToString("\n") { "${it.key} ${it.version}" } + "\nOrdine player: " + order.joinToString(" → ")

    /**
     * Applica la configurazione remota. Valori mancanti o non validi restano quelli integrati.
     * @return true se la configurazione era valida ed è stata applicata.
     */
    fun apply(o: JSONObject): Boolean {
        val cl = o.optJSONObject("clients") ?: return false
        val map = DEFAULTS.toMutableMap()
        for (key in cl.keys()) {
            val c = cl.optJSONObject(key) ?: continue
            val base = map[key]
            val name = c.optString("clientName", base?.clientName.orEmpty())
            val version = c.optString("version", base?.version.orEmpty())
            val nameId = c.optInt("nameId", base?.nameId ?: 0)
            if (name.isBlank() || version.isBlank() || nameId <= 0) continue
            val ctx = LinkedHashMap<String, Any>()
            val co = c.optJSONObject("context")
            if (co != null) {
                for (k in co.keys()) {
                    val v = co.opt(k)
                    if (v is String || v is Int || v is Long || v is Boolean) ctx[k] = v
                }
            } else if (base != null) {
                ctx.putAll(base.context)
            }
            map[key] = ClientProfile(
                key = key,
                clientName = name,
                nameId = nameId,
                version = version,
                userAgent = c.optString("userAgent", base?.userAgent ?: Http.WEB_USER_AGENT).ifBlank { Http.WEB_USER_AGENT },
                context = ctx,
            )
        }
        val newOrder = mutableListOf<String>()
        o.optJSONArray("playerOrder")?.let { arr ->
            for (i in 0 until arr.length()) {
                val k = arr.optString(i)
                if (k in map && k !in newOrder) newOrder += k
            }
        }
        profiles = map
        order = newOrder.ifEmpty { DEFAULT_ORDER }
        return true
    }

    /** User-Agent da usare su googlevideo in base al parametro c= dell'URL. */
    fun userAgentFor(c: String?): String = when (c) {
        null -> Http.WEB_USER_AGENT
        else -> profiles.values.firstOrNull { it.clientName == c }?.userAgent ?: Http.WEB_USER_AGENT
    }
}
