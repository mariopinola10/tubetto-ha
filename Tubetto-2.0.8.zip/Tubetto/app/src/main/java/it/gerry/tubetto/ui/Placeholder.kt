package it.gerry.tubetto.ui

import android.widget.ImageView
import coil.load
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.VideoItem
import it.gerry.tubetto.playback.ArtworkProvider

/**
 * Copertine mancanti: al posto del riquadro vuoto un disegno con sfumatura colorata e simbolo
 * (♫ playlist, iniziale per artisti/canali, ▶ video, oppure l'emoji del titolo, es. 🔥 o 🆕).
 */
object Placeholder {

    private val COLORS = listOf("#3A7BD5", "#7B4DFF", "#E91E63", "#27AE60", "#D35400", "#16A085", "#2980B9", "#8E44AD", "#0A84D0")

    fun uri(v: VideoItem): String {
        val color = COLORS[(v.title.lowercase().hashCode() and 0x7fffffff) % COLORS.size]
        val lead = v.title.trim().takeWhile { !it.isLetterOrDigit() && !it.isWhitespace() }
        val symbol = when {
            lead.isNotBlank() -> lead
            v.kind == ItemKind.ARTIST || v.kind == ItemKind.CHANNEL -> v.title.trim().take(1).uppercase().ifBlank { "♪" }
            v.kind == ItemKind.PLAYLIST -> "♫"
            else -> "▶"
        }
        return ArtworkProvider.tileUri(color, symbol).toString()
    }

    /** Carica la copertina; se manca o non si scarica, mette il disegno. */
    fun load(view: ImageView, url: String?, v: VideoItem) {
        val fallback = uri(v)
        view.load(url ?: fallback) {
            crossfade(true)
            listener(onError = { _, _ -> if (url != null) view.load(fallback) })
        }
    }
}
