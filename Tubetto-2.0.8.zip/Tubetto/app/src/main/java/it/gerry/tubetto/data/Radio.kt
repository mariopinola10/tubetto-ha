package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * Radio web da Radio Browser (radio-browser.info): elenco libero e gratuito, senza chiave,
 * con decine di migliaia di stazioni. Le radio sono elementi con id "radio:<uuid>"; l'URL
 * dello stream sta in [VideoItem.description].
 */
object Radio {

    const val PREFIX = "radio:"
    const val SEARCH_TILE = "radio-search"

    private val SERVERS = listOf(
        "https://de1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://at1.api.radio-browser.info",
        "https://de2.api.radio-browser.info",
    )
    private const val UA = "Tubetto/1.9 (app Android personale)"

    private lateinit var sp: SharedPreferences

    /** Avvisa la sincronizzazione. */
    @Volatile var onChanged: (() -> Unit)? = null
    private val favorites = mutableListOf<VideoItem>()

    /** URL degli stream visti di recente (Android Auto manda solo l'id). */
    private val known = ConcurrentHashMap<String, VideoItem>()

    fun init(context: Context) {
        sp = context.getSharedPreferences("radio", Context.MODE_PRIVATE)
        runCatching {
            val arr = JSONArray(sp.getString("favorites", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val v = VideoItem(
                    id = o.getString("id"), title = o.optString("title"), author = o.optString("author"),
                    duration = "LIVE", description = o.optString("url"),
                    thumbnailUrl = o.optString("thumb").ifBlank { null },
                )
                favorites += v
                known[v.id] = v
            }
        }
    }

    fun isRadio(id: String) = id.startsWith(PREFIX)

    // ---------------- Preferite ----------------

    @Synchronized fun favorites(): List<VideoItem> = favorites.toList()

    @Synchronized fun isFavorite(id: String) = favorites.any { it.id == id }

    /** @return true se ora è tra le preferite. */
    @Synchronized
    fun toggleFavorite(v: VideoItem): Boolean {
        val now = if (favorites.removeAll { it.id == v.id }) false else { favorites.add(0, v); true }
        save()
        return now
    }

    /** Ultima modifica delle preferite (per la sincronizzazione). */
    val modified: Long get() = sp.getLong("modified", 0L)

    @Synchronized
    fun exportJson(): JSONObject {
        val arr = JSONArray()
        favorites.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("author", it.author)
                    .put("url", it.description).put("thumb", it.thumbnailUrl.orEmpty())
            )
        }
        return JSONObject().put("modified", modified).put("items", arr)
    }

    /** Preferite arrivate da un altro dispositivo (se più recenti). */
    @Synchronized
    fun importJson(o: JSONObject): Boolean {
        if (o.optLong("modified") <= modified) return false
        val arr = o.optJSONArray("items") ?: return false
        favorites.clear()
        for (i in 0 until arr.length()) {
            val x = arr.getJSONObject(i)
            val v = VideoItem(
                id = x.getString("id"), title = x.optString("title"), author = x.optString("author"),
                duration = "LIVE", description = x.optString("url"), thumbnailUrl = x.optString("thumb").ifBlank { null },
            )
            favorites += v
            known[v.id] = v
        }
        save(o.optLong("modified"))
        return true
    }

    private fun save(at: Long = System.currentTimeMillis()) {
        val arr = JSONArray()
        favorites.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("author", it.author)
                    .put("url", it.description).put("thumb", it.thumbnailUrl.orEmpty())
            )
        }
        sp.edit().putString("favorites", arr.toString()).putLong("modified", at).apply()
        onChanged?.invoke()
    }

    fun urlOf(id: String): String? = known[id]?.description?.ifBlank { null }
    fun itemOf(id: String): VideoItem? = known[id]

    // ---------------- Ricerca ----------------

    suspend fun top(limit: Int = 40) = query("countrycode=IT&order=clickcount&reverse=true&limit=$limit")
    suspend fun byState(state: String, limit: Int = 30) =
        query("countrycode=IT&state=${Uri.encode(state)}&order=clickcount&reverse=true&limit=$limit")
    suspend fun byTag(tag: String, italianOnly: Boolean = true, limit: Int = 30) =
        query((if (italianOnly) "countrycode=IT&" else "") + "tag=${Uri.encode(tag)}&order=clickcount&reverse=true&limit=$limit")
    suspend fun search(name: String, limit: Int = 50) =
        query("name=${Uri.encode(name)}&order=clickcount&reverse=true&limit=$limit")

    private suspend fun query(params: String): List<VideoItem> = withContext(Dispatchers.IO) {
        var last: Exception? = null
        for (server in SERVERS) {
            try {
                val body = Http.client.newCall(
                    Request.Builder().url("$server/json/stations/search?hidebroken=true&$params")
                        .header("User-Agent", UA).build()
                ).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                    r.body!!.string()
                }
                val arr = JSONArray(body)
                return@withContext (0 until arr.length()).mapNotNull { i -> toItem(arr.getJSONObject(i)) }
                    .distinctBy { it.title.lowercase().trim() }
                    .onEach { known[it.id] = it }
            } catch (e: Exception) {
                last = e
            }
        }
        throw IOException("Elenco radio non raggiungibile: ${last?.message}")
    }

    private fun toItem(o: JSONObject): VideoItem? {
        val url = o.optString("url_resolved").ifBlank { o.optString("url") }
        if (url.isBlank()) return null
        val tags = o.optString("tags").split(",").map { it.trim() }.filter { it.isNotBlank() }.take(2)
        val where = o.optString("state").ifBlank { o.optString("country") }
        val quality = listOf(o.optString("codec"), o.optInt("bitrate").takeIf { it > 0 }?.let { "$it kbps" })
            .filterNotNull().filter { it.isNotBlank() }.joinToString(" ")
        return VideoItem(
            id = PREFIX + o.optString("stationuuid"),
            title = o.optString("name").trim(),
            author = (listOf(where) + tags + quality).filter { it.isNotBlank() }.joinToString(" · "),
            duration = "LIVE",
            description = url,
            thumbnailUrl = o.optString("favicon").takeIf { it.startsWith("http") },
        )
    }

    /** Segnala l'ascolto a Radio Browser (tiene aggiornata la classifica delle radio più ascoltate). */
    suspend fun countClick(id: String) = withContext(Dispatchers.IO) {
        runCatching {
            Http.client.newCall(
                Request.Builder().url("${SERVERS.first()}/json/url/${id.removePrefix(PREFIX)}")
                    .header("User-Agent", UA).build()
            ).execute().close()
        }
    }
}
