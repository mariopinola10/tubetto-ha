package it.gerry.tubetto.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import it.gerry.tubetto.R
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.Library
import it.gerry.tubetto.data.VideoItem

/** Lista compatta: miniatura a sinistra, testi a destra; righe di intestazione per le sezioni. */
class VideoAdapter(
    private val onClick: (VideoItem, Int) -> Unit,
    private val onLongClick: (VideoItem, View) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    /** Su TV usa le card verticali grandi, con ingrandimento quando sono selezionate. */
    var tvMode = false

    /** Nella pagina di un canale l'autore è sempre lo stesso: non lo ripetiamo. */
    var hideAuthor = false

    /** Descrizione solo nei risultati di ricerca; altrove lista compatta. */
    var showDescription = false

    var items: List<VideoItem> = emptyList()
        private set

    fun refresh() = notifyDataSetChanged()

    fun submit(list: List<VideoItem>) {
        items = list
        notifyDataSetChanged()
    }

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val duration: TextView = v.findViewById(R.id.duration)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val meta: TextView = v.findViewById(R.id.meta)
        val description: TextView = v.findViewById(R.id.description)
        val more: View? = v.findViewById(R.id.more)
    }

    class HeaderHolder(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.header)
    }

    override fun getItemViewType(position: Int) = if (items[position].kind == ItemKind.HEADER) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == 1) HeaderHolder(inf.inflate(R.layout.item_header, parent, false))
        else Holder(inf.inflate(if (tvMode) R.layout.item_video_tv else R.layout.item_video, parent, false)).also { h ->
            if (tvMode) {
                h.itemView.setOnFocusChangeListener { v, focused ->
                    v.animate().scaleX(if (focused) 1.06f else 1f).scaleY(if (focused) 1.06f else 1f).setDuration(120).start()
                    v.elevation = if (focused) 12f else 2f
                }
            }
        }
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val v = items[position]
        if (holder is HeaderHolder) {
            holder.text.text = v.title
            return
        }
        val h = holder as Holder

        // Playlist, preferiti e mix senza immagine propria: mosaico delle copertine dei brani
        if (!Collage.load(h.thumb, v, android.graphics.drawable.ColorDrawable(0xFF8FA3B8.toInt()))) {
            h.thumb.setTag(R.id.collage_key, null)
            Placeholder.load(h.thumb, v.thumbnailUrl?.ifBlank { null } ?: if (v.kind == ItemKind.VIDEO) v.thumbnail else null, v)
        }

        // Copertine pulite: niente etichette sopra le foto di playlist, artisti e canali
        val badge = if (v.kind == ItemKind.VIDEO) v.duration else ""
        // Video 16:9; playlist quadrate; artisti e canali rotondi
        if (!tvMode) {
            val frame = h.thumb.parent as View
            val lp = frame.layoutParams
            val res = h.itemView.resources
            lp.width = if (v.kind == ItemKind.VIDEO) res.getDimensionPixelSize(R.dimen.thumb_w) else res.getDimensionPixelSize(R.dimen.thumb_h)
            frame.layoutParams = lp
            (h.thumb as? com.google.android.material.imageview.ShapeableImageView)?.let { iv ->
                iv.shapeAppearanceModel = if (v.kind == ItemKind.ARTIST || v.kind == ItemKind.CHANNEL)
                    com.google.android.material.shape.ShapeAppearanceModel.builder()
                        .setAllCornerSizes(com.google.android.material.shape.RelativeCornerSize(0.5f)).build()
                else
                    com.google.android.material.shape.ShapeAppearanceModel.builder()
                        .setAllCornerSizes(10f * res.displayMetrics.density).build()
            }
        }
        h.duration.text = badge
        h.duration.visibility = if (badge.isBlank()) View.GONE else View.VISIBLE
        h.duration.setBackgroundResource(
            when {
                v.duration == "LIVE" -> R.drawable.badge_live
                v.kind != ItemKind.VIDEO -> R.drawable.badge_azure
                else -> R.drawable.badge_dark
            }
        )

        h.title.text = when {
            v.kind == ItemKind.VIDEO && Library.isFavorite(v.id) -> "❤ ${v.title}"
            v.kind == ItemKind.ARTIST && Library.isArtistFollowed(v.id) -> "★ ${v.title}"
            else -> v.title
        }
        val author = if (hideAuthor) "" else v.author
        val meta = listOf(v.views, v.published).filter { it.isNotBlank() }.joinToString(" • ")
        if (author.isBlank()) {
            h.subtitle.text = meta
            h.meta.visibility = View.GONE
        } else {
            h.subtitle.text = author
            h.meta.text = meta
            h.meta.visibility = if (meta.isBlank()) View.GONE else View.VISIBLE
        }
        // il numero di brani delle playlist va nel sottotitolo (non più sulla copertina)
        if (v.kind == ItemKind.PLAYLIST && v.duration.isNotBlank() && !h.subtitle.text.contains(v.duration)) {
            h.subtitle.text = listOf(h.subtitle.text?.toString().orEmpty(), v.duration).filter { it.isNotBlank() }.joinToString(" · ")
        }
        h.subtitle.visibility = if (h.subtitle.text.isNullOrBlank()) View.GONE else View.VISIBLE
        h.description.text = v.description
        h.description.visibility = if (!showDescription || tvMode || v.description.isBlank()) View.GONE else View.VISIBLE

        h.itemView.setOnClickListener { onClick(v, h.bindingAdapterPosition) }
        h.itemView.setOnLongClickListener { onLongClick(v, it); true }
        // ⋯ = stesso menu del tocco lungo (coda, playlist, preferiti…), area di tocco 48dp
        h.more?.visibility = if (tvMode || v.id.startsWith("tile:")) View.GONE else View.VISIBLE
        h.more?.setOnClickListener { onLongClick(v, it) }
    }
}
