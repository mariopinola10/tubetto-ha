package it.gerry.tubetto.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException

/**
 * Aggiornamento dall'ultima release GitHub (funziona anche con repo privato + token).
 * La release viene creata dal workflow con tag vX.Y.Z e asset Tubetto-X.Y.Z.apk.
 */
class Updater(private val context: Context) {

    data class Release(val version: String, val assetApiUrl: String, val assetName: String, val notes: String)

    private val prefs = UpdatePrefs(context)

    private fun Request.Builder.auth(): Request.Builder = apply {
        header("X-GitHub-Api-Version", "2022-11-28")
        if (prefs.token.isNotBlank() && prefs.releasesRepo == prefs.repo) header("Authorization", "Bearer ${prefs.token}")
    }

    suspend fun latest(): Release = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://api.github.com/repos/${prefs.releasesRepo}/releases/latest")
            .header("Accept", "application/vnd.github+json")
            .auth()
            .build()
        Http.client.newCall(req).execute().use { r ->
            when {
                r.code == 401 -> throw IOException("Token non valido o scaduto (HTTP 401)")
                r.code == 403 -> throw IOException("Token senza permesso Contents: Read su questo repo (HTTP 403)")
                r.code == 404 -> throw IOException(
                    "Repo o release non trovati (HTTP 404).\n• Controlla utente e nome repo\n" +
                        "• Se il repo è privato serve il token\n• Deve esistere almeno una release creata dal workflow"
                )
                !r.isSuccessful -> throw IOException("GitHub HTTP ${r.code}")
            }
            val json = JSONObject(r.body!!.string())
            val assets = json.getJSONArray("assets")
            val apk = (0 until assets.length()).map { assets.getJSONObject(it) }
                .firstOrNull { it.getString("name").endsWith(".apk") }
                ?: throw IOException("La release non contiene un APK")
            Release(
                version = json.getString("tag_name").removePrefix("v"),
                assetApiUrl = apk.getString("url"),
                assetName = apk.getString("name"),
                notes = json.optString("body"),
            )
        }
    }

    /** Scarica l'APK. OkHttp rimuove Authorization sul redirect verso lo storage GitHub. */
    suspend fun download(release: Release, onProgress: (Int) -> Unit = {}): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, release.assetName)

        val req = Request.Builder()
            .url(release.assetApiUrl)
            .header("Accept", "application/octet-stream")
            .auth()
            .build()
        Http.client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Download HTTP ${r.code}")
            val body = r.body ?: throw IOException("Risposta vuota")
            val total = body.contentLength()
            body.byteStream().use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != last) { last = pct; withContext(Dispatchers.Main) { onProgress(pct) } }
                        }
                    }
                }
            }
        }
        out
    }

    /** @return false se serve prima concedere "Installa app sconosciute". */
    fun install(apk: File): Boolean {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }

    companion object {
        fun isNewer(remote: String, local: String): Boolean {
            fun parse(v: String) = v.split(".").map { it.toIntOrNull() ?: 0 } + listOf(0, 0, 0)
            val r = parse(remote); val l = parse(local)
            for (i in 0 until 3) if (r[i] != l[i]) return r[i] > l[i]
            return false
        }
    }
}
