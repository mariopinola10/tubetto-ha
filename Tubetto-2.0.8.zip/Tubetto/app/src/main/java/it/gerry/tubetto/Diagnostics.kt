package it.gerry.tubetto

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log in memoria condiviso tra service e UI (stesso processo). */
object Diagnostics {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.ITALY)

    @Synchronized
    fun log(msg: String) {
        Log.i("Tubetto", msg)
        lines.addLast("${fmt.format(Date())} $msg")
        while (lines.size > 300) lines.removeFirst()
    }

    @Synchronized
    fun last(): String = lines.lastOrNull().orEmpty()

    @Synchronized
    fun dump(): String = lines.joinToString("\n").ifEmpty { "(vuoto)" }
}
