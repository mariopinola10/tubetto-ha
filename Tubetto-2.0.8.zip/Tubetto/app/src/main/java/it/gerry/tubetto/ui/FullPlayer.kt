package it.gerry.tubetto.ui

import it.gerry.tubetto.data.Lyrics
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.graphics.ColorUtils
import kotlinx.coroutines.launch
import androidx.core.graphics.drawable.toBitmap
import androidx.media3.common.Player
import coil.load
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import it.gerry.tubetto.R
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.Library
import it.gerry.tubetto.data.VideoItem
import it.gerry.tubetto.playback.PlaybackService

/**
 * Player a schermo intero in stile Spotify (telefono): copertina grande con ombra del suo colore,
 * titolo/artista/cuore, barra di avanzamento, casuale/precedente/play/successivo/ripeti,
 * uscita audio e coda. Si apre toccando il mini player.
 */
class FullPlayer(
    private val act: Activity,
    private val player: () -> Player?,
    private val callbacks: Callbacks,
) {
    interface Callbacks {
        fun onCast()
        fun onMore(item: VideoItem, anchor: View)
        /** Il brano è solo audio: riproduci il video dallo stesso punto. */
        fun onWatchVideo(item: VideoItem, positionMs: Long)
        /** Il video è in modalità solo audio: torna a mostrarlo. */
        fun onBackToVideo()
        fun isAudioOnlyVideo(): Boolean
        fun sourceTitle(): String
        fun onOpenChanged(open: Boolean)
        fun onShare(item: VideoItem)
        /** Chiude il video e resta solo l'audio. */
        fun onAudioOnly()
        fun isVideoPlaying(): Boolean
        /** Tocco sul nome dell'artista: apre il canale. */
        fun onOpenChannel() {}
    }

    private val root: View = LayoutInflater.from(act).inflate(
        R.layout.view_full_player, act.findViewById<ViewGroup>(android.R.id.content), false,
    ).also { act.findViewById<ViewGroup>(android.R.id.content).addView(it) }

    private val source: TextView = root.findViewById(R.id.fpSource)
    private val coverCard: MaterialCardView = root.findViewById(R.id.fpCoverCard)
    private val cover: ImageView = root.findViewById(R.id.fpCover)
    private val videoToggle: MaterialButton = root.findViewById(R.id.fpVideoToggle)
    private val title: TextView = root.findViewById(R.id.fpTitle)
    private val artist: TextView = root.findViewById(R.id.fpArtist)
    private val like: ImageButton = root.findViewById(R.id.fpLike)
    private val seek: SeekBar = root.findViewById(R.id.fpSeek)
    private val pos: TextView = root.findViewById(R.id.fpPos)
    private val dur: TextView = root.findViewById(R.id.fpDur)
    private val shuffle: ImageButton = root.findViewById(R.id.fpShuffle)
    private val play: FloatingActionButton = root.findViewById(R.id.fpPlay)
    private val repeat: ImageButton = root.findViewById(R.id.fpRepeat)
    private val outputIcon: ImageView = root.findViewById(R.id.fpOutputIcon)
    private val outputName: TextView = root.findViewById(R.id.fpOutputName)

    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    private var lastArt: String? = null

    val isOpen: Boolean get() = root.visibility == View.VISIBLE

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (isOpen) handler.postDelayed(this, 500)
        }
    }

    init {
        root.findViewById<View>(R.id.fpClose).setOnClickListener { close() }
        root.findViewById<View>(R.id.fpCast).setOnClickListener { callbacks.onCast() }
        root.findViewById<View>(R.id.fpShare).setOnClickListener { currentItem()?.let { callbacks.onShare(it) } }
        // Copertina sempre quadrata, grande quanto lo spazio disponibile
        val coverBox = coverCard.parent as View
        coverBox.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            val side = minOf(v.width - v.paddingLeft - v.paddingRight, v.height - v.paddingTop - v.paddingBottom)
            if (side > 0 && coverCard.layoutParams.width != side) {
                coverCard.layoutParams = coverCard.layoutParams.apply { width = side; height = side }
            }
        }
        root.findViewById<View>(R.id.fpMore).setOnClickListener { v -> currentItem()?.let { callbacks.onMore(it, v) } }
        root.findViewById<View>(R.id.fpPrev).setOnClickListener {
            player()?.let { p -> if (p.currentPosition > 4000) p.seekTo(0) else p.seekToPreviousMediaItem() }
        }
        root.findViewById<View>(R.id.fpNext).setOnClickListener { player()?.seekToNextMediaItem() }
        play.setOnClickListener { player()?.let { if (it.isPlaying) it.pause() else it.play() } }
        shuffle.setOnClickListener { player()?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled; update() } }
        repeat.setOnClickListener {
            player()?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                update()
            }
        }
        like.setOnClickListener {
            val item = currentItem() ?: return@setOnClickListener
            Library.toggleFavorite(item)
            update()
        }
        root.findViewById<View>(R.id.fpQueue).setOnClickListener { showQueue() }
        root.findViewById<View>(R.id.fpLyrics).setOnClickListener { showLyrics() }
        // il nome dell'artista porta al suo canale
        artist.setOnClickListener { callbacks.onOpenChannel() }
        root.findViewById<View>(R.id.fpOutput).setOnClickListener { showOutputMenu() }
        videoToggle.setOnClickListener {
            val p = player() ?: return@setOnClickListener
            if (callbacks.isAudioOnlyVideo()) callbacks.onBackToVideo()
            else currentItem()?.let { callbacks.onWatchVideo(it, p.currentPosition) }
            close()
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, value: Int, fromUser: Boolean) {
                if (fromUser) {
                    val d = player()?.duration ?: 0L
                    if (d > 0) pos.text = fmt(d * value / 1000)
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar) {
                dragging = false
                player()?.let { p -> if (p.duration > 0) p.seekTo(p.duration * s.progress / 1000) }
            }
        })
    }

    fun open() {
        if (player()?.currentMediaItem == null) return
        update()
        root.visibility = View.VISIBLE
        root.translationY = root.height.takeIf { it > 0 }?.toFloat() ?: 2000f
        root.animate().translationY(0f).setDuration(220).start()
        title.isSelected = true // scorrimento del titolo lungo
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        callbacks.onOpenChanged(true)
    }

    fun close() {
        if (!isOpen) return
        handler.removeCallbacks(ticker)
        callbacks.onOpenChanged(false)
        root.animate().translationY(root.height.toFloat()).setDuration(200).withEndAction {
            root.visibility = View.GONE
            root.translationY = 0f
        }.start()
    }

    /** Aggiorna tutto (chiamato dagli eventi del player). */
    fun update() {
        if (!isOpen) return
        val p = player()
        val item = p?.currentMediaItem
        if (p == null || item == null) {
            close()
            return
        }
        val m = item.mediaMetadata
        source.text = callbacks.sourceTitle().ifBlank { "In riproduzione" }
        title.text = m.title ?: ""
        artist.text = m.artist ?: ""
        val id = PlaybackService.videoIdOf(item.mediaId)
        val fav = Library.isFavorite(id)
        like.setImageResource(if (fav) R.drawable.ic_aa_heart else R.drawable.ic_heart_outline)
        like.setColorFilter(if (fav) Color.parseColor("#FF4D7D") else Color.WHITE)
        play.setImageResource(if (p.isPlaying || (p.playWhenReady && p.playbackState == Player.STATE_BUFFERING)) R.drawable.ic_pause else R.drawable.ic_play)
        shuffle.alpha = if (p.shuffleModeEnabled) 1f else 0.45f
        shuffle.setColorFilter(if (p.shuffleModeEnabled) act.getColor(R.color.azure_light) else Color.WHITE)
        repeat.setImageResource(if (p.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        repeat.alpha = if (p.repeatMode == Player.REPEAT_MODE_OFF) 0.45f else 1f
        repeat.setColorFilter(if (p.repeatMode == Player.REPEAT_MODE_OFF) Color.WHITE else act.getColor(R.color.azure_light))

        // Solo audio ↔ video
        val audioItem = item.mediaId.startsWith("a:")
        videoToggle.visibility = if (item.mediaId.startsWith("radio:")) View.GONE
            else if (audioItem || callbacks.isAudioOnlyVideo()) View.VISIBLE else View.GONE
        videoToggle.text = if (callbacks.isAudioOnlyVideo()) "▶  Torna al video" else "▶  Guarda il video"

        val art = item.mediaId + "|" + m.artworkUri
        if (art != lastArt) {
            lastArt = art
            // copertina 16:9 HD del video, poi le alternative (playlist, logo): mai vuota
            NowArt.load(cover, NowArt.candidates(item, hd = true)) { d -> applyColor(d.toBitmap(24, 24)) }
        }
        updateOutput()
        updateProgress()
    }

    private fun updateProgress() {
        val p = player() ?: return
        val d = p.duration.takeIf { it > 0 } ?: 0L
        val c = p.currentPosition.coerceAtLeast(0)
        if (!dragging) {
            seek.progress = if (d > 0) (c * 1000 / d).toInt() else 0
            pos.text = fmt(c)
        }
        dur.text = if (d > 0) "-" + fmt(d - c) else ""
        play.setImageResource(if (p.isPlaying || (p.playWhenReady && p.playbackState == Player.STATE_BUFFERING)) R.drawable.ic_pause else R.drawable.ic_play)
    }

    /** Colore dominante della copertina: sfondo sfumato e ombra della copertina. */
    private fun applyColor(bmp: android.graphics.Bitmap) {
        val avg = android.graphics.Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(avg, hsl)
        hsl[1] = (hsl[1] * 1.3f).coerceAtMost(0.9f)
        hsl[2] = hsl[2].coerceIn(0.35f, 0.6f)
        val vivid = ColorUtils.HSLToColor(hsl)
        val top = ColorUtils.blendARGB(vivid, Color.parseColor("#0E1621"), 0.55f)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(top, Color.parseColor("#0E1621"), Color.parseColor("#0A1018")),
        )
        if (Build.VERSION.SDK_INT >= 28) {
            coverCard.outlineSpotShadowColor = vivid
            coverCard.outlineAmbientShadowColor = vivid
        }
    }

    /** Uscita audio attuale: Bluetooth, cuffie con filo o altoparlante. */
    private fun updateOutput() {
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val bt = outs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
        val wired = outs.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        when {
            bt != null -> {
                outputIcon.setImageResource(R.drawable.ic_headphones)
                outputName.text = bt.productName?.toString()?.takeIf { it.isNotBlank() } ?: "Cuffie Bluetooth"
            }
            wired != null -> {
                outputIcon.setImageResource(R.drawable.ic_headphones)
                outputName.text = "Cuffie"
            }
            else -> {
                outputIcon.setImageResource(R.drawable.ic_speaker)
                outputName.text = "Questo telefono"
            }
        }
    }

    /** Dove suona: uscita audio, TV, e per i video "chiudi il video" con un tocco. */
    private fun showOutputMenu() {
        val opts = mutableListOf<Pair<String, () -> Unit>>()
        opts += "🔈  Uscita audio: ${outputName.text}  (cambia…)" to { openOutputSwitcher() }
        opts += "📺  Trasmetti su TV / Fire TV" to { callbacks.onCast() }
        if (callbacks.isVideoPlaying()) opts += "✕  Chiudi il video (resta l'audio)" to { callbacks.onAudioOnly(); close() }
        if (callbacks.isAudioOnlyVideo()) opts += "▶  Torna al video" to { callbacks.onBackToVideo(); close() }
        AlertDialog.Builder(act)
            .setTitle("Dove ascoltare")
            .setItems(opts.map { it.first }.toTypedArray()) { _, i -> opts[i].second() }
            .setNegativeButton("✕", null)
            .show()
    }

    /** Selettore di uscita audio di Android (Bluetooth, altoparlante…). */
    private fun openOutputSwitcher() {
        val panel = Intent("com.android.settings.panel.action.MEDIA_OUTPUT")
            .putExtra("com.android.settings.panel.extra.PACKAGE_NAME", act.packageName)
        try {
            act.startActivity(panel)
        } catch (e: Exception) {
            runCatching { act.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
    }

    /** Coda leggibile: copertina, titolo su due righe, artista; il brano attuale è evidenziato. */
    private fun showQueue() {
        val p = player() ?: return
        val n = p.mediaItemCount
        if (n == 0) return
        val cur = p.currentMediaItemIndex
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val accent = act.getColor(R.color.azure_light)

        val box = android.widget.LinearLayout(act).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(0, px(18), 0, px(8))
        }
        box.addView(TextView(act).apply {
            text = "In coda"
            setTextColor(Color.WHITE)
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(px(22), 0, px(22), 0)
        })
        box.addView(TextView(act).apply {
            text = "Brano ${cur + 1} di $n · tocca un brano per ascoltarlo"
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 13f
            setPadding(px(22), px(2), px(22), px(10))
        })

        val listView = android.widget.ListView(act).apply {
            divider = null
            selector = android.graphics.drawable.ColorDrawable(0x22FFFFFF)
            layoutParams = android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        listView.adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = n
            override fun getItem(i: Int) = p.getMediaItemAt(i)
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
                val row = convert as? android.widget.LinearLayout ?: android.widget.LinearLayout(act).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(px(18), px(8), px(18), px(8))
                    addView(com.google.android.material.imageview.ShapeableImageView(act).apply {
                        id = R.id.queue_thumb
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        shapeAppearanceModel = shapeAppearanceModel.toBuilder().setAllCornerSizes(6 * dp).build()
                        layoutParams = android.widget.LinearLayout.LayoutParams(px(52), px(52))
                    })
                    addView(android.widget.LinearLayout(act).apply {
                        orientation = android.widget.LinearLayout.VERTICAL
                        setPadding(px(14), 0, 0, 0)
                        layoutParams = android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        addView(TextView(act).apply {
                            id = R.id.queue_title
                            textSize = 15f
                            maxLines = 2
                            ellipsize = android.text.TextUtils.TruncateAt.END
                            setTypeface(typeface, android.graphics.Typeface.BOLD)
                        })
                        addView(TextView(act).apply {
                            id = R.id.queue_sub
                            textSize = 13f
                            maxLines = 1
                            ellipsize = android.text.TextUtils.TruncateAt.END
                            setTextColor(0xA6FFFFFF.toInt())
                        })
                    })
                }
                val m = p.getMediaItemAt(i).mediaMetadata
                val now = i == cur
                row.setBackgroundColor(if (now) 0x1FFFFFFF else Color.TRANSPARENT)
                row.findViewById<ImageView>(R.id.queue_thumb).load(m.artworkUri) {
                    crossfade(true)
                    placeholder(R.drawable.bg_round_dark)
                    error(R.drawable.bg_round_dark)
                }
                row.findViewById<TextView>(R.id.queue_title).apply {
                    text = m.title ?: ""
                    setTextColor(if (now) accent else Color.WHITE)
                }
                row.findViewById<TextView>(R.id.queue_sub).text =
                    (if (now) "▶ In riproduzione · " else "") + (m.artist ?: "")
                return row
            }
        }
        box.addView(listView)

        val dlg = AlertDialog.Builder(act)
            .setView(box)
            .setNegativeButton("Chiudi", null)
            .create()
        listView.setOnItemClickListener { _, _, i, _ ->
            p.seekTo(i, 0)
            dlg.dismiss()
        }
        dlg.window?.setBackgroundDrawable(GradientDrawable().apply {
            setColor(0xFF161C24.toInt())
            cornerRadius = 20 * dp
        })
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(accent)
        // altezza: al massimo l'80% dello schermo
        val maxH = (act.resources.displayMetrics.heightPixels * 0.8f).toInt()
        dlg.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, maxH)
        listView.setSelection((cur - 1).coerceAtLeast(0))
    }

    /**
     * Testo della canzone (LRCLIB). Se è sincronizzato, la riga cantata è evidenziata e lo scorrimento
     * la segue; toccando una riga si salta a quel punto.
     */
    private fun showLyrics() {
        val p = player() ?: return
        val item = currentItem() ?: return
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val accent = act.getColor(R.color.azure_light)

        val lines = android.widget.LinearLayout(act).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(px(22), px(8), px(22), px(40))
        }
        val scroll = android.widget.ScrollView(act).apply { addView(lines) }
        val header = TextView(act).apply {
            text = "${item.title}\n${item.author}"
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 13f
            setPadding(px(22), px(18), px(22), px(6))
        }
        val box = android.widget.LinearLayout(act).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(header)
            addView(scroll, android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        lines.addView(TextView(act).apply {
            text = "Cerco il testo…"
            setTextColor(Color.WHITE)
            textSize = 18f
        })
        val dlg = AlertDialog.Builder(act).setView(box).setNegativeButton("Chiudi", null).create()
        dlg.window?.setBackgroundDrawable(GradientDrawable().apply {
            setColor(0xFF161C24.toInt())
            cornerRadius = 20 * dp
        })
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(accent)
        dlg.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (act.resources.displayMetrics.heightPixels * 0.85f).toInt())

        val durSec = if (p.duration > 0) p.duration / 1000 else 0L
        val job = kotlinx.coroutines.MainScope().launch {
            val res = Lyrics.get(item.title, item.author, durSec)
            lines.removeAllViews()
            if (res == null) {
                lines.addView(TextView(act).apply {
                    text = "Testo non trovato per questo brano."
                    setTextColor(Color.WHITE)
                    textSize = 17f
                })
                return@launch
            }
            if (res.synced.isEmpty()) {
                lines.addView(TextView(act).apply {
                    text = res.plain
                    setTextColor(Color.WHITE)
                    textSize = 18f
                    setLineSpacing(0f, 1.25f)
                })
                return@launch
            }
            val views = res.synced.map { l ->
                TextView(act).apply {
                    text = l.text.ifBlank { "♪" }
                    textSize = 21f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(0x66FFFFFF)
                    setPadding(0, px(7), 0, px(7))
                    setOnClickListener { player()?.seekTo(l.ms) }
                }.also { lines.addView(it) }
            }
            var current = -1
            while (dlg.isShowing) {
                val pos = player()?.currentPosition ?: break
                val idx = res.synced.indexOfLast { it.ms <= pos + 300 }
                if (idx != current) {
                    views.getOrNull(current)?.setTextColor(0x66FFFFFF)
                    views.getOrNull(idx)?.let { v ->
                        v.setTextColor(Color.WHITE)
                        scroll.smoothScrollTo(0, (v.top - scroll.height / 3).coerceAtLeast(0))
                    }
                    current = idx
                }
                kotlinx.coroutines.delay(250)
            }
        }
        dlg.setOnDismissListener { job.cancel() }
    }

    private fun currentItem(): VideoItem? {
        val item = player()?.currentMediaItem ?: return null
        val m = item.mediaMetadata
        return VideoItem(
            id = PlaybackService.videoIdOf(item.mediaId),
            title = m.title?.toString().orEmpty(),
            author = m.artist?.toString().orEmpty(),
            duration = "",
            thumbnailUrl = m.artworkUri?.toString()?.takeIf { it.startsWith("http") },
            kind = ItemKind.VIDEO,
        )
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }
}
