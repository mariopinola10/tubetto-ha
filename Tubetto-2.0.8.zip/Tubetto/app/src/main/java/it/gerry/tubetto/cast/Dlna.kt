package it.gerry.tubetto.cast

import android.content.Context
import android.net.wifi.WifiManager
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.IOException
import java.io.StringReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import javax.xml.parsers.DocumentBuilderFactory

/** @param isTubetto true se è il ricevitore Tubetto (Fire TV): accetta direttamente i link YouTube in piena qualità. */
data class Renderer(val name: String, val location: String, val avTransportUrl: String, val isTubetto: Boolean)

/** UPnP/DLNA: scoperta dei MediaRenderer via SSDP e comandi AVTransport via SOAP. */
object Dlna {

    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"
    private val OK_STATES = setOf("PLAYING", "TRANSITIONING")

    suspend fun discover(context: Context, timeoutMs: Long = 4000): List<Renderer> = withContext(Dispatchers.IO) {
        val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
        val lock = wifi.createMulticastLock("tubetto-ssdp").apply { setReferenceCounted(false); acquire() }
        val locations = linkedSetOf<String>()
        try {
            DatagramSocket(null).use { sock ->
                sock.reuseAddress = true
                sock.bind(InetSocketAddress(0))
                sock.soTimeout = 500
                val group = InetAddress.getByName("239.255.255.250")
                for (st in listOf("urn:schemas-upnp-org:device:MediaRenderer:1", AVT)) {
                    val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: $st\r\n\r\n").toByteArray()
                    repeat(2) { sock.send(DatagramPacket(msg, msg.size, group, 1900)) }
                }
                val buf = ByteArray(8192)
                val deadline = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < deadline) {
                    val p = DatagramPacket(buf, buf.size)
                    try { sock.receive(p) } catch (_: SocketTimeoutException) { continue }
                    val text = String(p.data, 0, p.length)
                    Regex("(?im)^location:\\s*(\\S+)").find(text)?.groupValues?.get(1)?.let { locations += it }
                }
            }
        } finally {
            lock.release()
        }
        locations.mapNotNull { loc ->
            runCatching { describe(loc) }.onFailure { Diagnostics.log("DLNA $loc: ${it.message}") }.getOrNull()
        }.distinctBy { it.avTransportUrl }
            .sortedByDescending { it.isTubetto }
    }

    private fun describe(location: String): Renderer? {
        val xml = Http.client.newCall(Request.Builder().url(location).build()).execute().use { it.body?.string() }
            ?: return null
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(StringReader(xml)))
        fun tag(n: String) = doc.getElementsByTagName(n).item(0)?.textContent?.trim().orEmpty()
        val name = tag("friendlyName").ifBlank { "Dispositivo" }
        val isTubetto = "Tubetto" in tag("manufacturer") || "Tubetto" in tag("modelName")
        val base = tag("URLBase").ifBlank { location }
        val services = doc.getElementsByTagName("service")
        for (i in 0 until services.length) {
            val e = services.item(i) as? Element ?: continue
            val type = e.getElementsByTagName("serviceType").item(0)?.textContent.orEmpty()
            val ctrl = e.getElementsByTagName("controlURL").item(0)?.textContent?.trim() ?: continue
            if ("AVTransport" in type) {
                val abs = base.toHttpUrl().resolve(ctrl)?.toString() ?: continue
                return Renderer(if (isTubetto) "$name ★" else name, location, abs, isTubetto)
            }
        }
        return null
    }

    /**
     * Molte TV (es. Samsung) partono da sole dopo SetAVTransportURI e rispondono
     * all'azione Play con un errore SOAP 500 (UPnP 701 "transizione non disponibile").
     * In quel caso verifichiamo lo stato: se sta già suonando è tutto ok.
     */
    suspend fun play(r: Renderer, url: String, title: String, mime: String) {
        soap(
            r, "SetAVTransportURI",
            "<InstanceID>0</InstanceID><CurrentURI>${esc(url)}</CurrentURI>" +
                "<CurrentURIMetaData>${esc(didl(url, title, mime))}</CurrentURIMetaData>"
        )
        try {
            soap(r, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>")
        } catch (e: IOException) {
            Diagnostics.log("DLNA Play rifiutato (${e.message?.take(80)}), controllo lo stato")
            repeat(4) { attempt ->
                delay(1000)
                val state = runCatching { transportState(r) }.getOrNull()
                Diagnostics.log("DLNA stato ${r.name}: $state")
                if (state != null && state in OK_STATES) return
                if (attempt == 1) runCatching { soap(r, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>") }
            }
            throw e
        }
    }

    suspend fun resume(r: Renderer) { soap(r, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>") }
    suspend fun pause(r: Renderer) { soap(r, "Pause", "<InstanceID>0</InstanceID>") }
    suspend fun stop(r: Renderer) { soap(r, "Stop", "<InstanceID>0</InstanceID>") }

    suspend fun transportState(r: Renderer): String? {
        val body = soap(r, "GetTransportInfo", "<InstanceID>0</InstanceID>")
        return Regex("<CurrentTransportState>(.*?)</CurrentTransportState>").find(body)?.groupValues?.get(1)
    }

    private suspend fun soap(r: Renderer, action: String, args: String): String = withContext(Dispatchers.IO) {
        val body = """<?xml version="1.0" encoding="utf-8"?>""" +
            """<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">""" +
            """<s:Body><u:$action xmlns:u="$AVT">$args</u:$action></s:Body></s:Envelope>"""
        val req = Request.Builder()
            .url(r.avTransportUrl)
            .post(body.toRequestBody("text/xml; charset=utf-8".toMediaType()))
            .header("SOAPACTION", "\"$AVT#$action\"")
            .build()
        Http.client.newCall(req).execute().use {
            val text = it.body?.string().orEmpty()
            if (!it.isSuccessful) {
                val code = Regex("<errorCode>(\\d+)</errorCode>").find(text)?.groupValues?.get(1)
                val desc = Regex("<errorDescription>(.*?)</errorDescription>").find(text)?.groupValues?.get(1)
                throw IOException("$action HTTP ${it.code}" + (code?.let { c -> " UPnP $c ${desc.orEmpty()}" } ?: ""))
            }
            text
        }
    }

    private fun didl(url: String, title: String, mime: String): String {
        val cls = if (mime.startsWith("audio")) "object.item.audioItem.musicTrack" else "object.item.videoItem"
        return """<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" """ +
            """xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">""" +
            """<item id="0" parentID="-1" restricted="1"><dc:title>${esc(title)}</dc:title>""" +
            """<upnp:class>$cls</upnp:class>""" +
            """<res protocolInfo="http-get:*:$mime:DLNA.ORG_OP=01;DLNA.ORG_CI=0">${esc(url)}</res>""" +
            """</item></DIDL-Lite>"""
    }

    fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")
}
