package it.gerry.tubetto.playback

import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.os.Build
import it.gerry.tubetto.Diagnostics

/**
 * Profilo sonoro applicato al player:
 * equalizzatore (bassi/alti) + compressione multibanda + limiter, così in auto
 * i brani hanno corpo, si sentono bene anche a basso volume e senza sbalzi.
 */
class AudioFx {

    private var dp: DynamicsProcessing? = null
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null

    fun apply(sessionId: Int, profile: AudioPrefs.Profile) {
        release()
        if (sessionId == 0 || profile == AudioPrefs.Profile.NATURAL) return
        runCatching {
            if (Build.VERSION.SDK_INT >= 28) applyDynamics(sessionId, profile) else applyLegacy(sessionId, profile)
            Diagnostics.log("Profilo audio: ${profile.name}")
        }.onFailure { Diagnostics.log("Effetti audio non disponibili: ${it.message}") }
    }

    private fun applyDynamics(sessionId: Int, profile: AudioPrefs.Profile) {
        val bands = 5
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2,           // canali
            true, bands, // pre-EQ
            true, 3,     // compressore multibanda
            false, 0,    // post-EQ
            true,        // limiter
        ).build()
        val p = DynamicsProcessing(0, sessionId, cfg)

        // Pre-EQ: frequenza di taglio superiore di ogni banda + guadagno (dB)
        val gains = when (profile) {
            AudioPrefs.Profile.BASS -> floatArrayOf(7f, 4f, 0f, 0.5f, 1.5f)
            else -> floatArrayOf(4.5f, 2f, 0f, 1.5f, 3f)
        }
        val cutoffs = floatArrayOf(90f, 300f, 2500f, 7000f, 20000f)
        for (i in 0 until bands) p.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cutoffs[i], gains[i]))

        // Compressione dolce su 3 bande: alza le parti basse, contiene i picchi
        val mbcCut = floatArrayOf(250f, 4000f, 20000f)
        for (i in 0 until 3) {
            p.setMbcBandAllChannelsTo(
                i,
                DynamicsProcessing.MbcBand(
                    true, mbcCut[i],
                    10f,    // attack ms
                    150f,   // release ms
                    2.5f,   // ratio
                    -24f,   // threshold dB
                    6f,     // knee dB
                    -90f,   // noise gate
                    1f,     // expander ratio
                    0f,     // pre-gain
                    3f,     // post-gain (recupera volume)
                ),
            )
        }
        p.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -1.5f, 0f))
        p.setEnabled(true)
        dp = p
    }

    private fun applyLegacy(sessionId: Int, profile: AudioPrefs.Profile) {
        bass = BassBoost(0, sessionId).apply {
            setStrength((if (profile == AudioPrefs.Profile.BASS) 700 else 400).toShort())
            setEnabled(true)
        }
        eq = Equalizer(0, sessionId).apply {
            val n = numberOfBands.toInt()
            val max = bandLevelRange[1]
            if (n > 0) setBandLevel((n - 1).toShort(), (max * 0.4).toInt().toShort())
            setEnabled(true)
        }
    }

    fun release() {
        runCatching { dp?.release() }
        runCatching { eq?.release() }
        runCatching { bass?.release() }
        dp = null; eq = null; bass = null
    }
}
