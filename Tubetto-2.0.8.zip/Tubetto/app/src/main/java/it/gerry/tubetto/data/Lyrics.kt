package it.gerry.tubetto.data

import android.net.Uri
import android.util.LruCache
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Testi delle canzoni da LRCLIB (lrclib.net): gratuito, senza chiave, spesso sincronizzati riga per riga. */
object Lyrics {

    data class Line(val ms: Long, val text: String)
    data class Result(val synced: List<Line>, val plain: String?) {
        val isEmpty: Boolean get() = synced.isEmpty() && plain.isNullOrBlank()
    }

    private val cache = LruCache<String, Result>(60)
    private const val UA = "Tubetto (app Android personale; https://github.com/mariopinola10)"

    suspend fun get(title: String, artist: String, durationSec: Long): Result? = withContext(Dispatchers.IO) {
        val (t, a) = MetaCleaner.clean(title, artist)
        val track = t.ifBlank { title }
        val key = "$track|$a"
        cache.get(key)?.let { return@withContext it }

        // 1) ricerca esatta (titolo + artista + durata)
        var res: Result? = null
        if (a.isNotBlank()) {
            val url = "https://lrclib.net/api/get?track_name=${Uri.encode(track)}&artist_name=${Uri.encode(a)}" +
                if (durationSec > 0) "&duration=$durationSec" else ""
            res = call(url)?.let { parse(JSONObject(it)) }
        }
        // 2) ricerca libera: sceglie la durata più vicina, preferendo i testi sincronizzati
        if (res == null || res.isEmpty) {
            val body = call("https://lrclib.net/api/search?q=${Uri.encode("$track $a".trim())}")
            if (body != null) {
                val arr = JSONArray(body)
                val items = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                val best = items
                    .filter { durationSec <= 0 || abs(it.optDouble("duration", 0.0) - durationSec) <= 8 }
                    .sortedByDescending { if (it.optString("syncedLyrics").isNotBlank()) 1 else 0 }
                    .firstOrNull()
                res = best?.let { parse(it) }
            }
        }
        if (res != null && !res.isEmpty) cache.put(key, res)
        res?.takeIf { !it.isEmpty }
    }

    private fun call(url: String): String? = runCatching {
        Http.client.newCall(Request.Builder().url(url).header("User-Agent", UA).build()).execute().use { r ->
            if (r.isSuccessful) r.body?.string() else null
        }
    }.getOrNull()

    private fun parse(o: JSONObject): Result? {
        if (o.optBoolean("instrumental")) return Result(emptyList(), "♪ Brano strumentale")
        val synced = parseLrc(o.optString("syncedLyrics").takeIf { it != "null" }.orEmpty())
        val plain = o.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
        return Result(synced, plain)
    }

    private val TAG = Regex("""\[(\d+):(\d+)(?:[.:](\d+))?]""")

    /** Formato LRC: "[01:23.45] testo"; più tag sulla stessa riga sono ammessi. */
    fun parseLrc(s: String): List<Line> {
        val out = mutableListOf<Line>()
        s.lineSequence().forEach { raw ->
            val tags = TAG.findAll(raw).toList()
            if (tags.isEmpty()) return@forEach
            val text = raw.substring(tags.last().range.last + 1).trim()
            tags.forEach { m ->
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out += Line(min * 60_000 + sec * 1000 + ms, text)
            }
        }
        return out.sortedBy { it.ms }
    }
}
