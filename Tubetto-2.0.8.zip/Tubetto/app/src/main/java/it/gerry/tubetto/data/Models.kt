package it.gerry.tubetto.data

enum class ItemKind { VIDEO, PLAYLIST, CHANNEL, ARTIST, HEADER }

data class VideoItem(
    /** videoId per i video, playlistId per le playlist. */
    val id: String,
    val title: String,
    val author: String,
    /** Durata, "LIVE" o, per le playlist, il numero di elementi. */
    val duration: String,
    val views: String = "",
    val published: String = "",
    val description: String = "",
    val channelAvatar: String? = null,
    val thumbnailUrl: String? = null,
    val kind: ItemKind = ItemKind.VIDEO,
    /** Canale che ha pubblicato il video (per "Vai al canale"). */
    val channelId: String? = null,
) {
    val thumbnail: String get() = thumbnailUrl ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"
}

data class ResolvedStream(
    val videoId: String,
    val title: String,
    val author: String,
    val thumbnail: String,
    val durationMs: Long,
    /** Video-only mp4 (oppure muxed se audioUrl == null). */
    val videoUrl: String?,
    /** Audio-only m4a/webm. */
    val audioUrl: String?,
    /** Per le dirette. */
    val hlsUrl: String?,
    /** Sorgente usata, es. "innertube:IOS" o "newpipe:muxed". */
    val source: String,
    /** Manifest DASH generato: qualità adattiva (parte bassa, poi sale). */
    val dashManifest: String? = null,
) {
    val isMuxed: Boolean get() = videoUrl != null && audioUrl == null && hlsUrl == null && dashManifest == null
}
