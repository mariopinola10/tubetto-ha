package it.gerry.tubetto.data

import android.content.Context
import android.os.Build
import android.util.Base64
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import it.gerry.tubetto.update.UpdatePrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * "Stesso account" su telefono, tablet e Fire TV: preferiti, playlist, artisti, canali
 * e cronologia vengono salvati in un file JSON nel repository GitHub privato
 * (sync/tubetto-library.json) usando lo stesso utente/repo/token degli aggiornamenti.
 *
 * Regole: la libreria più recente vince (così anche le cancellazioni si propagano);
 * la cronologia invece si unisce. Il file è fuori dagli zip, quindi non avvia build.
 */
object SyncManager {

    private const val PATH = "sync/tubetto-library.json"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var pending: Job? = null
    private lateinit var app: Context

    /** Nel file c'è un accesso YouTube ma su questo dispositivo manca (o è sbagliato) il codice. */
    @Volatile var accountCodeMissing = false

    @Volatile var lastStatus: String = "Mai sincronizzato"
        private set

    fun init(context: Context) {
        app = context.applicationContext
        Library.onChanged = { schedule(15_000) }
        ListenHistory.onChanged = { schedule(120_000) }
        Radio.onChanged = { schedule(15_000) }
    }

    /**
     * Dove sincronizzare: il repo personale dell'utente (Impostazioni → Sincronizza i tuoi dispositivi)
     * oppure, per l'amministratore, lo stesso repo/token degli aggiornamenti.
     */
    private fun target(): Pair<String, String>? {
        val own = OwnSync(app)
        if (own.isConfigured) return own.repo to own.token
        val p = UpdatePrefs(app)
        return if (p.isConfigured && p.token.isNotBlank()) p.repo to p.token else null
    }

    fun enabled(): Boolean = ::app.isInitialized && UpdatePrefs(app).syncEnabled && target() != null

    /** Invio differito: raggruppa più modifiche in un solo salvataggio. */
    fun schedule(delayMs: Long) {
        if (!::app.isInitialized || !enabled()) return
        if (pending?.isActive == true) return
        pending = scope.launch {
            delay(delayMs)
            runCatching { sync() }
        }
    }

    /** Invia subito le modifiche in sospeso (es. uscendo dall'app). */
    fun flush() {
        if (!::app.isInitialized || !enabled() || pending?.isActive != true) return
        pending?.cancel()
        pending = scope.launch { runCatching { sync() } }
    }

    /**
     * Scarica, unisce e carica.
     * @return true se la libreria locale è cambiata (la UI va aggiornata).
     */
    suspend fun sync(): Boolean = withContext(Dispatchers.IO) {
        if (!enabled()) return@withContext false
        mutex.withLock {
            accountCodeMissing = false
            var libraryChanged = false
            repeat(2) { attempt ->
                val remote = download()
                val remoteJson = remote?.first
                var historyChanged = false
                if (remoteJson != null) {
                    val lib = remoteJson.optJSONObject("library")
                    if (lib != null && lib.optLong("modified") > Library.modified) {
                        Library.importJson(lib)
                        libraryChanged = true
                    }
                    remoteJson.optJSONArray("history")?.let { historyChanged = ListenHistory.mergeJson(it) }
                    remoteJson.optJSONObject("radios")?.let { if (Radio.importJson(it)) libraryChanged = true }
                    remoteJson.optJSONObject("account")?.let { acc ->
                        when (Account.importEncrypted(acc)) {
                            true -> Diagnostics.log("Sync: accesso YouTube ricevuto da un altro dispositivo")
                            null -> accountCodeMissing = true
                            false -> Unit
                        }
                    }
                }

                val localLib = Library.exportJson()
                val localHist = ListenHistory.exportJson()
                val needUpload = remoteJson == null ||
                    Library.modified > (remoteJson.optJSONObject("library")?.optLong("modified") ?: 0L) ||
                    historyChanged ||
                    localHist.toString() != remoteJson.optJSONArray("history")?.toString() ||
                    Radio.modified > (remoteJson.optJSONObject("radios")?.optLong("modified") ?: 0L) ||
                    (Account.syncCode.isNotBlank() && Account.updatedAt > (remoteJson.optJSONObject("account")?.optLong("updated") ?: 0L))
                if (!needUpload) {
                    lastStatus = "Sincronizzato ✓ ${time()}"
                    return@withLock libraryChanged
                }
                val payload = JSONObject()
                    .put("version", 1)
                    .put("device", Build.MODEL)
                    .put("updated", System.currentTimeMillis())
                    .put("library", localLib)
                    .put("history", localHist)
                    .put("radios", Radio.exportJson())
                // accesso: il nostro se più recente, altrimenti si conserva quello già nel file
                val remoteAcc = remoteJson?.optJSONObject("account")
                val localAcc = if (Account.syncCode.isNotBlank()) Account.exportEncrypted() else null
                when {
                    localAcc != null && localAcc.optLong("updated") >= (remoteAcc?.optLong("updated") ?: 0L) -> payload.put("account", localAcc)
                    remoteAcc != null -> payload.put("account", remoteAcc)
                }
                val ok = upload(payload, remote?.second)
                if (ok) {
                    lastStatus = "Sincronizzato ✓ ${time()}"
                    Diagnostics.log("Sync: libreria salvata su GitHub")
                    return@withLock libraryChanged
                }
                if (attempt == 1) throw IOException("conflitto ripetuto")
                // conflitto: un altro dispositivo ha appena salvato, riprova con la versione nuova
            }
            libraryChanged
        }
    }

    private fun time() = java.text.SimpleDateFormat("HH:mm", java.util.Locale.ITALY).format(java.util.Date())

    private fun url(): String = "https://api.github.com/repos/${target()?.first}/contents/$PATH"

    private fun Request.Builder.auth(): Request.Builder = apply {
        header("Authorization", "Bearer ${target()?.second.orEmpty()}")
        header("Accept", "application/vnd.github+json")
        header("X-GitHub-Api-Version", "2022-11-28")
    }

    /** @return contenuto e sha del file, null se non esiste ancora. */
    private fun download(): Pair<JSONObject, String>? {
        Http.client.newCall(Request.Builder().url(url()).auth().build()).execute().use { r ->
            if (r.code == 404) return null
            if (!r.isSuccessful) {
                lastStatus = "Errore lettura GitHub (HTTP ${r.code})"
                throw IOException(lastStatus)
            }
            val o = JSONObject(r.body!!.string())
            val content = String(Base64.decode(o.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
            return JSONObject(content) to o.getString("sha")
        }
    }

    /** @return false in caso di conflitto (il file è cambiato nel frattempo). */
    private fun upload(payload: JSONObject, sha: String?): Boolean {
        val body = JSONObject()
            .put("message", "Tubetto sync da ${Build.MODEL}")
            .put("content", Base64.encodeToString(payload.toString().toByteArray(), Base64.NO_WRAP))
        if (sha != null) body.put("sha", sha)
        val req = Request.Builder().url(url()).auth()
            .put(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        Http.client.newCall(req).execute().use { r ->
            return when {
                r.isSuccessful -> true
                r.code == 409 || r.code == 422 -> false
                r.code == 403 || r.code == 404 -> {
                    lastStatus = "Il token non può scrivere nel repo: serve \"Contents: Read and write\""
                    throw IOException(lastStatus)
                }
                else -> {
                    lastStatus = "Errore salvataggio GitHub (HTTP ${r.code})"
                    throw IOException(lastStatus)
                }
            }
        }
    }
}

/** Sincronizzazione personale di un utente qualsiasi: il suo repo GitHub privato e il suo token. */
class OwnSync(context: Context) {
    private val sp = context.getSharedPreferences("own_sync", Context.MODE_PRIVATE)

    var repo: String
        get() = sp.getString("repo", "").orEmpty()
        set(v) = sp.edit().putString("repo", v.trim()).apply()

    var token: String
        get() = sp.getString("token", "").orEmpty()
        set(v) = sp.edit().putString("token", v.trim()).apply()

    val isConfigured: Boolean get() = repo.contains('/') && token.isNotBlank()

    /** Accetta "utente/repo" o il link del repo. */
    fun setRepo(input: String): Boolean {
        val m = Regex("""(?:github\.com/)?([A-Za-z0-9-]+)/([A-Za-z0-9._-]+)""").find(input.trim()) ?: return false
        repo = m.groupValues[1] + "/" + m.groupValues[2].removeSuffix(".git")
        return true
    }

    fun clear() = sp.edit().clear().apply()
}
