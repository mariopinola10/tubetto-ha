package it.gerry.tubetto.playback

import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Segmenti da saltare dal database comunitario SponsorBlock:
 * per la musica intro parlate, parti non musicali dei videoclip, sponsor, finali con titoli.
 * Per privacy si invia solo l'inizio dell'hash dell'ID video, non l'ID.
 */
object SponsorBlock {

    data class Segment(val startMs: Long, val endMs: Long, val category: String)

    /** Attivabile/disattivabile da Impostazioni (attivo di default). */
    fun enabled(ctx: android.content.Context): Boolean =
        ctx.getSharedPreferences("playback", android.content.Context.MODE_PRIVATE).getBoolean("sponsorblock", true)

    fun setEnabled(ctx: android.content.Context, on: Boolean) =
        ctx.getSharedPreferences("playback", android.content.Context.MODE_PRIVATE).edit().putBoolean("sponsorblock", on).apply()

    private val MUSIC = listOf("music_offtopic", "intro", "sponsor", "selfpromo", "outro")
    private val VIDEO = listOf("sponsor", "selfpromo")
    private val cache = HashMap<String, List<Segment>>()

    suspend fun segments(videoId: String, music: Boolean): List<Segment> = withContext(Dispatchers.IO) {
        val key = "$videoId|$music"
        synchronized(cache) { cache[key] }?.let { return@withContext it }
        val cats = if (music) MUSIC else VIDEO
        val prefix = sha256(videoId).take(4)
        val catsParam = URLEncoder.encode(JSONArray(cats).toString(), "UTF-8")
        val url = "https://sponsor.ajay.app/api/skipSegments/$prefix?categories=$catsParam&actionType=skip"
        val result = runCatching {
            Http.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.code == 404) return@use emptyList()
                if (!r.isSuccessful) return@use emptyList()
                val arr = JSONArray(r.body?.string().orEmpty())
                val out = mutableListOf<Segment>()
                for (i in 0 until arr.length()) {
                    val v = arr.getJSONObject(i)
                    if (v.optString("videoID") != videoId) continue
                    val segs = v.optJSONArray("segments") ?: continue
                    for (j in 0 until segs.length()) {
                        val s = segs.getJSONObject(j)
                        val range = s.optJSONArray("segment") ?: continue
                        val a = (range.optDouble(0) * 1000).toLong()
                        val b = (range.optDouble(1) * 1000).toLong()
                        if (b - a >= 1000) out += Segment(a, b, s.optString("category"))
                    }
                }
                out.sortedBy { it.startMs }
            }
        }.getOrElse {
            Diagnostics.log("SponsorBlock non raggiungibile: ${it.message}")
            emptyList()
        }
        synchronized(cache) { cache[key] = result }
        result
    }

    private fun sha256(s: String) =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
