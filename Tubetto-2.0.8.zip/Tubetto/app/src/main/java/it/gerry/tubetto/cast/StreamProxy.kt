package it.gerry.tubetto.cast

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.okhttp.OkHttpDataSource
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.data.StreamResolver
import it.gerry.tubetto.data.YouTubeApiHelper
import it.gerry.tubetto.net.Http
import it.gerry.tubetto.net.YouTubeChunkedDataSource
import kotlinx.coroutines.runBlocking
import java.io.IOException
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Mini server HTTP sul telefono: la TV chiede lo stream al telefono, che lo scarica
 * da YouTube con User-Agent e blocchi corretti.
 * Se YouTube interrompe il link a metà (403/scadenza), il proxy ottiene un nuovo link
 * per lo stesso video e riprende dallo stesso byte, senza che la TV se ne accorga.
 */
@OptIn(UnstableApi::class)
object StreamProxy {

    private class Route(@Volatile var url: String, @Volatile var source: String?, val videoId: String?)

    private var server: ServerSocket? = null
    private val routes = ConcurrentHashMap<String, Route>()
    private val pool = Executors.newCachedThreadPool()
    private val resolver by lazy { StreamResolver(YouTubeApiHelper()) }

    @Synchronized
    private fun start(): Int {
        server?.takeIf { !it.isClosed }?.let { return it.localPort }
        val s = ServerSocket(0)
        server = s
        thread(isDaemon = true, name = "tubetto-proxy") {
            while (!s.isClosed) {
                val c = runCatching { s.accept() }.getOrNull() ?: break
                pool.execute { runCatching { handle(c) }.onFailure { Diagnostics.log("Proxy: ${it.message}") } }
            }
        }
        return s.localPort
    }

    /**
     * Pubblica un URL e restituisce l'indirizzo locale da dare alla TV.
     * Con [videoId] il proxy può rinnovare il link da solo se YouTube lo interrompe.
     */
    fun publish(upstreamUrl: String, ext: String, videoId: String? = null, source: String? = null): String {
        val port = start()
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        routes[token] = Route(upstreamUrl, source, videoId)
        return "http://${localIp()}:$port/s/$token.$ext"
    }

    private fun handle(sock: Socket) {
        sock.use { s -> serve(s) }
    }

    private fun serve(s: Socket) {
        s.soTimeout = 60_000
        val input = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
        val requestLine = input.readLine() ?: return
        val parts = requestLine.split(" ")
        val method = parts.getOrElse(0) { "GET" }
        val path = parts.getOrElse(1) { "/" }
        val headers = HashMap<String, String>()
        while (true) {
            val line = input.readLine() ?: break
            if (line.isEmpty()) break
            val i = line.indexOf(':')
            if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }

        val out = s.getOutputStream()
        val token = path.removePrefix("/s/").substringBefore('.').substringBefore('?')
        val route = routes[token]
        if (route == null) {
            writeHead(out, 404, "Not Found", emptyMap())
            return
        }

        val uri = Uri.parse(route.url)
        val total = uri.getQueryParameter("clen")?.toLongOrNull()
        if (total == null) {
            writeHead(out, 502, "Bad Gateway", emptyMap())
            return
        }
        val mime = uri.getQueryParameter("mime") ?: "video/mp4"

        var start = 0L
        var end = total - 1
        val range = headers["range"]
        val partial = range != null && range.startsWith("bytes=")
        if (partial) {
            val r = range!!.removePrefix("bytes=").substringBefore(',')
            val a = r.substringBefore('-')
            val b = r.substringAfter('-', "")
            if (a.isEmpty()) {
                start = (total - (b.toLongOrNull() ?: total)).coerceAtLeast(0)
            } else {
                start = a.toLongOrNull() ?: 0
                b.toLongOrNull()?.let { end = minOf(it, total - 1) }
            }
        }
        if (start >= total) {
            writeHead(out, 416, "Range Not Satisfiable", mapOf("Content-Range" to "bytes */$total"))
            return
        }
        val length = end - start + 1

        val h = linkedMapOf(
            "Content-Type" to mime,
            "Content-Length" to length.toString(),
            "Accept-Ranges" to "bytes",
            "transferMode.dlna.org" to "Streaming",
            "contentFeatures.dlna.org" to "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000",
        )
        if (partial) h["Content-Range"] = "bytes $start-$end/$total"
        writeHead(out, if (partial) 206 else 200, if (partial) "Partial Content" else "OK", h)
        if (method == "HEAD") return

        var pos = start
        var renewals = 0
        val buf = ByteArray(64 * 1024)
        while (pos <= end) {
            val ds = YouTubeChunkedDataSource(OkHttpDataSource.Factory(Http.streamClient).createDataSource())
            try {
                ds.open(DataSpec.Builder().setUri(Uri.parse(route.url)).setPosition(pos).setLength(end - pos + 1).build())
                while (pos <= end) {
                    val n = ds.read(buf, 0, buf.size)
                    if (n == C.RESULT_END_OF_INPUT) break
                    try {
                        out.write(buf, 0, n)
                    } catch (e: IOException) {
                        // La TV ha chiuso la connessione (seek, stop o nuova richiesta): normale
                        return
                    }
                    pos += n
                }
                if (pos <= end) throw IOException("stream terminato prima del previsto a $pos/$total")
            } catch (e: IOException) {
                if (pos > end) break
                Diagnostics.log("Proxy: interruzione a ${pos / 1_048_576} MB (${e.message?.take(80)})")
                if (route.videoId == null || renewals >= 4 || !renew(route, total)) {
                    Diagnostics.log("Proxy: impossibile riprendere ${route.videoId}")
                    return
                }
                renewals++
            } finally {
                runCatching { ds.close() }
            }
        }
        runCatching { out.flush() }
    }

    /** Nuovo link per lo stesso video e lo stesso file (stessa dimensione), poi si riprende. */
    private fun renew(route: Route, total: Long): Boolean {
        val id = route.videoId ?: return false
        val exclude = setOfNotNull(route.source)
        val fresh = runCatching {
            runBlocking { resolver.resolve(id, audioOnly = false, exclude = exclude, muxedOnly = true) }
        }.getOrNull() ?: runCatching {
            runBlocking { resolver.resolve(id, audioOnly = false, muxedOnly = true) }
        }.getOrNull() ?: return false
        val url = fresh.videoUrl ?: return false
        val clen = Uri.parse(url).getQueryParameter("clen")?.toLongOrNull()
        if (clen != total) {
            Diagnostics.log("Proxy: nuovo link di dimensione diversa ($clen ≠ $total), non riprendibile")
            return false
        }
        route.url = url
        route.source = fresh.source
        Diagnostics.log("Proxy: link rinnovato via ${fresh.source}, riprendo")
        return true
    }

    private fun writeHead(out: OutputStream, code: Int, msg: String, headers: Map<String, String>) {
        val sb = StringBuilder("HTTP/1.1 $code $msg\r\n")
        headers.forEach { (k, v) -> sb.append(k).append(": ").append(v).append("\r\n") }
        if (!headers.containsKey("Content-Length")) sb.append("Content-Length: 0\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    /** IPv4 della rete locale (preferisce il Wi-Fi). */
    fun localIp(): String =
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress ?: "127.0.0.1"
}
