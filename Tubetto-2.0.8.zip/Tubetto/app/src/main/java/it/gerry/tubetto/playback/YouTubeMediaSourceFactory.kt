package it.gerry.tubetto.playback

import android.net.Uri
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import it.gerry.tubetto.data.ResolvedStream
import java.io.ByteArrayInputStream

/**
 * Crea la sorgente giusta per ogni elemento:
 * - manifest DASH negli extras → qualità adattiva
 * - URL audio separato negli extras → video-only + audio uniti
 * - altrimenti la sorgente standard (progressivo, HLS, URL pigro tubetto://).
 */
@OptIn(UnstableApi::class)
class YouTubeMediaSourceFactory(
    private val delegate: DefaultMediaSourceFactory,
    private val dataSourceFactory: DataSource.Factory,
) : MediaSource.Factory {

    private var drmProvider: DrmSessionManagerProvider? = null
    private var errorPolicy: LoadErrorHandlingPolicy? = null

    override fun setDrmSessionManagerProvider(provider: DrmSessionManagerProvider): MediaSource.Factory = apply {
        drmProvider = provider
        delegate.setDrmSessionManagerProvider(provider)
    }

    override fun setLoadErrorHandlingPolicy(policy: LoadErrorHandlingPolicy): MediaSource.Factory = apply {
        errorPolicy = policy
        delegate.setLoadErrorHandlingPolicy(policy)
    }

    override fun getSupportedTypes(): IntArray = delegate.supportedTypes

    override fun createMediaSource(mediaItem: MediaItem): MediaSource {
        val extras = mediaItem.requestMetadata.extras

        extras?.getString(EXTRA_DASH)?.let { mpd ->
            val manifest = DashManifestParser().parse(
                Uri.parse("https://tubetto.local/manifest.mpd"),
                ByteArrayInputStream(mpd.toByteArray()),
            )
            val f = DashMediaSource.Factory(dataSourceFactory)
            drmProvider?.let { f.setDrmSessionManagerProvider(it) }
            errorPolicy?.let { f.setLoadErrorHandlingPolicy(it) }
            return f.createMediaSource(manifest, mediaItem)
        }

        val main = delegate.createMediaSource(mediaItem)
        val audioUrl = extras?.getString(EXTRA_AUDIO_URL) ?: return main
        val audio = ProgressiveMediaSource.Factory(dataSourceFactory)
            .createMediaSource(MediaItem.fromUri(audioUrl))
        return MergingMediaSource(/* adjustPeriodTimeOffsets = */ true, /* clipDurations = */ true, main, audio)
    }

    companion object {
        const val EXTRA_AUDIO_URL = "tubetto.audio_url"
        const val EXTRA_DASH = "tubetto.dash"
        const val EXTRA_SOURCE = "tubetto.source"
        const val EXTRA_AUDIO_ONLY = "tubetto.audio_only"

        /** MediaItem riproducibile da uno stream risolto (usato da telefono e ricevitore TV). */
        fun mediaItemFor(s: ResolvedStream, metadata: MediaMetadata, extras: Bundle = Bundle()): MediaItem {
            val b = MediaItem.Builder().setMediaId(s.videoId)
            when {
                s.hlsUrl != null -> b.setUri(s.hlsUrl).setMimeType(MimeTypes.APPLICATION_M3U8)
                s.dashManifest != null -> {
                    extras.putString(EXTRA_DASH, s.dashManifest)
                    b.setUri("https://tubetto.local/dash/${s.videoId}.mpd").setMimeType(MimeTypes.APPLICATION_MPD)
                }
                else -> {
                    if (s.videoUrl != null && s.audioUrl != null) extras.putString(EXTRA_AUDIO_URL, s.audioUrl)
                    b.setUri(s.videoUrl ?: s.audioUrl)
                }
            }
            extras.putString(EXTRA_SOURCE, s.source)
            return b.setRequestMetadata(MediaItem.RequestMetadata.Builder().setExtras(extras).build())
                .setMediaMetadata(metadata)
                .build()
        }
    }
}
