package it.gerry.tubetto.playback

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import androidx.media3.session.CommandButton
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionError
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.data.ArtistImages
import it.gerry.tubetto.data.Charts
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.Library
import it.gerry.tubetto.data.MetaCleaner
import it.gerry.tubetto.data.ListenHistory
import it.gerry.tubetto.data.Recommender
import it.gerry.tubetto.data.ResolvedStream
import it.gerry.tubetto.data.StreamResolver
import it.gerry.tubetto.data.Recents
import it.gerry.tubetto.data.Radio
import it.gerry.tubetto.data.LoginRequiredException
import it.gerry.tubetto.data.VideoItem
import it.gerry.tubetto.data.YouTubeApiHelper
import it.gerry.tubetto.net.Http
import it.gerry.tubetto.net.YouTubeChunkedDataSource
import it.gerry.tubetto.playback.YouTubeMediaSourceFactory.Companion.EXTRA_AUDIO_ONLY
import it.gerry.tubetto.playback.YouTubeMediaSourceFactory.Companion.EXTRA_AUDIO_URL
import it.gerry.tubetto.playback.YouTubeMediaSourceFactory.Companion.EXTRA_SOURCE
import it.gerry.tubetto.ui.Collage
import it.gerry.tubetto.ui.DeviceProfile
import it.gerry.tubetto.ui.ShelfAdapter
import it.gerry.tubetto.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.cancel
import kotlinx.coroutines.guava.future
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.concurrent.ConcurrentHashMap

/**
 * ForegroundService + MediaSession: notifica persistente, riproduzione in background,
 * Android Auto (MediaBrowserServiceCompat legacy esposto da Media3).
 *
 * ID media:
 *  - "<videoId>"            video completo (risolto subito)
 *  - "a:<videoId>"          brano solo audio, risolto al momento della riproduzione (code/playlist)
 *  - "plt:<plId>:<videoId>" brano dentro una playlist (Android Auto): avvia tutta la playlist
 *  - "pl:<plId>"            cartella playlist (Android Auto)
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaLibraryService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val api = YouTubeApiHelper()
    private val resolver = StreamResolver(api)

    private lateinit var player: ExoPlayer
    private lateinit var focus: FocusManager
    private val fx = AudioFx()
    private var audioPrefsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var session: MediaLibrarySession? = null

    private val recommender by lazy { Recommender(api) }
    private var radioPending = false

    /** Segmenti da saltare per il brano in corso (intro, parti non musicali, sponsor). */
    @Volatile private var skipSegments: List<SponsorBlock.Segment> = emptyList()
    private var skipFor: String? = null
    private val skipHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val skipTick = object : Runnable {
        override fun run() {
            checkSkip()
            skipHandler.postDelayed(this, 400)
        }
    }
    private val browseCache = ConcurrentHashMap<String, List<MediaItem>>()

    /** Liste sfogliate in auto: toccando un brano parte tutta la lista da quel punto. */
    private val queueCache = ConcurrentHashMap<String, List<VideoItem>>()
    private val timedCache = ConcurrentHashMap<String, Pair<Long, List<VideoItem>>>()

    /** Stream audio già risolti per gli elementi "a:" (risoluzione pigra). */
    private val lazyCache = ConcurrentHashMap<String, ResolvedStream>()

    /** Sorgenti fallite in riproduzione, per video. */
    private val failedSources = ConcurrentHashMap<String, MutableSet<String>>()

    /** Tentativi di recupero per video: oltre il limite si passa al successivo invece di bloccarsi. */
    private val retryCount = ConcurrentHashMap<String, Int>()
    private val lastErrorAt = ConcurrentHashMap<String, Long>()

    override fun onCreate() {
        super.onCreate()

        val chunked = YouTubeChunkedDataSource.Factory(OkHttpDataSource.Factory(Http.streamClient))

        // tubetto://audio/<id> -> URL reale, risolto solo quando il brano sta per suonare
        val lazy = ResolvingDataSource.Factory(chunked, ResolvingDataSource.Resolver { spec ->
            if (spec.uri.scheme != LAZY_SCHEME) return@Resolver spec
            val id = spec.uri.lastPathSegment ?: return@Resolver spec
            if (spec.uri.host == "video") {
                // Ripiego finché il service non sostituisce l'elemento con la versione adattiva
                val v = runBlocking {
                    resolver.resolve(id, audioOnly = false, exclude = failedSources[id].orEmpty().toSet(), muxedOnly = true)
                }
                mainHandler.post { fillMetadata(id, v) }
                return@Resolver spec.withUri(Uri.parse(v.videoUrl ?: throw java.io.IOException("Diretta: apri il video singolo")))
            }
            val s = lazyCache[id] ?: runBlocking {
                resolver.audioMaxKbps = AudioPrefs.maxAudioKbps(this@PlaybackService)
                resolver.resolve(id, audioOnly = true, exclude = failedSources[id].orEmpty().toSet())
            }.also {
                lazyCache[id] = it
                mainHandler.post { fillMetadata(id, it) }
            }
            spec.withUri(Uri.parse(s.audioUrl ?: s.videoUrl ?: s.hlsUrl))
        })

        val sourceFactory = YouTubeMediaSourceFactory(
            DefaultMediaSourceFactory(this).setDataSourceFactory(lazy),
            lazy,
        )

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(sourceFactory)
            .setLoadControl(Buffering.loadControl(it.gerry.tubetto.ui.DeviceProfile.kind(this) == it.gerry.tubetto.ui.DeviceProfile.Kind.TV))
            .setBandwidthMeter(Buffering.bandwidthMeter(this))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ false, // gestito da FocusManager: le notifiche non fermano la musica
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        // Casuale "fisico": l'ordine della coda è quello che si vede ("Poi:" giusto, ⏮ torna al precedente vero).
        // Con l'ordine casuale interno di ExoPlayer, ogni sostituzione di un brano (link aggiornati) rimescolava
        // la coda: si saltavano 2-3 brani e "indietro" andava a caso.
        player.setShuffleOrder(androidx.media3.exoplayer.source.ShuffleOrder.UnshuffledShuffleOrder(0))
        focus = FocusManager(this, player)

        // Profilo sonoro (bassi/alti + compressione) applicato alla sessione audio del player
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                fx.apply(audioSessionId, AudioPrefs.profile(this@PlaybackService))
            }
        })
        fx.apply(player.audioSessionId, AudioPrefs.profile(this))
        audioPrefsListener = AudioPrefs.register(this) {
            mainHandler.post { fx.apply(player.audioSessionId, AudioPrefs.profile(this)) }
            lazyCache.clear() // nuova qualità dal prossimo brano
        }

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // il controllo riguarda il brano che ha dato errore, non quello su cui si arriva dopo il recupero
                val failed = player.currentMediaItem?.mediaId
                val failedIndex = player.currentMediaItemIndex
                recoverFromError(error)
                armErrorWatchdog(failed, failedIndex)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // nel log: perché si è passati a questo brano (per capire salti inattesi)
                val why = when (reason) {
                    Player.MEDIA_ITEM_TRANSITION_REASON_AUTO -> "fine brano"
                    Player.MEDIA_ITEM_TRANSITION_REASON_SEEK -> "avanti/indietro"
                    Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT -> "ripeti"
                    else -> "nuova coda"
                }
                Diagnostics.log(
                    "▶ ${player.currentMediaItemIndex + 1}/${player.mediaItemCount} " +
                        "${mediaItem?.mediaMetadata?.title ?: "?"} ($why${if (player.shuffleModeEnabled) ", casuale" else ""})"
                )
                mediaItem?.let { recordListen(it) }
                mediaItem?.mediaId?.takeIf { it.startsWith(Q_PREFIX) }?.let { mid ->
                    val k = queueKeyOf(mid)
                    when {
                        k.startsWith(LPL_PREFIX) -> Recents.touch(Recents.playlistKey(Library.LOCAL_PREFIX + k.removePrefix(LPL_PREFIX)))
                        k.startsWith(ART_PREFIX) -> Recents.touch(Recents.artistKey(k.removePrefix(ART_PREFIX)))
                        k.startsWith(PL_PREFIX) -> Recents.touch(Recents.playlistKey(k.removePrefix(PL_PREFIX)))
                    }
                }
                extendRadio()
                loadSkipSegments(mediaItem)
                upgradeVideo(player.currentMediaItemIndex)
                upgradeVideo(player.currentMediaItemIndex + 1)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                skipHandler.removeCallbacks(skipTick)
                if (isPlaying) {
                    skipHandler.post(skipTick)
                    extendRadio()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                // Se è finito tutto ma la radio sta ancora caricando, riparte appena arrivano i nuovi elementi
                if (playbackState == Player.STATE_ENDED && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.play()
                }
            }

            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                if (player.playbackState == Player.STATE_ENDED && player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
        })

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        session = MediaLibrarySession.Builder(this, player, LibraryCallback())
            .setSessionActivity(openApp)
            .setMediaButtonPreferences(mediaButtons())
            .build()

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refreshButtons()
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                if (shuffleModeEnabled) shuffleRemaining()
                refreshButtons()
            }
        })
    }

    /** Su errore HTTP segna la sorgente come fallita, ne cerca un'altra e riprende dallo stesso punto. */
    /** Rimescola davvero i brani DOPO quello in ascolto (quelli prima restano "precedenti"). */
    private fun shuffleRemaining() {
        val cur = player.currentMediaItemIndex
        val n = player.mediaItemCount
        if (n - cur <= 2) return
        val target = (cur + 1 until n).shuffled()
        // order[i] = indice originale dell'elemento che ora sta in posizione i
        val order = (0 until n).toMutableList()
        target.forEachIndexed { k, orig ->
            val to = cur + 1 + k
            val from = order.indexOf(orig)
            if (from != to) {
                player.moveMediaItem(from, to)
                order.add(to, order.removeAt(from))
            }
        }
        Diagnostics.log("Casuale: rimescolati ${n - cur - 1} brani dopo quello in ascolto")
    }

    private val watchdogHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var watchdogItem: String? = null

    /**
     * Rete di sicurezza: se 15 s dopo un errore il player è ancora fermo in errore sullo stesso brano
     * (es. "Source error" in Android Auto), si passa al successivo; se la coda è finita si aggiungono
     * brani consigliati. Mai restare senza musica.
     */
    private fun armErrorWatchdog(mid: String?, index: Int) {
        mid ?: return
        watchdogItem = mid
        watchdogHandler.removeCallbacksAndMessages(null)
        watchdogHandler.postDelayed({
            // salta SOLO se si è ancora fermi in errore sullo stesso brano (stessa posizione in coda)
            val same = player.currentMediaItem?.mediaId == watchdogItem && player.currentMediaItemIndex == index
            if (same && player.playerError != null && !player.isPlaying) {
                Diagnostics.log("Brano bloccato in errore ($mid): passo avanti")
                skipOrContinue()
            }
        }, 15_000)
    }

    private var lastSkipAt = 0L

    /** Successivo; a fine coda brani consigliati (anche con la riproduzione automatica spenta). */
    private fun skipOrContinue() {
        // due recuperi per lo stesso errore non devono saltare due brani
        val now = System.currentTimeMillis()
        if (now - lastSkipAt < 4_000) return
        lastSkipAt = now
        Diagnostics.log("Passo al brano successivo")
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
            player.prepare()
            player.play()
            return
        }
        val current = player.currentMediaItem
        scope.launch {
            val seed = current?.let { videoIdOf(it.mediaId) }
            val more = runCatching {
                val similar = if (seed != null && !Radio.isRadio(seed)) api.related(seed, music = true).filter { it.kind == ItemKind.VIDEO } else emptyList()
                similar.ifEmpty { recommender.musicForYou().items }
            }.getOrDefault(emptyList()).take(20)
            if (more.isEmpty()) return@launch
            player.addMediaItems(more.map { lazyAudio(it.id, it.toMetadata()) })
            Diagnostics.log("Coda finita dopo un errore: aggiunti ${more.size} brani consigliati")
            player.seekToNextMediaItem()
            player.prepare()
            player.play()
        }
    }

    private fun recoverFromError(error: PlaybackException) {
        val item = player.currentMediaItem ?: return
        val http = generateSequence(error.cause) { it.cause }
            .filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
            .firstOrNull()
        val isLazy = item.localConfiguration?.uri?.scheme == LAZY_SCHEME
        val id = videoIdOf(item.mediaId)
        val source = if (isLazy) lazyCache.remove(id)?.source else item.requestMetadata.extras?.getString(EXTRA_SOURCE)

        Diagnostics.log(
            "ERR ${error.errorCodeName} http=${http?.responseCode} " +
                "c=${http?.dataSpec?.uri?.getQueryParameter("c")} src=$source id=$id"
        )
        val index = player.currentMediaItemIndex
        val position = player.currentPosition
        if (generateSequence(error as Throwable) { t -> t.cause }.any { t -> t is LoginRequiredException }) {
            // video con limiti di età / riservato: nessun tentativo, subito il prossimo
            failedSources.remove(id)
            retryCount.remove(id)
            skipOrContinue()
            return
        }
        // Se l'ultimo errore è di oltre 3 minuti fa il video stava andando bene: si riparte da zero
        val nowMs = System.currentTimeMillis()
        if (nowMs - (lastErrorAt[id] ?: 0L) > 180_000L) retryCount.remove(id)
        lastErrorAt[id] = nowMs
        val attempts = (retryCount[id] ?: 0) + 1
        retryCount[id] = attempts
        if (attempts > 6) {
            // Dopo vari tentativi non resta bloccato: passa al prossimo brano
            Diagnostics.log("Salto $id dopo ${attempts - 1} tentativi")
            retryCount.remove(id)
            failedSources.remove(id)
            skipOrContinue()
            return
        }
        resolver.invalidate(id)

        if (source == null) {
            // La risoluzione stessa è fallita (tutte le sorgenti escluse o link scaduti):
            // si riparte da zero con link nuovi, dallo stesso punto.
            if (!isLazy) return
            failedSources.remove(id)
            Diagnostics.log("Richiedo link nuovi per $id (tentativo $attempts)")
            scope.launch {
                kotlinx.coroutines.delay(1500L * attempts)
                player.seekTo(index, position)
                player.prepare()
                player.play()
            }
            return
        }

        val tried = failedSources.getOrPut(id) { ConcurrentHashMap.newKeySet() }
        tried += source
        // Anche lo stream unico si è interrotto: i link erano scaduti, ne servono di nuovi
        if (source.endsWith(":muxed")) tried.removeAll { it.endsWith(":muxed") }
        Diagnostics.log("Riprovo $id escludendo $tried")

        if (isLazy) {
            player.seekTo(index, position)
            player.prepare()
            player.play()
            return
        }
        val audioOnly = item.requestMetadata.extras?.getBoolean(EXTRA_AUDIO_ONLY) ?: false
        scope.launch {
            try {
                val s = resolver.resolve(id, audioOnly, tried)
                player.replaceMediaItem(index, toPlayable(s, audioOnly))
                player.seekTo(index, position)
                player.prepare()
                player.play()
            } catch (e: Exception) {
                // Nessuna alternativa: link nuovi da zero dopo una breve pausa
                Diagnostics.log("Nessuna alternativa per $id: richiedo link nuovi (tentativo $attempts)")
                tried.clear()
                resolver.invalidate(id)
                kotlinx.coroutines.delay(1500L * attempts)
                try {
                    val s = resolver.resolve(id, audioOnly, emptySet())
                    player.replaceMediaItem(index, toPlayable(s, audioOnly))
                    player.seekTo(index, position)
                    player.prepare()
                    player.play()
                } catch (e2: Exception) {
                    Diagnostics.log("Salto $id: ${e2.message?.lineSequence()?.firstOrNull()}")
                    skipOrContinue()
                }
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    // ------------------------------------------------------------------
    // Pulsanti extra in auto, notifica e schermata di blocco (come Spotify)
    // ------------------------------------------------------------------

    private fun currentIsFavorite(): Boolean {
        val item = player.currentMediaItem ?: return false
        return Library.isFavorite(videoIdOf(item.mediaId))
    }

    private fun mediaButtons(): List<CommandButton> = listOf(
        CommandButton.Builder(if (currentIsFavorite()) CommandButton.ICON_HEART_FILLED else CommandButton.ICON_HEART_UNFILLED)
            .setDisplayName(if (currentIsFavorite()) "Rimuovi dai preferiti" else "Aggiungi ai preferiti")
            .setSessionCommand(SessionCommand(CMD_LIKE, Bundle.EMPTY))
            .build(),
        CommandButton.Builder(if (player.shuffleModeEnabled) CommandButton.ICON_SHUFFLE_ON else CommandButton.ICON_SHUFFLE_OFF)
            .setDisplayName(if (player.shuffleModeEnabled) "Casuale attivo" else "Casuale")
            .setSessionCommand(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
            .build(),
    )

    private fun refreshButtons() {
        session?.setMediaButtonPreferences(mediaButtons())
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Su TV, chiudendo l'app dai recenti, si ferma tutto
        if (DeviceProfile.kind(this) == DeviceProfile.Kind.TV) {
            session?.player?.let { p -> p.pause(); p.stop() }
            stopSelf()
            return
        }
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0 || p.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        skipHandler.removeCallbacks(skipTick)
        fx.release()
        runCatching { focus.release() }
        session?.run {
            player.release()
            release()
        }
        session = null
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Callback: navigazione Android Auto, ricerca vocale, code
    // ------------------------------------------------------------------

    private inner class LibraryCallback : MediaLibrarySession.Callback {

        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS.buildUpon()
                .add(SessionCommand(CMD_LIKE, Bundle.EMPTY))
                .add(SessionCommand(CMD_SHUFFLE, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle,
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CMD_LIKE -> player.currentMediaItem?.let { item ->
                    val m = item.mediaMetadata
                    val v = VideoItem(
                        id = videoIdOf(item.mediaId),
                        title = m.title?.toString().orEmpty(),
                        author = m.artist?.toString().orEmpty(),
                        duration = "",
                        thumbnailUrl = "https://i.ytimg.com/vi/${videoIdOf(item.mediaId)}/hqdefault.jpg",
                    )
                    val now = Library.toggleFavorite(v)
                    Diagnostics.log(if (now) "❤ ${v.title} aggiunto ai preferiti" else "${v.title} tolto dai preferiti")
                }
                CMD_SHUFFLE -> player.shuffleModeEnabled = !player.shuffleModeEnabled
            }
            refreshButtons()
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> {
            // Mostra il tasto di ricerca in Android Auto
            val rootParams = LibraryParams.Builder()
                .setExtras(Bundle().apply {
                    putBoolean("android.media.browse.SEARCH_SUPPORTED", true)
                    // 1 = elenco, 2 = griglia, 3 = elenco di categorie con icone
                    putInt(STYLE_BROWSABLE, STYLE_GRID)
                    putInt(STYLE_PLAYABLE, STYLE_LIST)
                })
                .build()
            return Futures.immediateFuture(LibraryResult.ofItem(folder(ROOT_ID, "Tubetto"), rootParams))
        }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val item = browseCache.values.asSequence().flatten().firstOrNull { it.mediaId == mediaId }
                ?: ListenHistory.all().firstOrNull { it.id == videoIdOf(mediaId) }
                    ?.let { browseItem(it.toVideoItem(), "a:${it.id}") }
            return Futures.immediateFuture(
                if (item != null) LibraryResult.ofItem(item, null)
                else LibraryResult.ofError(SessionError.ERROR_BAD_VALUE)
            )
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = scope.future {
            try {
                val all: List<MediaItem> = when {
                    // Quattro schede in alto, come Spotify: Home, Recenti, Sfoglia, Libreria
                    parentId == ROOT_ID -> listOf(
                        tab(TAB_HOME, "Home", "ic_aa_home", STYLE_GRID, STYLE_GRID),
                        tab(TAB_RECENT, "Recenti", "ic_aa_recent", STYLE_GRID, STYLE_GRID),
                        tab(TAB_BROWSE, "Sfoglia", "ic_aa_browse", STYLE_GRID, STYLE_LIST),
                        tab(TAB_LIBRARY, "Libreria", "ic_aa_library", STYLE_CATEGORY_LIST, STYLE_LIST),
                    )
                    parentId == TAB_HOME -> homeItems()
                    parentId == TAB_RECENT -> songs("recent", ListenHistory.all().take(60).map { it.toVideoItem() })
                    parentId == TAB_BROWSE -> browseCategories()
                    parentId == TAB_LIBRARY -> listOf(
                        styled(MIX_ID, "Il mio mix", "Preferiti, artisti che segui e brani simili", icon("ic_aa_mix")),
                        styled(FAV_ID, "Brani che ti piacciono", "${Library.favorites().size} brani", icon("ic_aa_heart")),
                        styled(MYPL_ID, "Playlist", "Le tue playlist", icon("ic_aa_playlist"), browsable = STYLE_GRID),
                        styled(ARTISTS_ID, "Artisti", "Che segui e che ascolti di più", icon("ic_aa_artist"), browsable = STYLE_GRID),
                        styled(FORYOU_ID, "Per te", "Consigliati in base agli ascolti", icon("ic_aa_trending")),
                        styled(HISTORY_ID, "Cronologia", "Ascoltati di recente", icon("ic_aa_recent")),
                        styled(RADIO_ID, "Radio", "Le tue radio preferite", icon("ic_aa_trending")),
                    )
                    parentId == RADIO_ID -> Radio.favorites().map { browseItem(it, it.id) }
                    parentId.startsWith(CAT_PREFIX) -> {
                        val cat = CATEGORIES.firstOrNull { it.key == parentId.removePrefix(CAT_PREFIX) }
                        if (cat == null) emptyList() else songs("cat:${cat.key}", timed("cat:${cat.key}", 30) { loadCategory(cat) })
                    }
                    parentId == MIX_ID -> songs("mix", recommender.myMix().items)
                    parentId == FORYOU_ID -> songs("foryou", recommender.forYou().items)
                    parentId == CHARTS_ID -> Charts.items().map {
                        when (it.id) {
                            Charts.YTM_HITS, Charts.YTM_NEW -> folder(it.id, it.title)
                            else -> folder("$PLS_PREFIX${it.id.removePrefix(Charts.PREFIX)}", it.title)
                        }
                    }
                    parentId == Charts.YTM_HITS -> cached(parentId) { api.musicCharts().map { browseItem(it, "a:${it.id}") } }
                    parentId == Charts.YTM_NEW -> cached(parentId) { api.musicNewReleases().map { browseItem(it, "a:${it.id}") } }
                    parentId == ARTISTS_ID -> artistFolders(30)
                    parentId.startsWith(ART_PREFIX) -> {
                        val name = parentId.removePrefix(ART_PREFIX)
                        songs("art:$name", timed("art:$name", 60) { api.searchMusic(name) })
                    }
                    parentId == FAV_ID -> songs("fav", Library.favorites().filter { it.kind == ItemKind.VIDEO })
                    parentId == MYPL_ID -> playlistFolders()
                    parentId.startsWith(LPL_PREFIX) -> {
                        val name = parentId.removePrefix(LPL_PREFIX)
                        songs("lpl:$name", Library.playlist(name))
                    }
                    parentId == HISTORY_ID -> songs("history", ListenHistory.all().take(60).map { it.toVideoItem() })
                    parentId.startsWith(MUSIC_PREFIX) -> musicItems(parentId.removePrefix(MUSIC_PREFIX))
                    parentId.startsWith(PLS_PREFIX) -> cached(parentId) {
                        api.searchPlaylists(parentId.removePrefix(PLS_PREFIX)).map {
                            queueTitles["$PL_PREFIX${it.id}"] = it.title
                            folder("$PL_PREFIX${it.id}", it.title, it)
                        }
                    }
                    parentId.startsWith(PL_PREFIX) -> {
                        val plId = parentId.removePrefix(PL_PREFIX)
                        cached(parentId) { api.playlist(plId).map { browseItem(it, "plt:$plId:${it.id}") } }
                    }
                    else -> emptyList()
                }
                LibraryResult.ofItemList(all.paged(page, pageSize), params)
            } catch (e: Exception) {
                Diagnostics.log("Auto browse $parentId: ${e.message}")
                LibraryResult.ofError(SessionError.ERROR_IO)
            }
        }

        override fun onSearch(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<Void>> {
            scope.launch {
                val n = runCatching { musicItems(query).size }.getOrDefault(0)
                session.notifySearchResultChanged(browser, query, n, params)
            }
            return Futures.immediateFuture(LibraryResult.ofVoid())
        }

        override fun onGetSearchResult(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = scope.future {
            val items = runCatching { musicItems(query) }.getOrDefault(emptyList())
            LibraryResult.ofItemList(items.paged(page, pageSize), params)
        }

        /** Gestisce ricerca vocale ("Ok Google, riproduci … su Tubetto") e avvio di playlist. */
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> = scope.future {
            val single = mediaItems.singleOrNull()
            val query = single?.requestMetadata?.searchQuery
            when {
                single != null && single.mediaId.isBlank() -> {
                    // "Ok Google, riproduci X su Tubetto"; senza titolo ("metti musica") parte "Per te"
                    Diagnostics.log("Ricerca vocale: ${query.orEmpty()}")
                    val wantsMix = query != null && MIX_WORDS.containsMatchIn(query)
                    val songs = when {
                        query.isNullOrBlank() -> recommender.musicForYou().items.take(30)
                        wantsMix -> recommender.myMix().items
                        else -> api.searchMusic(query).take(30)
                    }
                    MediaSession.MediaItemsWithStartPosition(songs.map { lazyAudio(it.id, it.toMetadata()) }, 0, C.TIME_UNSET)
                }
                single != null && single.mediaId.startsWith(SHUF_PREFIX) -> {
                    // "Riproduzione casuale": tutta la lista, partenza a caso, casuale attivo
                    val key = single.mediaId.removePrefix(SHUF_PREFIX)
                    val list = queueCache[key].orEmpty()
                    // la coda arriva già mescolata: il flag serve solo a mostrare 🔀 acceso
                    player.shuffleModeEnabled = false
                    scope.launch { kotlinx.coroutines.delay(1500); if (!player.shuffleModeEnabled) player.shuffleModeEnabled = true }
                    val start = 0 // l'ordine casuale è già nella coda (vedi shuffleRemaining)
                    val title = queueTitle(key)
                    MediaSession.MediaItemsWithStartPosition(list.shuffled().map { tagSource(lazyAudio(it.id, it.toMetadata()), title) }, start, C.TIME_UNSET)
                }
                single != null && single.mediaId.startsWith(Q_PREFIX) && queueCache.containsKey(queueKeyOf(single.mediaId)) -> {
                    val key = queueKeyOf(single.mediaId)
                    val list = queueCache[key].orEmpty()
                    val vid = videoIdOf(single.mediaId)
                    val idx = list.indexOfFirst { it.id == vid }.coerceAtLeast(0)
                    val title = queueTitle(key)
                    MediaSession.MediaItemsWithStartPosition(list.map { tagSource(lazyAudio(it.id, it.toMetadata()), title) }, idx, C.TIME_UNSET)
                }
                single != null && single.mediaId.startsWith("plt:") -> {
                    val plId = single.mediaId.removePrefix("plt:").substringBeforeLast(':')
                    val vid = single.mediaId.substringAfterLast(':')
                    val tracks = api.playlist(plId)
                    val idx = tracks.indexOfFirst { it.id == vid }.coerceAtLeast(0)
                    val title = queueTitles["$PL_PREFIX$plId"]?.let { "Playlist «$it»" }
                    MediaSession.MediaItemsWithStartPosition(tracks.map { tagSource(lazyAudio(it.id, it.toMetadata()), title) }, idx, C.TIME_UNSET)
                }
                else -> {
                    val items = addItems(controller, mediaItems).toMutableList()
                    val first = if (startIndex in items.indices) startIndex else 0
                    val f = items.getOrNull(first)
                    if (f != null && f.mediaId.startsWith("v:")) {
                        val id = videoIdOf(f.mediaId)
                        runCatching {
                            resolver.maxHeight = Buffering.maxVideoHeight(this@PlaybackService)
                            resolver.audioMaxKbps = AudioPrefs.maxAudioKbps(this@PlaybackService)
                            toPlayable(resolver.resolve(id, audioOnly = false), audioOnly = false).buildUpon()
                                .setMediaId(f.mediaId)
                                .setMediaMetadata(f.mediaMetadata)
                                .build()
                        }.onSuccess { items[first] = it }
                    }
                    MediaSession.MediaItemsWithStartPosition(items, startIndex, startPositionMs)
                }
            }
        }

        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> = scope.future { addItems(controller, mediaItems).toMutableList() }
    }

    /** Converte gli ID inviati dai controller in elementi riproducibili. */
    private suspend fun addItems(controller: MediaSession.ControllerInfo, items: List<MediaItem>): List<MediaItem> {
        val fromAuto = controller.packageName in AUTO_PACKAGES
        return items.map { item ->
            val mid = item.mediaId
            if (Radio.isRadio(mid)) {
                // Radio web: stream diretto (anche da Android Auto, che manda solo l'id)
                val url = item.requestMetadata.mediaUri?.toString() ?: Radio.urlOf(mid) ?: error("Radio sconosciuta")
                val known = Radio.itemOf(mid)
                val meta = if (item.mediaMetadata.title.isNullOrBlank() && known != null) known.toMetadata() else item.mediaMetadata
                return@map MediaItem.Builder()
                    .setMediaId(mid)
                    .setUri(url)
                    .setMediaMetadata(meta)
                    .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(url)).build())
                    .build()
            }
            val id = videoIdOf(mid).ifBlank {
                val q = item.requestMetadata.searchQuery ?: error("mediaId mancante")
                api.searchMusic(q).first().id
            }
            if (!fromAuto && mid.startsWith("v:")) {
                lazyVideo(id, if (item.mediaMetadata.title.isNullOrBlank()) knownMetadata(id) ?: item.mediaMetadata else item.mediaMetadata)
            } else if (fromAuto || mid.startsWith("a:") || mid.startsWith("plt:") || mid.startsWith(Q_PREFIX)) {
                // In auto e nelle code: solo audio, risolto quando serve.
                // Android Auto invia solo l'ID: titolo e copertina li recuperiamo noi.
                val meta = if (item.mediaMetadata.title.isNullOrBlank()) knownMetadata(id) ?: item.mediaMetadata
                else item.mediaMetadata
                lazyAudio(id, meta)
            } else {
                failedSources.remove(id)
                resolver.maxHeight = Buffering.maxVideoHeight(this@PlaybackService)
                resolver.audioMaxKbps = AudioPrefs.maxAudioKbps(this@PlaybackService)
                try {
                    toPlayable(resolver.resolve(id, audioOnly = false), audioOnly = false)
                } catch (e: Exception) {
                    Diagnostics.log("Risoluzione fallita $id: ${e.message?.lineSequence()?.firstOrNull()}")
                    throw e
                }
            }
        }
    }

    // ------------------------------------------------------------------

    /** Metadati già noti per un video (liste sfogliate, preferiti, playlist, cronologia). */
    private fun knownMetadata(videoId: String): MediaMetadata? {
        browseCache.values.asSequence().flatten()
            .firstOrNull { videoIdOf(it.mediaId) == videoId }
            ?.let { return it.mediaMetadata }
        Library.favorites().firstOrNull { it.id == videoId }?.let { return it.toMetadata() }
        Library.playlistNames().asSequence()
            .mapNotNull { n -> Library.playlist(n).firstOrNull { it.id == videoId } }
            .firstOrNull()?.let { return it.toMetadata() }
        ListenHistory.all().firstOrNull { it.id == videoId }?.let { return it.toVideoItem().toMetadata() }
        return null
    }

    private suspend fun musicItems(query: String): List<MediaItem> =
        songs("s:$query", timed("s:$query", 30) { api.searchMusic(query) })

    private suspend fun cached(key: String, load: suspend () -> List<MediaItem>): List<MediaItem> =
        browseCache[key] ?: load().also { browseCache[key] = it }

    private fun VideoItem.toMetadata(): MediaMetadata = MetaCleaner.clean(title, author).let { (t, a) ->
        MediaMetadata.Builder()
        .setTitle(t)
        .setDisplayTitle(t)
        .setArtist(a)
        .setSubtitle(listOf(author, duration).filter { it.isNotBlank() }.joinToString(" • "))
        .setArtworkUri(ArtworkProvider.uriFor(thumbnail))
        .build()
    }

    private fun browseItem(v: VideoItem, mediaId: String): MediaItem = MediaItem.Builder()
        .setMediaId(mediaId)
        .setMediaMetadata(
            v.toMetadata().buildUpon()
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .build()
        )
        .build()

    private fun lazyAudio(videoId: String, rawMeta: MediaMetadata): MediaItem {
        val (t, a) = MetaCleaner.clean(rawMeta.title?.toString().orEmpty(), rawMeta.artist?.toString().orEmpty())
        val meta = rawMeta.buildUpon()
            .setTitle(t.ifBlank { null })
            .setDisplayTitle(t.ifBlank { null })
            .setArtist(a.ifBlank { null })
            .build()
        StreamResolver.hint(videoId, t, a)
        return lazyAudioItem(videoId, meta)
    }

    private fun lazyAudioItem(videoId: String, meta: MediaMetadata): MediaItem = MediaItem.Builder()
        .setMediaId("a:$videoId")
        .setUri("$LAZY_SCHEME://audio/$videoId")
        .setRequestMetadata(
            MediaItem.RequestMetadata.Builder()
                .setExtras(Bundle().apply { putBoolean(EXTRA_AUDIO_ONLY, true) })
                .build()
        )
        .setMediaMetadata(
            meta.buildUpon()
                .setArtworkUri(ArtworkProvider.uriFor(meta.artworkUri ?: Uri.parse("https://i.ytimg.com/vi/$videoId/hqdefault.jpg")))
                .setDisplayTitle(meta.displayTitle ?: meta.title)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .build()
        )
        .build()

    private fun toPlayable(s: ResolvedStream, audioOnly: Boolean): MediaItem {
        val extras = Bundle().apply { putBoolean(EXTRA_AUDIO_ONLY, audioOnly) }
        val (t, a) = MetaCleaner.clean(s.title, s.author)
        val meta = MediaMetadata.Builder()
            .setTitle(t)
            .setDisplayTitle(t)
            .setArtist(a)
            .setAlbumArtist(a)
            .setArtworkUri(ArtworkProvider.uriFor(s.thumbnail))
            .setDurationMs(s.durationMs.takeIf { it > 0 })
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_VIDEO)
            .build()
        return YouTubeMediaSourceFactory.mediaItemFor(s, meta, extras)
    }

    private fun loadSkipSegments(item: MediaItem?) {
        skipSegments = emptyList()
        val id = item?.let { videoIdOf(it.mediaId) } ?: return
        val music = item.mediaId.startsWith("a:") || item.mediaId.startsWith("v:")
        skipFor = id
        if (Radio.isRadio(item.mediaId)) return
        if (!SponsorBlock.enabled(this)) return
        scope.launch {
            val segs = SponsorBlock.segments(id, music)
            if (skipFor == id) {
                skipSegments = segs
                if (segs.isNotEmpty()) Diagnostics.log("Da saltare in $id: " + segs.joinToString { "${it.category} ${it.startMs / 1000}-${it.endMs / 1000}s" })
                checkSkip()
            }
        }
    }

    /** Se siamo dentro un segmento da saltare, va subito alla fine del segmento. */
    private fun checkSkip() {
        val segs = skipSegments
        if (segs.isEmpty() || !player.isPlaying) return
        val pos = player.currentPosition
        val seg = segs.firstOrNull { pos >= it.startMs && pos < it.endMs - 300 } ?: return
        val duration = player.duration
        if (duration > 0 && seg.endMs >= duration - 1000) {
            // Segmento fino alla fine (es. titoli di coda): passa al brano dopo
            if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(duration)
        } else {
            player.seekTo(seg.endMs)
        }
        Diagnostics.log("Saltato ${seg.category} (${seg.startMs / 1000}-${seg.endMs / 1000}s)")
    }

    /**
     * Code di video (TV): gli elementi "v:" partono come segnaposto e qui diventano
     * video adattivi in piena qualità. Il successivo viene preparato in anticipo.
     */
    private val upgrading = java.util.Collections.synchronizedSet(HashSet<String>())

    private fun upgradeVideo(index: Int) {
        if (index < 0 || index >= player.mediaItemCount) return
        val item = player.getMediaItemAt(index)
        if (item.localConfiguration?.uri?.toString()?.startsWith("$LAZY_SCHEME://video/") != true) return
        val id = videoIdOf(item.mediaId)
        if (!upgrading.add(id)) return
        scope.launch {
            try {
                resolver.maxHeight = Buffering.maxVideoHeight(this@PlaybackService)
                resolver.audioMaxKbps = AudioPrefs.maxAudioKbps(this@PlaybackService)
                val s = resolver.resolve(id, audioOnly = false, exclude = failedSources[id].orEmpty().toSet())
                // L'indice può essere cambiato nel frattempo
                val idx = (0 until player.mediaItemCount).firstOrNull { player.getMediaItemAt(it).mediaId == item.mediaId }
                    ?: return@launch
                val full = toPlayable(s, audioOnly = false).buildUpon()
                    .setMediaId(item.mediaId)
                    .setMediaMetadata(
                        item.mediaMetadata.buildUpon()
                            .setDurationMs(s.durationMs.takeIf { it > 0 })
                            .setMediaType(MediaMetadata.MEDIA_TYPE_VIDEO)
                            .build()
                    )
                    .build()
                val isCurrent = idx == player.currentMediaItemIndex
                val pos = player.currentPosition
                player.replaceMediaItem(idx, full)
                if (isCurrent && pos > 1500) player.seekTo(idx, pos)
            } catch (e: Exception) {
                Diagnostics.log("Video in coda $id: resta la versione semplice (${e.message?.take(60)})")
            } finally {
                upgrading.remove(id)
            }
        }
    }

    private fun lazyVideo(videoId: String, rawMeta: MediaMetadata): MediaItem {
        val (t, a) = MetaCleaner.clean(rawMeta.title?.toString().orEmpty(), rawMeta.artist?.toString().orEmpty())
        return MediaItem.Builder()
            .setMediaId("v:$videoId")
            .setUri("$LAZY_SCHEME://video/$videoId")
            .setRequestMetadata(
                MediaItem.RequestMetadata.Builder()
                    .setExtras(Bundle().apply { putBoolean(EXTRA_AUDIO_ONLY, false) })
                    .build()
            )
            .setMediaMetadata(
                rawMeta.buildUpon()
                    .setTitle(t.ifBlank { null }).setDisplayTitle(t.ifBlank { null })
                    .setArtist(a.ifBlank { null })
                    .setArtworkUri(ArtworkProvider.uriFor(rawMeta.artworkUri ?: Uri.parse("https://i.ytimg.com/vi/$videoId/hqdefault.jpg")))
                    .setIsBrowsable(false)
                    .setIsPlayable(true)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_VIDEO)
                    .build()
            )
            .build()
    }

    /** Se un brano in coda non ha titolo o artista, li prende dallo stream appena risolto. */
    private fun fillMetadata(id: String, s: ResolvedStream) {
        for (i in 0 until player.mediaItemCount) {
            val item = player.getMediaItemAt(i)
            if (videoIdOf(item.mediaId) != id) continue
            val m = item.mediaMetadata
            if (!m.title.isNullOrBlank() && !m.artist.isNullOrBlank()) continue
            val (t, a) = MetaCleaner.clean(
                m.title?.toString()?.ifBlank { null } ?: s.title,
                m.artist?.toString()?.ifBlank { null } ?: s.author,
            )
            val updated = m.buildUpon()
                .setTitle(t).setDisplayTitle(t)
                .setArtist(a.ifBlank { MetaCleaner.cleanArtist(s.author) })
                .setDurationMs(m.durationMs ?: s.durationMs.takeIf { it > 0 })
                .build()
            player.replaceMediaItem(i, item.buildUpon().setMediaMetadata(updated).build())
            Diagnostics.log("Titolo/artista completati: $t — $a")
        }
    }

    /** Salva l'ascolto nella cronologia persistente (base dei suggerimenti). */
    private fun recordListen(item: MediaItem) {
        if (Radio.isRadio(item.mediaId)) return
        val m = item.mediaMetadata
        ListenHistory.record(
            id = videoIdOf(item.mediaId),
            title = m.title?.toString().orEmpty(),
            author = m.artist?.toString().orEmpty(),
            thumb = m.artworkUri?.toString().orEmpty(),
            music = item.mediaId.startsWith("a:") || item.mediaId.startsWith("v:"),
        )
    }

    /**
     * Radio automatica: quando una coda musicale sta per finire aggiunge brani simili
     * all'ultimo ascoltato, così la musica non si ferma (utile in auto).
     */
    private fun extendRadio() {
        val item = player.currentMediaItem ?: return
        if (Radio.isRadio(item.mediaId)) return
        if (radioPending || !AutoplayPrefs.enabled(this)) return
        // Aggiunge quando restano al massimo 2 elementi (anche con un solo video in coda)
        if (player.mediaItemCount - player.currentMediaItemIndex > 2) return
        val mid = item.mediaId
        val audioQueue = mid.startsWith("a:") || mid.startsWith("plt:")
        val musicVideoQueue = mid.startsWith("v:")
        val plainVideo = !audioQueue && !musicVideoQueue && mid.isNotBlank()
        radioPending = true
        scope.launch {
            try {
                val id = videoIdOf(mid)
                val queued = (0 until player.mediaItemCount).map { videoIdOf(player.getMediaItemAt(it).mediaId) }.toSet()
                val recent = ListenHistory.all().take(30).map { it.id }.toSet()
                val more = api.related(id, music = !plainVideo)
                    .filter { it.kind == ItemKind.VIDEO && it.id !in queued && it.id !in recent }
                    .take(if (plainVideo) 10 else 15)
                player.addMediaItems(
                    more.map {
                        if (audioQueue) lazyAudio(it.id, it.toMetadata()) else lazyVideo(it.id, it.toMetadata())
                    }
                )
                Diagnostics.log("Riproduzione automatica: aggiunti ${more.size} ${if (audioQueue) "brani" else "video"} dopo $id")
                // Prepara subito in piena qualità il prossimo video
                if (!audioQueue) upgradeVideo(player.currentMediaItemIndex + 1)
            } catch (e: Exception) {
                Diagnostics.log("Riproduzione automatica fallita: ${e.message}")
            } finally {
                radioPending = false
            }
        }
    }

    private fun folder(id: String, title: String, v: VideoItem? = null) = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .apply {
                    if (v != null) {
                        setSubtitle(listOf(v.author, v.duration).filter { it.isNotBlank() }.joinToString(" • "))
                        setArtworkUri(ArtworkProvider.uriFor(v.thumbnailUrl?.ifBlank { null } ?: v.thumbnail))
                    }
                }
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(
                    if (v?.kind == ItemKind.PLAYLIST) MediaMetadata.MEDIA_TYPE_PLAYLIST
                    else MediaMetadata.MEDIA_TYPE_FOLDER_MIXED
                )
                .build()
        )
        .build()

    // ---------------- Android Auto in stile Spotify ----------------

    /** Brani di una lista: toccandone uno parte tutta la lista da quel punto. */
    /** Titoli delle playlist YouTube aperte in Android Auto. */
    private val queueTitles = ConcurrentHashMap<String, String>()

    /** Da quale lista arriva la coda, detto in chiaro (es. "Playlist «Lapreferita»"). */
    private fun queueTitle(key: String): String? = when {
        key.startsWith(LPL_PREFIX) -> "Playlist «${key.removePrefix(LPL_PREFIX)}»"
        key.startsWith(ART_PREFIX) -> "Artista: ${key.removePrefix(ART_PREFIX)}"
        key == "fav" -> "Brani che ti piacciono"
        key == "mix" -> "Il mio mix"
        key == "foryou" || key == "home:foryou" -> "Per te"
        key == "history" || key == "recent" || key == "home:recent" -> "Ascoltati di recente"
        key == "home:hits" -> "Hit del momento"
        key == "home:new" -> "Nuove uscite"
        key.startsWith("cat:") -> CATEGORIES.firstOrNull { it.key == key.removePrefix("cat:") }?.title
        key.startsWith("s:") -> "Ricerca: ${key.removePrefix("s:")}"
        else -> queueTitles[key]
    }

    /** Aggiunge al brano il nome della lista: visibile nel player di Android Auto sotto il titolo. */
    private fun tagSource(item: MediaItem, source: String?): MediaItem {
        if (source.isNullOrBlank()) return item
        val m = item.mediaMetadata
        val artist = m.artist?.toString().orEmpty()
        return item.buildUpon().setMediaMetadata(
            m.buildUpon()
                .setAlbumTitle(source)
                .setSubtitle(listOf(artist, "🎵 $source").filter { it.isNotBlank() }.joinToString(" · "))
                .build()
        ).build()
    }

    private fun songs(key: String, list: List<VideoItem>, group: String? = null): List<MediaItem> {
        val vids = list.filter { it.kind == ItemKind.VIDEO }.distinctBy { it.id }
        queueCache[key] = vids
        val items = vids.map { v ->
            val item = browseItem(v, "$Q_PREFIX$key|${v.id}")
            if (group == null) item else item.withExtras { putString(STYLE_GROUP, group) }
        }
        browseCache["$Q_PREFIX$key"] = items
        // Elenchi (playlist, preferiti, artisti…): prima riga "Riproduzione casuale", come Spotify
        if (group != null || vids.size < 2) return items
        val shuffle = MediaItem.Builder()
            .setMediaId("$SHUF_PREFIX$key")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle("Riproduzione casuale")
                    .setDisplayTitle("Riproduzione casuale")
                    .setSubtitle("${vids.size} brani in ordine casuale")
                    .setArtworkUri(icon("ic_shuffle"))
                    .setIsBrowsable(false)
                    .setIsPlayable(true)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                    .build()
            )
            .build()
        return listOf(shuffle) + items
    }

    /** Dati che cambiano poco (classifiche, categorie): ricaricati al massimo ogni [minutes]. */
    private suspend fun timed(key: String, minutes: Int, load: suspend () -> List<VideoItem>): List<VideoItem> {
        val c = timedCache[key]
        if (c != null && System.currentTimeMillis() - c.first < minutes * 60_000L) return c.second
        val fresh = try { load() } catch (e: Exception) { if (c != null) return c.second else throw e }
        timedCache[key] = System.currentTimeMillis() to fresh
        return fresh
    }

    private suspend fun safeTimed(key: String, minutes: Int, load: suspend () -> List<VideoItem>): List<VideoItem> =
        withTimeoutOrNull(8_000) { runCatching { timed(key, minutes, load) }.getOrNull() } ?: timedCache[key]?.second.orEmpty()

    private fun MediaItem.withExtras(f: Bundle.() -> Unit): MediaItem {
        val ex = Bundle(mediaMetadata.extras ?: Bundle()).apply(f)
        return buildUpon().setMediaMetadata(mediaMetadata.buildUpon().setExtras(ex).build()).build()
    }

    private fun icon(name: String): Uri = Uri.parse("android.resource://$packageName/drawable/$name")

    /** Cartella con icona/copertina e stile dei figli. */
    private fun styled(
        id: String,
        title: String,
        subtitle: String?,
        art: Uri?,
        browsable: Int? = null,
        playable: Int? = null,
        group: String? = null,
        type: Int = MediaMetadata.MEDIA_TYPE_FOLDER_MIXED,
    ): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setArtworkUri(art)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(type)
                .setExtras(Bundle().apply {
                    if (browsable != null) putInt(STYLE_BROWSABLE, browsable)
                    if (playable != null) putInt(STYLE_PLAYABLE, playable)
                    if (group != null) putString(STYLE_GROUP, group)
                })
                .build()
        )
        .build()

    private fun tab(id: String, title: String, iconName: String, browsable: Int, playable: Int) =
        styled(id, title, null, icon(iconName), browsable, playable)

    /** Home: raccolte, per te, hit, nuove uscite, recenti — a griglia con titoli di sezione. */
    private suspend fun homeItems(): List<MediaItem> = coroutineScope {
        val forYou = async { safeTimed("home:foryou", 20) { recommender.musicForYou().items.take(12) } }
        val hits = async { safeTimed("home:hits", 60) { api.musicCharts().take(12) } }
        val news = async { safeTimed("home:new", 120) { api.musicNewReleases(12) } }
        val artists = artistFolders(6, group = G_MINE)
        buildList {
            add(styled(MIX_ID, "Il mio mix", "Creato per te", mixArt(), group = G_MINE))
            add(styled(FAV_ID, "Brani che ti piacciono", "${Library.favorites().size} brani", favArt(), group = G_MINE))
            addAll(playlistFolders(group = G_MINE).take(4))
            addAll(artists)
            addAll(songs("home:foryou", forYou.await(), group = "Per te"))
            addAll(songs("home:hits", hits.await(), group = "🔥 Hit del momento"))
            addAll(songs("home:new", news.await(), group = "🆕 Nuove uscite"))
            addAll(songs("home:recent", ListenHistory.all().filter { it.music }.take(10).map { it.toVideoItem() }, group = "Ascoltati di recente"))
        }
    }

    /** Artisti seguiti + più ascoltati, con foto rotonda. */
    private fun artistFolders(limit: Int, group: String? = null): List<MediaItem> {
        val names = (Library.artists().map { it.id } + ListenHistory.topArtists(limit, musicOnly = true))
            .distinctBy { it.lowercase() }
            .withIndex().sortedWith(compareByDescending<IndexedValue<String>> { Recents.at(Recents.artistKey(it.value)) }.thenBy { it.index })
            .map { it.value }.take(limit)
        return names.map { name ->
            val photo = ArtistImages.cached(name)
                ?: Library.artists().firstOrNull { it.id.equals(name, true) }?.thumbnailUrl
            if (photo == null) scope.launch { runCatching { ArtistImages.get(api, name) } } // la prossima volta c'è
            styled(
                "$ART_PREFIX$name", name, "Artista",
                ArtworkProvider.roundUri(photo) ?: ArtworkProvider.tileUri(colorFor(name), name.take(1).uppercase()),
                playable = STYLE_LIST, group = group, type = MediaMetadata.MEDIA_TYPE_ARTIST,
            )
        }
    }

    private fun playlistFolders(group: String? = null): List<MediaItem> = Library.playlistNames()
        .sortedByDescending { Recents.at(Recents.playlistKey(Library.LOCAL_PREFIX + it)) }.map { name ->
        val list = Library.playlist(name)
        styled(
            "$LPL_PREFIX$name", name, "${list.size} brani",
            ArtworkProvider.collageUri(list.map { Collage.coverOf(it) }) ?: ArtworkProvider.tileUri(colorFor(name), "♫"),
            playable = STYLE_LIST, group = group, type = MediaMetadata.MEDIA_TYPE_PLAYLIST,
        )
    }

    /** Sfoglia: riquadri colorati per genere, come le categorie di Spotify. */
    private fun browseCategories(): List<MediaItem> = buildList {
        CATEGORIES.forEach { c ->
            val cover = queueCache["cat:${c.key}"]?.firstOrNull()?.thumbnail
                ?: timedCache["cat:${c.key}"]?.second?.firstOrNull()?.thumbnail
            add(styled("$CAT_PREFIX${c.key}", c.title, null, ArtworkProvider.tileUri(c.color, c.symbol, cover), playable = STYLE_LIST))
        }
        add(styled(CHARTS_ID, "Classifiche ed eventi", null, ArtworkProvider.tileUri("#F39C12", "🏆"), browsable = STYLE_LIST))
        PLAYLIST_FOLDERS.forEach { q ->
            add(styled("$PLS_PREFIX$q", "Playlist: $q", null, ArtworkProvider.tileUri(colorFor(q), "▶"), browsable = STYLE_GRID))
        }
    }

    private suspend fun loadCategory(c: Category): List<VideoItem> = when (c.key) {
        "hits" -> api.musicCharts()
        "new" -> api.musicNewReleases()
        else -> api.searchMusic(c.query)
    }

    /** Mosaico dei preferiti (o riquadro viola col cuore se vuoti). */
    private fun favArt(): Uri =
        ArtworkProvider.collageUri(Library.favorites().filter { it.kind == ItemKind.VIDEO }.map { Collage.coverOf(it) })
            ?: ArtworkProvider.tileUri("#7B4DFF", "♥\uFE0E")

    /** Mosaico del mix: preferiti e più ascoltati alternati. */
    private fun mixArt(): Uri {
        val v = VideoItem(id = ShelfAdapter.TILE_MIX, title = "", author = "", duration = "")
        return ArtworkProvider.collageUri(Collage.urlsFor(v).orEmpty()) ?: ArtworkProvider.tileUri("#3A7BD5", "✦")
    }

    private fun colorFor(s: String): String = TILE_COLORS[(s.lowercase().hashCode() and 0x7fffffff) % TILE_COLORS.size]

    private fun queueKeyOf(mediaId: String): String = mediaId.removePrefix(Q_PREFIX).substringBeforeLast('|')

    private data class Category(val key: String, val title: String, val color: String, val symbol: String, val query: String = "")

    private fun <T> List<T>.paged(page: Int, size: Int): List<T> {
        if (size <= 0 || size == Int.MAX_VALUE) return this
        val from = page * size
        return if (from >= this.size) emptyList() else subList(from, minOf(from + size, this.size))
    }

    companion object {
        const val LAZY_SCHEME = "tubetto"
        private const val CMD_LIKE = "tubetto.LIKE"
        private const val CMD_SHUFFLE = "tubetto.SHUFFLE"
        private const val ROOT_ID = "root"
        private const val HISTORY_ID = "history"
        private const val RADIO_ID = "radiofav"
        private const val SHUF_PREFIX = "shuf:"
        private const val FORYOU_ID = "foryou"
        private const val MIX_ID = "mix"
        /** "il mio mix", "mix per me", "la mia musica", "musica per me". */
        private val MIX_WORDS = Regex("(?i)(\\bmio mix\\b|\\bmix per me\\b|\\bmy mix\\b|\\bla mia musica\\b|\\bmusica per me\\b|^mix$)")
        private const val FAV_ID = "fav"
        private const val CHARTS_ID = "charts"
        private const val ARTISTS_ID = "artists"
        private const val ART_PREFIX = "art:"
        private const val MYPL_ID = "mypl"
        private const val LPL_PREFIX = "lpl:"
        private const val MUSIC_PREFIX = "m:"
        private const val PLS_PREFIX = "pls:"
        private const val PL_PREFIX = "pl:"
        private val MUSIC_FOLDERS = listOf("Musica italiana", "Hit del momento", "Rap italiano", "Anni 80")

        private const val TAB_HOME = "tab:home"
        private const val TAB_RECENT = "tab:recent"
        private const val TAB_BROWSE = "tab:browse"
        private const val TAB_LIBRARY = "tab:library"
        private const val CAT_PREFIX = "cat:"
        private const val Q_PREFIX = "q:"
        private const val G_MINE = "Le tue raccolte"

        private const val STYLE_BROWSABLE = "android.media.browse.CONTENT_STYLE_BROWSABLE_HINT"
        private const val STYLE_PLAYABLE = "android.media.browse.CONTENT_STYLE_PLAYABLE_HINT"
        private const val STYLE_GROUP = "android.media.browse.CONTENT_STYLE_GROUP_TITLE_HINT"
        private const val STYLE_LIST = 1
        private const val STYLE_GRID = 2
        private const val STYLE_CATEGORY_LIST = 3

        private val TILE_COLORS = listOf("#E91E63", "#8E44AD", "#27AE60", "#2980B9", "#D35400", "#16A085", "#C0392B", "#2C3E50", "#6C5CE7", "#0A84D0")

        private val CATEGORIES = listOf(
            Category("hits", "Hit del momento", "#E91E63", "🔥"),
            Category("new", "Nuove uscite", "#8E44AD", "🆕"),
            Category("ita", "Musica italiana", "#27AE60", "♫", "musica italiana successi"),
            Category("rap", "Rap italiano", "#34495E", "🎤", "rap italiano"),
            Category("pop", "Pop internazionale", "#2980B9", "★", "pop hits"),
            Category("nap", "Musica napoletana", "#0A84D0", "♫", "musica napoletana"),
            Category("80", "Anni 80", "#D35400", "80", "hit anni 80"),
            Category("90", "Anni 90", "#16A085", "90", "hit anni 90"),
            Category("dance", "Dance", "#C0392B", "♪", "dance hits"),
            Category("rock", "Rock", "#7F8C8D", "♪", "rock classici"),
            Category("relax", "Relax", "#1ABC9C", "☾", "musica rilassante"),
            Category("car", "In viaggio", "#2C3E50", "🚗", "canzoni da viaggio in macchina"),
        )
        private val PLAYLIST_FOLDERS = listOf("musica italiana", "relax", "viaggio in auto")
        private val AUTO_PACKAGES = setOf(
            "com.google.android.projection.gearhead",
            "com.google.android.carassistant",
        )

        fun videoIdOf(mediaId: String): String = when {
            mediaId.startsWith("a:") -> mediaId.removePrefix("a:")
            mediaId.startsWith("v:") -> mediaId.removePrefix("v:")
            mediaId.startsWith("plt:") -> mediaId.substringAfterLast(':')
            mediaId.startsWith(Q_PREFIX) -> mediaId.substringAfterLast('|')
            else -> mediaId
        }
    }
}
