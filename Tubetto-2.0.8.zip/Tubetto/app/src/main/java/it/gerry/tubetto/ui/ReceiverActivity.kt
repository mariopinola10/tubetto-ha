package it.gerry.tubetto.ui

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import it.gerry.tubetto.BuildConfig
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.R
import it.gerry.tubetto.cast.RendererBackend
import it.gerry.tubetto.cast.RendererState
import it.gerry.tubetto.cast.TubettoRenderer
import it.gerry.tubetto.data.StreamResolver
import it.gerry.tubetto.data.YouTubeApiHelper
import it.gerry.tubetto.net.Http
import it.gerry.tubetto.net.YouTubeChunkedDataSource
import it.gerry.tubetto.playback.YouTubeMediaSourceFactory
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.concurrent.Callable
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

/**
 * Modalità ricevitore per Fire TV / Android TV: espone un renderer DLNA.
 * I link YouTube (https://youtu.be/…, watch?v=…) vengono risolti qui in piena qualità,
 * quindi il telefono non deve restare acceso. Gli altri URL vengono riprodotti così come sono.
 */
@OptIn(UnstableApi::class)
class ReceiverActivity : AppCompatActivity(), RendererBackend {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var idle: View
    private lateinit var idleInfo: TextView
    private var renderer: TubettoRenderer? = null

    private val main = Handler(Looper.getMainLooper())
    private val resolver = StreamResolver(YouTubeApiHelper())
    private var loadJob: Job? = null

    private var uri = ""
    private var metadata = ""
    private var transport = "NO_MEDIA_PRESENT"
    private var volume = 100
    private var mute = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receiver)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        playerView = findViewById(R.id.playerView)
        idle = findViewById(R.id.idle)
        idleInfo = findViewById(R.id.idleInfo)

        val chunked = YouTubeChunkedDataSource.Factory(OkHttpDataSource.Factory(Http.streamClient))
        player = ExoPlayer.Builder(this)
            .setLoadControl(it.gerry.tubetto.playback.Buffering.loadControl(it.gerry.tubetto.ui.DeviceProfile.kind(this) == it.gerry.tubetto.ui.DeviceProfile.Kind.TV))
            .setBandwidthMeter(it.gerry.tubetto.playback.Buffering.bandwidthMeter(this))
            .setMediaSourceFactory(
                YouTubeMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(chunked), chunked)
            )
            .build()
        playerView.player = player
        playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        player.addListener(object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) = updateTransport()
            override fun onPlayerError(error: PlaybackException) {
                Diagnostics.log("Ricevitore: errore ${error.errorCodeName}")
                transport = "STOPPED"
                renderer?.stateChanged()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val name = "Tubetto ${Build.MODEL}"
        renderer = TubettoRenderer(this, this, name).also { it.start() }
        main.postDelayed({
            idleInfo.text = "Pronto a ricevere\n$name\n${renderer?.ip}:${renderer?.port}\nv${BuildConfig.VERSION_NAME}"
        }, 300)
    }

    override fun onStop() {
        renderer?.stop()
        renderer = null
        player.pause()
        super.onStop()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }

    private fun updateTransport() {
        transport = when {
            uri.isEmpty() -> "NO_MEDIA_PRESENT"
            loadJob?.isActive == true -> "TRANSITIONING"
            player.playbackState == Player.STATE_BUFFERING -> "TRANSITIONING"
            player.playbackState == Player.STATE_READY && player.playWhenReady -> "PLAYING"
            player.playbackState == Player.STATE_READY -> "PAUSED_PLAYBACK"
            else -> "STOPPED"
        }
        idle.visibility = if (uri.isEmpty() || player.playbackState == Player.STATE_IDLE) View.VISIBLE else View.GONE
        renderer?.stateChanged()
    }

    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val task = FutureTask(Callable { block() })
        main.post(task)
        return task.get(5, TimeUnit.SECONDS)
    }

    // ---------------- RendererBackend ----------------

    override fun setUri(uri: String, title: String, metadata: String) {
        onMain { load(uri, title, metadata) }
    }

    private fun load(uri: String, title: String, metadata: String) {
        this.uri = uri
        this.metadata = metadata
        loadJob?.cancel()
        val ytId = YT_ID.find(uri)?.groupValues?.get(1)
        val meta = MediaMetadata.Builder().setTitle(title).build()
        if (ytId != null) {
            Diagnostics.log("Ricevitore: YouTube $ytId")
            loadJob = lifecycleScope.launch {
                try {
                    val s = resolver.resolve(ytId, audioOnly = false)
                    player.setMediaItem(
                        YouTubeMediaSourceFactory.mediaItemFor(s, meta.buildUpon().setTitle(title.ifBlank { s.title }).build())
                    )
                    player.prepare()
                } catch (e: Exception) {
                    Diagnostics.log("Ricevitore: risoluzione fallita ${e.message}")
                    transport = "STOPPED"
                } finally {
                    updateTransport()
                }
            }
        } else {
            player.setMediaItem(MediaItem.Builder().setUri(Uri.parse(uri)).setMediaMetadata(meta).build())
            player.prepare()
        }
        updateTransport()
    }

    override fun play() {
        onMain {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.playWhenReady = true
        }
    }

    override fun pause() {
        onMain { player.pause() }
    }

    override fun stop() {
        onMain {
            player.pause()
            player.seekTo(0)
            transport = "STOPPED"
        }
    }

    override fun seek(ms: Long) {
        onMain { player.seekTo(ms) }
    }

    override fun setVolume(v: Int) {
        onMain {
            volume = v.coerceIn(0, 100)
            applyVolume()
        }
    }

    override fun setMute(m: Boolean) {
        onMain {
            mute = m
            applyVolume()
        }
    }

    private fun applyVolume() { player.volume = if (mute) 0f else volume / 100f }

    override fun snapshot(): RendererState = onMain {
        RendererState(
            transport = transport,
            uri = uri,
            metadata = metadata,
            positionMs = player.currentPosition,
            durationMs = player.duration.takeIf { it > 0 } ?: 0,
            volume = volume,
            mute = mute,
        )
    }

    companion object {
        private val YT_ID = Regex("""(?:youtu\.be/|[?&]v=|/shorts/|/embed/|tubetto://video/)([A-Za-z0-9_-]{11})""")
    }
}
