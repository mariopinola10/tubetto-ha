package it.gerry.tubetto.data

/**
 * Tiene solo le versioni "canzone": scarta extended, loop di ore, album interi,
 * versioni rallentate/velocizzate, karaoke… salvo che le chiedi esplicitamente.
 */
object MusicFilter {

    private val UNWANTED = Regex(
        "(?i)(extended|\\b\\d+\\s*(hours?|ore|ora)\\b|\\b1\\s*hour\\b|full album|album completo|" +
            "\\bloop\\b|nightcore|slowed|sped\\s*up|reverb|8d audio|karaoke|mashup|megamix|mix \\d{4}|" +
            "compilation|playlist|non stop|nonstop)"
    )

    /** Video che parlano dell'artista ma non sono canzoni. */
    private val NOT_A_SONG = Regex(
        "(?i)(incident|intervist|interview|\\bnews\\b|notizi|\\btg\\d*\\b|telegiornale|reaction|reazione|podcast|" +
            "backstage|vlog|documentari|trailer|parodia|tutorial|making of|dietro le quinte|conferenza|annuncia|" +
            "ospedale|morto|morte|addio|malore|polemica|gossip|fidanzat|matrimonio|shorts?\\b|#shorts)"
    )

    fun isSong(v: VideoItem, query: String = ""): Boolean =
        !(NOT_A_SONG.containsMatchIn(v.title) && !NOT_A_SONG.containsMatchIn(query))

    /** Durata massima di una canzone "normale": oltre si scarta (album, mix, live interi). */
    private const val MAX_SECONDS = 9 * 60

    fun clean(items: List<VideoItem>, query: String = ""): List<VideoItem> {
        val asked = UNWANTED.containsMatchIn(query)
        val out = items.filter { v ->
            if (v.kind != ItemKind.VIDEO) return@filter true
            if (!asked && UNWANTED.containsMatchIn(v.title)) return@filter false
            if (!isSong(v, query)) return@filter false
            val secs = seconds(v.duration)
            secs == null || secs <= MAX_SECONDS
        }
        // Se il filtro svuota tutto, meglio qualcosa che niente
        return out.ifEmpty { items }
    }

    private fun seconds(d: String): Int? {
        val p = d.trim().split(":").map { it.toIntOrNull() ?: return null }
        return when (p.size) {
            2 -> p[0] * 60 + p[1]
            3 -> p[0] * 3600 + p[1] * 60 + p[2]
            else -> null
        }
    }
}
