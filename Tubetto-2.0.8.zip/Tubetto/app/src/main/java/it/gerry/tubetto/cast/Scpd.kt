package it.gerry.tubetto.cast

/** Descrizioni dei servizi UPnP (SCPD) generate da una specifica compatta. */
object Scpd {

    private class Action(val name: String, val ins: List<Pair<String, String>>, val outs: List<Pair<String, String>> = emptyList())

    private fun build(actions: List<Action>, vars: List<Triple<String, String, Boolean>>, allowed: Map<String, List<String>> = emptyMap()): String {
        val sb = StringBuilder("""<?xml version="1.0" encoding="utf-8"?><scpd xmlns="urn:schemas-upnp-org:service-1-0">""")
        sb.append("<specVersion><major>1</major><minor>0</minor></specVersion><actionList>")
        for (a in actions) {
            sb.append("<action><name>${a.name}</name><argumentList>")
            a.ins.forEach { (n, v) -> sb.append("<argument><name>$n</name><direction>in</direction><relatedStateVariable>$v</relatedStateVariable></argument>") }
            a.outs.forEach { (n, v) -> sb.append("<argument><name>$n</name><direction>out</direction><relatedStateVariable>$v</relatedStateVariable></argument>") }
            sb.append("</argumentList></action>")
        }
        sb.append("</actionList><serviceStateTable>")
        for ((name, type, events) in vars) {
            sb.append("<stateVariable sendEvents=\"${if (events) "yes" else "no"}\"><name>$name</name><dataType>$type</dataType>")
            allowed[name]?.let { list ->
                sb.append("<allowedValueList>")
                list.forEach { sb.append("<allowedValue>$it</allowedValue>") }
                sb.append("</allowedValueList>")
            }
            if (name == "Volume") sb.append("<allowedValueRange><minimum>0</minimum><maximum>100</maximum><step>1</step></allowedValueRange>")
            sb.append("</stateVariable>")
        }
        sb.append("</serviceStateTable></scpd>")
        return sb.toString()
    }

    private val ID = "InstanceID" to "A_ARG_TYPE_InstanceID"

    val AVT: String = build(
        listOf(
            Action("SetAVTransportURI", listOf(ID, "CurrentURI" to "AVTransportURI", "CurrentURIMetaData" to "AVTransportURIMetaData")),
            Action("GetMediaInfo", listOf(ID), listOf(
                "NrTracks" to "NumberOfTracks", "MediaDuration" to "CurrentMediaDuration",
                "CurrentURI" to "AVTransportURI", "CurrentURIMetaData" to "AVTransportURIMetaData",
                "NextURI" to "NextAVTransportURI", "NextURIMetaData" to "NextAVTransportURIMetaData",
                "PlayMedium" to "PlaybackStorageMedium", "RecordMedium" to "RecordStorageMedium",
                "WriteStatus" to "RecordMediumWriteStatus",
            )),
            Action("GetTransportInfo", listOf(ID), listOf(
                "CurrentTransportState" to "TransportState", "CurrentTransportStatus" to "TransportStatus",
                "CurrentSpeed" to "TransportPlaySpeed",
            )),
            Action("GetPositionInfo", listOf(ID), listOf(
                "Track" to "CurrentTrack", "TrackDuration" to "CurrentTrackDuration",
                "TrackMetaData" to "CurrentTrackMetaData", "TrackURI" to "CurrentTrackURI",
                "RelTime" to "RelativeTimePosition", "AbsTime" to "AbsoluteTimePosition",
                "RelCount" to "RelativeCounterPosition", "AbsCount" to "AbsoluteCounterPosition",
            )),
            Action("GetDeviceCapabilities", listOf(ID), listOf(
                "PlayMedia" to "PossiblePlaybackStorageMedia", "RecMedia" to "PossibleRecordStorageMedia",
                "RecQualityModes" to "PossibleRecordQualityModes",
            )),
            Action("GetTransportSettings", listOf(ID), listOf("PlayMode" to "CurrentPlayMode", "RecQualityMode" to "CurrentRecordQualityMode")),
            Action("GetCurrentTransportActions", listOf(ID), listOf("Actions" to "CurrentTransportActions")),
            Action("Stop", listOf(ID)),
            Action("Play", listOf(ID, "Speed" to "TransportPlaySpeed")),
            Action("Pause", listOf(ID)),
            Action("Seek", listOf(ID, "Unit" to "A_ARG_TYPE_SeekMode", "Target" to "A_ARG_TYPE_SeekTarget")),
        ),
        listOf(
            Triple("LastChange", "string", true),
            Triple("TransportState", "string", false),
            Triple("TransportStatus", "string", false),
            Triple("TransportPlaySpeed", "string", false),
            Triple("NumberOfTracks", "ui4", false),
            Triple("CurrentTrack", "ui4", false),
            Triple("CurrentTrackDuration", "string", false),
            Triple("CurrentMediaDuration", "string", false),
            Triple("CurrentTrackMetaData", "string", false),
            Triple("CurrentTrackURI", "string", false),
            Triple("AVTransportURI", "string", false),
            Triple("AVTransportURIMetaData", "string", false),
            Triple("NextAVTransportURI", "string", false),
            Triple("NextAVTransportURIMetaData", "string", false),
            Triple("RelativeTimePosition", "string", false),
            Triple("AbsoluteTimePosition", "string", false),
            Triple("RelativeCounterPosition", "i4", false),
            Triple("AbsoluteCounterPosition", "i4", false),
            Triple("PlaybackStorageMedium", "string", false),
            Triple("RecordStorageMedium", "string", false),
            Triple("RecordMediumWriteStatus", "string", false),
            Triple("PossiblePlaybackStorageMedia", "string", false),
            Triple("PossibleRecordStorageMedia", "string", false),
            Triple("PossibleRecordQualityModes", "string", false),
            Triple("CurrentPlayMode", "string", false),
            Triple("CurrentRecordQualityMode", "string", false),
            Triple("CurrentTransportActions", "string", false),
            Triple("A_ARG_TYPE_SeekMode", "string", false),
            Triple("A_ARG_TYPE_SeekTarget", "string", false),
            Triple("A_ARG_TYPE_InstanceID", "ui4", false),
        ),
        mapOf(
            "TransportState" to listOf("STOPPED", "PLAYING", "TRANSITIONING", "PAUSED_PLAYBACK", "NO_MEDIA_PRESENT"),
            "TransportStatus" to listOf("OK", "ERROR_OCCURRED"),
            "A_ARG_TYPE_SeekMode" to listOf("REL_TIME", "ABS_TIME"),
            "CurrentPlayMode" to listOf("NORMAL"),
        ),
    )

    val RCS: String = build(
        listOf(
            Action("GetVolume", listOf(ID, "Channel" to "A_ARG_TYPE_Channel"), listOf("CurrentVolume" to "Volume")),
            Action("SetVolume", listOf(ID, "Channel" to "A_ARG_TYPE_Channel", "DesiredVolume" to "Volume")),
            Action("GetMute", listOf(ID, "Channel" to "A_ARG_TYPE_Channel"), listOf("CurrentMute" to "Mute")),
            Action("SetMute", listOf(ID, "Channel" to "A_ARG_TYPE_Channel", "DesiredMute" to "Mute")),
        ),
        listOf(
            Triple("LastChange", "string", true),
            Triple("Volume", "ui2", false),
            Triple("Mute", "boolean", false),
            Triple("A_ARG_TYPE_Channel", "string", false),
            Triple("A_ARG_TYPE_InstanceID", "ui4", false),
        ),
        mapOf("A_ARG_TYPE_Channel" to listOf("Master")),
    )

    val CMS: String = build(
        listOf(
            Action("GetProtocolInfo", emptyList(), listOf("Source" to "SourceProtocolInfo", "Sink" to "SinkProtocolInfo")),
            Action("GetCurrentConnectionIDs", emptyList(), listOf("ConnectionIDs" to "CurrentConnectionIDs")),
            Action("GetCurrentConnectionInfo", listOf("ConnectionID" to "A_ARG_TYPE_ConnectionID"), listOf(
                "RcsID" to "A_ARG_TYPE_RcsID", "AVTransportID" to "A_ARG_TYPE_AVTransportID",
                "ProtocolInfo" to "A_ARG_TYPE_ProtocolInfo", "PeerConnectionManager" to "A_ARG_TYPE_ConnectionManager",
                "PeerConnectionID" to "A_ARG_TYPE_ConnectionID", "Direction" to "A_ARG_TYPE_Direction",
                "Status" to "A_ARG_TYPE_ConnectionStatus",
            )),
        ),
        listOf(
            Triple("SourceProtocolInfo", "string", true),
            Triple("SinkProtocolInfo", "string", true),
            Triple("CurrentConnectionIDs", "string", true),
            Triple("A_ARG_TYPE_ConnectionID", "i4", false),
            Triple("A_ARG_TYPE_RcsID", "i4", false),
            Triple("A_ARG_TYPE_AVTransportID", "i4", false),
            Triple("A_ARG_TYPE_ProtocolInfo", "string", false),
            Triple("A_ARG_TYPE_ConnectionManager", "string", false),
            Triple("A_ARG_TYPE_Direction", "string", false),
            Triple("A_ARG_TYPE_ConnectionStatus", "string", false),
        ),
        mapOf(
            "A_ARG_TYPE_Direction" to listOf("Input", "Output"),
            "A_ARG_TYPE_ConnectionStatus" to listOf("OK", "ContentFormatMismatch", "InsufficientBandwidth", "UnreliableChannel", "Unknown"),
        ),
    )
}
