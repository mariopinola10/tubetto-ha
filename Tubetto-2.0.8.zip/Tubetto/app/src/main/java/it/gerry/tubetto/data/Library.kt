package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Preferiti, canali seguiti e playlist create dall'utente, salvati sul telefono. */
object Library {
    private lateinit var sp: SharedPreferences
    private val favorites = mutableListOf<VideoItem>()
    private val channels = mutableListOf<VideoItem>()
    private val artists = mutableListOf<VideoItem>()
    private val playlists = LinkedHashMap<String, MutableList<VideoItem>>()

    /** Ultima modifica della libreria (per la sincronizzazione tra dispositivi). */
    @Volatile var modified: Long = 0L
        private set

    /** Chiamato a ogni modifica (la sincronizzazione programma l'invio). */
    @Volatile var onChanged: (() -> Unit)? = null

    fun init(context: Context) {
        sp = context.getSharedPreferences("library", Context.MODE_PRIVATE)
        runCatching {
            favorites += readList(JSONArray(sp.getString("favorites", "[]")))
            channels += readList(JSONArray(sp.getString("channels", "[]")))
            artists += readList(JSONArray(sp.getString("artists", "[]")))
            val pl = JSONObject(sp.getString("playlists", "{}"))
            for (name in pl.keys()) playlists[name] = readList(pl.getJSONArray(name)).toMutableList()
        }
        modified = sp.getLong("modified", 0L)
    }

    // ---------------- Preferiti ----------------

    @Synchronized fun favorites(): List<VideoItem> = favorites.toList()
    @Synchronized fun isFavorite(id: String) = favorites.any { it.id == id }

    /** @return true se ora è nei preferiti. */
    @Synchronized
    fun toggleFavorite(v: VideoItem): Boolean {
        val removed = favorites.removeAll { it.id == v.id }
        if (!removed) favorites.add(0, v)
        save()
        return !removed
    }

    // ---------------- Canali ----------------

    @Synchronized fun channels(): List<VideoItem> = channels.toList()
    @Synchronized fun isFollowed(channelId: String) = channels.any { it.id == channelId }

    @Synchronized
    fun toggleChannel(c: VideoItem): Boolean {
        val removed = channels.removeAll { it.id == c.id }
        if (!removed) channels.add(0, c.copy(kind = ItemKind.CHANNEL))
        save()
        return !removed
    }

    // ---------------- Artisti ----------------

    @Synchronized fun artists(): List<VideoItem> = artists.toList()
    @Synchronized fun isArtistFollowed(name: String) = artists.any { it.id.equals(name, ignoreCase = true) }
    @Synchronized fun artistChannel(name: String): String? = artists.firstOrNull { it.id.equals(name, ignoreCase = true) }?.channelId

    /** @return true se ora è tra gli artisti seguiti. */
    @Synchronized
    fun toggleArtist(name: String, thumb: String? = null, channelId: String? = null): Boolean {
        val removed = artists.removeAll { it.id.equals(name, ignoreCase = true) }
        if (!removed) {
            artists.add(
                0,
                VideoItem(
                    id = name, title = name, author = "Artista", duration = "",
                    thumbnailUrl = thumb, kind = ItemKind.ARTIST, channelId = channelId,
                ),
            )
        }
        save()
        return !removed
    }

    // ---------------- Playlist personali ----------------

    @Synchronized fun playlistNames(): List<String> = playlists.keys.toList()
    @Synchronized fun playlist(name: String): List<VideoItem> = playlists[name]?.toList().orEmpty()

    @Synchronized
    fun createPlaylist(name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || playlists.containsKey(n)) return false
        playlists[n] = mutableListOf()
        save()
        return true
    }

    @Synchronized
    fun addToPlaylist(name: String, v: VideoItem): Boolean {
        val list = playlists.getOrPut(name) { mutableListOf() }
        if (list.any { it.id == v.id }) return false
        list += v
        save()
        return true
    }

    @Synchronized
    fun removeFromPlaylist(name: String, id: String) {
        playlists[name]?.removeAll { it.id == id }
        save()
    }

    @Synchronized
    fun deletePlaylist(name: String) {
        playlists.remove(name)
        save()
    }

    @Synchronized
    fun renamePlaylist(old: String, new: String): Boolean {
        val n = new.trim()
        if (n.isEmpty() || playlists.containsKey(n)) return false
        val items = playlists.remove(old) ?: return false
        playlists[n] = items
        save()
        return true
    }

    /** Le playlist personali come elementi della lista. */
    @Synchronized
    fun playlistItems(): List<VideoItem> = playlists.map { (name, items) ->
        VideoItem(
            id = LOCAL_PREFIX + name,
            title = name,
            author = "La mia playlist",
            duration = "${items.size} brani",
            thumbnailUrl = items.firstOrNull()?.thumbnail,
            kind = ItemKind.PLAYLIST,
        )
    }

    const val LOCAL_PREFIX = "local:"

    // ---------------- Persistenza ----------------

    /** Tutta la libreria in JSON (per la sincronizzazione). */
    @Synchronized
    fun exportJson(): JSONObject {
        val pl = JSONObject()
        playlists.forEach { (name, items) -> pl.put(name, writeList(items)) }
        return JSONObject()
            .put("modified", modified)
            .put("favorites", writeList(favorites))
            .put("channels", writeList(channels))
            .put("artists", writeList(artists))
            .put("playlists", pl)
    }

    /** Sostituisce la libreria con quella più recente arrivata da un altro dispositivo. */
    @Synchronized
    fun importJson(o: JSONObject) {
        favorites.clear(); favorites += readList(o.optJSONArray("favorites") ?: JSONArray())
        channels.clear(); channels += readList(o.optJSONArray("channels") ?: JSONArray())
        artists.clear(); artists += readList(o.optJSONArray("artists") ?: JSONArray())
        playlists.clear()
        o.optJSONObject("playlists")?.let { pl ->
            for (name in pl.keys()) playlists[name] = readList(pl.getJSONArray(name)).toMutableList()
        }
        modified = o.optLong("modified", System.currentTimeMillis())
        save(notify = false)
    }

    private fun save(notify: Boolean = true) {
        if (notify) modified = System.currentTimeMillis()
        val pl = JSONObject()
        playlists.forEach { (name, items) -> pl.put(name, writeList(items)) }
        sp.edit()
            .putLong("modified", modified)
            .putString("favorites", writeList(favorites).toString())
            .putString("channels", writeList(channels).toString())
            .putString("artists", writeList(artists).toString())
            .putString("playlists", pl.toString())
            .apply()
        if (notify) onChanged?.invoke()
    }

    private fun writeList(list: List<VideoItem>) = JSONArray().apply {
        list.forEach {
            put(
                JSONObject()
                    .put("id", it.id).put("title", it.title).put("author", it.author)
                    .put("duration", it.duration).put("thumb", it.thumbnailUrl ?: it.thumbnail)
                    .put("kind", it.kind.name).put("channelId", it.channelId ?: "")
            )
        }
    }

    private fun readList(arr: JSONArray): List<VideoItem> = (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        VideoItem(
            id = o.getString("id"),
            title = o.optString("title"),
            author = o.optString("author"),
            duration = o.optString("duration"),
            thumbnailUrl = o.optString("thumb").ifBlank { null },
            kind = runCatching { ItemKind.valueOf(o.optString("kind")) }.getOrDefault(ItemKind.VIDEO),
            channelId = o.optString("channelId").ifBlank { null },
        )
    }
}
