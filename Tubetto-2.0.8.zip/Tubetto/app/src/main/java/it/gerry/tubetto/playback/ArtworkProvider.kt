package it.gerry.tubetto.playback

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.ParcelFileDescriptor
import it.gerry.tubetto.net.Http
import okhttp3.Request
import java.io.File
import java.security.MessageDigest

/**
 * Copertine per Android Auto: l'auto mostra in modo affidabile solo immagini content://,
 * non link web. Questo provider:
 *  - /img   scarica la miniatura una volta e la tiene in cache;
 *  - /round ritaglia la foto in un cerchio (artisti, come Spotify);
 *  - /tile  disegna un riquadro colorato con simbolo o copertina inclinata (categorie, playlist).
 */
class ArtworkProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val ctx = context ?: return null
        val dir = File(ctx.cacheDir, "art").apply { mkdirs() }
        val url = uri.getQueryParameter("u")
        val file: File? = try {
            when (uri.lastPathSegment) {
                "round" -> renderRound(dir, uri, url)
                "tile" -> renderTile(dir, uri, url)
                "collage" -> renderCollage(dir, uri)
                else -> if (url != null) download(dir, url) else null
            }
        } catch (e: Exception) {
            null
        }
        return file?.let { ParcelFileDescriptor.open(it, ParcelFileDescriptor.MODE_READ_ONLY) }
    }

    override fun getType(uri: Uri): String =
        if (uri.lastPathSegment in setOf("round", "tile", "collage")) "image/png" else "image/jpeg"

    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?): Int = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?): Int = 0

    private fun allowed(url: String): Boolean {
        val host = Uri.parse(url).host ?: return false
        return ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") }
    }

    private fun download(dir: File, url: String): File? {
        if (!allowed(url)) return null
        val file = File(dir, sha1(url))
        if (file.exists() && file.length() > 0L) return file
        val tmp = File(dir, file.name + ".tmp")
        Http.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) return null
            val body = r.body ?: return null
            body.byteStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
        }
        tmp.renameTo(file)
        trim(dir)
        return file
    }

    /** Foto rotonda (artisti). */
    private fun renderRound(dir: File, uri: Uri, url: String?): File? {
        val out = File(dir, "r_" + sha1(uri.toString()) + ".png")
        if (out.exists() && out.length() > 0L) return out
        val src = url?.let { download(dir, it) } ?: return null
        val bmp = BitmapFactory.decodeFile(src.path) ?: return null
        val size = SIZE.toFloat()
        val result = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val scale = size / minOf(bmp.width, bmp.height)
        val m = Matrix().apply {
            setScale(scale, scale)
            postTranslate((size - bmp.width * scale) / 2f, (size - bmp.height * scale) / 2f)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply { setLocalMatrix(m) }
        }
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        save(result, out)
        return out
    }

    /** Mosaico 2×2 con le copertine dei primi 4 brani (playlist, preferiti, mix). */
    private fun renderCollage(dir: File, uri: Uri): File? {
        val out = File(dir, "c_" + sha1(uri.toString()) + ".png")
        if (out.exists() && out.length() > 0L) return out
        val urls = uri.getQueryParameters("u").take(4)
        if (urls.size < 4) return null
        val parts = urls.map { u -> download(dir, u)?.let { BitmapFactory.decodeFile(it.path) } ?: return null }
        val result = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val half = SIZE / 2
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        parts.forEachIndexed { i, bmp ->
            val side = minOf(bmp.width, bmp.height)
            val src = android.graphics.Rect((bmp.width - side) / 2, (bmp.height - side) / 2, (bmp.width + side) / 2, (bmp.height + side) / 2)
            val x = (i % 2) * half
            val y = (i / 2) * half
            canvas.drawBitmap(bmp, src, android.graphics.Rect(x, y, x + half, y + half), paint)
        }
        save(result, out)
        return out
    }

    /** Riquadro colorato stile Spotify: sfumatura, copertina inclinata o simbolo. */
    private fun renderTile(dir: File, uri: Uri, url: String?): File? {
        val out = File(dir, "t_" + sha1(uri.toString()) + ".png")
        if (out.exists() && out.length() > 0L) return out
        val color = runCatching { Color.parseColor(uri.getQueryParameter("c") ?: "#0A84D0") }.getOrDefault(Color.parseColor("#0A84D0"))
        val symbol = uri.getQueryParameter("s")
        val size = SIZE.toFloat()
        val result = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, size, size, lighter(color), darker(color), Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(RectF(0f, 0f, size, size), size * 0.08f, size * 0.08f, bg)

        val cover = url?.let { runCatching { download(dir, it) }.getOrNull() }?.let { BitmapFactory.decodeFile(it.path) }
        if (cover != null) {
            // copertina inclinata nell'angolo in basso a destra
            val side = size * 0.58f
            val crop = minOf(cover.width, cover.height)
            val sq = Bitmap.createBitmap(cover, (cover.width - crop) / 2, (cover.height - crop) / 2, crop, crop)
            canvas.save()
            canvas.translate(size * 0.70f, size * 0.70f)
            canvas.rotate(22f)
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.argb(90, 0, 0, 0) }
            canvas.drawRect(RectF(-side / 2 + 6, -side / 2 + 8, side / 2 + 6, side / 2 + 8), shadow)
            canvas.drawBitmap(sq, null, RectF(-side / 2, -side / 2, side / 2, side / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
        }
        if (!symbol.isNullOrBlank()) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = Color.WHITE
                textSize = if (cover != null) size * 0.26f else size * 0.42f
                typeface = Typeface.DEFAULT_BOLD
                textAlign = Paint.Align.CENTER
                setShadowLayer(8f, 0f, 3f, Color.argb(80, 0, 0, 0))
            }
            val cx = if (cover != null) size * 0.27f else size / 2f
            val cy = (if (cover != null) size * 0.30f else size / 2f) - (tp.descent() + tp.ascent()) / 2f
            canvas.drawText(symbol, cx, cy, tp)
        }
        save(result, out)
        return out
    }

    private fun lighter(c: Int): Int = Color.rgb(
        minOf(255, Color.red(c) + 40), minOf(255, Color.green(c) + 40), minOf(255, Color.blue(c) + 40),
    )

    private fun darker(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.6f).toInt(), (Color.green(c) * 0.6f).toInt(), (Color.blue(c) * 0.6f).toInt(),
    )

    private fun save(bmp: Bitmap, out: File) {
        val tmp = File(out.parentFile, out.name + ".tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        tmp.renameTo(out)
    }

    private fun trim(dir: File) {
        val files = dir.listFiles()?.filter { it.isFile } ?: return
        if (files.size > 600) files.sortedBy { it.lastModified() }.take(files.size - 600).forEach { it.delete() }
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    companion object {
        const val AUTHORITY = "it.gerry.tubetto.art"
        private const val SIZE = 320
        private val ALLOWED_HOSTS = listOf("ytimg.com", "ggpht.com", "googleusercontent.com", "ytimg.googleusercontent.com")

        /** Converte un link web di copertina in content:// leggibile da Android Auto. */
        fun uriFor(url: String?): Uri? {
            if (url.isNullOrBlank()) return null
            if (!url.startsWith("http")) return Uri.parse(url)
            return Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("img")
                .appendQueryParameter("u", url).build()
        }

        fun uriFor(uri: Uri?): Uri? = uri?.let { if (it.scheme?.startsWith("http") == true) uriFor(it.toString()) else it }

        /** Foto rotonda (artisti). */
        fun roundUri(url: String?): Uri? {
            if (url.isNullOrBlank() || !url.startsWith("http")) return null
            return Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("round")
                .appendQueryParameter("u", url).build()
        }

        /**
         * Copertina di una raccolta: mosaico 2×2 se ci sono almeno 4 brani, altrimenti la copertina del primo.
         * null se la raccolta è vuota.
         */
        fun collageUri(covers: List<String>): Uri? {
            val list = covers.filter { it.startsWith("http") }.distinct()
            if (list.isEmpty()) return null
            if (list.size < 4) return uriFor(list.first())
            val b = Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("collage")
            list.take(4).forEach { b.appendQueryParameter("u", it) }
            return b.build()
        }

        /** Riquadro colorato con simbolo e/o copertina inclinata. */
        fun tileUri(color: String, symbol: String? = null, cover: String? = null): Uri {
            val b = Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("tile")
                .appendQueryParameter("c", color)
            if (!symbol.isNullOrBlank()) b.appendQueryParameter("s", symbol)
            if (!cover.isNullOrBlank() && cover.startsWith("http")) b.appendQueryParameter("u", cover)
            return b.build()
        }
    }
}
