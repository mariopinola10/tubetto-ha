package it.gerry.tubetto.playback

import android.content.Context

/** Riproduzione automatica: alla fine di un video/brano continua con contenuti simili. */
object AutoplayPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("audio", Context.MODE_PRIVATE)
    fun enabled(c: Context): Boolean = sp(c).getBoolean("autoplay", true)
    fun set(c: Context, on: Boolean) = sp(c).edit().putBoolean("autoplay", on).apply()
}
