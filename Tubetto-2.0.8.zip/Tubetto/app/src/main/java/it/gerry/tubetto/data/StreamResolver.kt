package it.gerry.tubetto.data

import android.net.Uri
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.services.youtube.YoutubeJavaScriptPlayerManager
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * Prova in cascata: InnerTube (IOS, ANDROID_VR, ANDROID) -> NewPipeExtractor -> muxed.
 * Ogni candidato viene verificato su due punti del file (inizio e metà) prima di usarlo.
 * [exclude] contiene le sorgenti già fallite in riproduzione per quel video.
 */
class StreamResolver(
    private val api: YouTubeApiHelper,
    /** Qualità video massima; aggiornata in base alla rete prima di ogni risoluzione. */
    var maxHeight: Int = 1080,
) {
    /** kbps massimi per l'audio (qualità/consumo dati). */
    @Volatile var audioMaxKbps: Int = 1000


    /**
     * @param muxedOnly solo stream unico audio+video (per DLNA: le TV non uniscono tracce separate)
     */
    suspend fun resolve(
        videoId: String,
        audioOnly: Boolean,
        exclude: Set<String> = emptySet(),
        muxedOnly: Boolean = false,
    ): ResolvedStream {
        // le dirette (HLS) vanno sempre bene: non hanno link separati da bloccare
        val wanted: (ResolvedStream) -> Boolean = { it.source !in exclude && (!muxedOnly || it.isMuxed || it.hlsUrl != null) }

        if (videoId in unplayable && !Account.isLoggedIn) throw LoginRequiredException(videoId)

        // Cache: riaprire lo stesso video è istantaneo
        val key = "$videoId|$audioOnly|$muxedOnly|$maxHeight|$audioMaxKbps"
        cache[key]?.let { (cached, t) ->
            if (System.currentTimeMillis() - t < CACHE_MS && wanted(cached)) return cached
        }
        val errors = mutableListOf<String>()

        // Link separati audio/video che si sono interrotti a metà (YouTube senza PO token):
        // per 30 minuti quel client usa direttamente lo stream unico, che non si interrompe.
        // Se succede con UN client succede con tutti (YouTube li blocca insieme): blocco globale,
        // salvato, così non si riprovano uno alla volta perdendo secondi a ogni brano.
        val now = System.currentTimeMillis()
        val brokenAdaptive = exclude.filter { !it.endsWith(":muxed") && !it.endsWith(":hls") && !it.startsWith("soundcloud") }
        if (brokenAdaptive.isNotEmpty()) blockAdaptive(now, brokenAdaptive.first())
        val adaptiveOk = now >= adaptiveBlockedUntil

        // Prima il client che ha funzionato l'ultima volta
        val order = Clients.PLAYER_ORDER.sortedBy { if (it.key == preferred) 0 else 1 }
        for (client in order) {
            val source = "innertube:${client.key}"
            if (source in exclude && "$source:muxed" in exclude) continue
            try {
                val candidates = StreamParser.parsePlayer(api.player(videoId, client), maxHeight, audioOnly, source, audioMaxKbps)
                    .filter(wanted)
                    .filter { it.isMuxed || it.hlsUrl != null || adaptiveOk }
                if (candidates.isEmpty()) errors += "$source: nessun URL diretto"
                for (c in candidates) {
                    val check = validate(c)
                    if (check == null) {
                        preferred = client.key
                        cache[key] = c to System.currentTimeMillis()
                        Diagnostics.log("OK $videoId via ${c.source}")
                        ServiceHealth.reportSuccess()
                        return c
                    }
                    errors += "${c.source}: $check"
                }
            } catch (e: Exception) {
                errors += "$source: ${e.message}"
            }
        }

        try {
            val candidates = withContext(Dispatchers.IO) { newPipeCandidates(videoId, audioOnly) }
                .filter(wanted)
                .filter { it.isMuxed || it.hlsUrl != null || adaptiveOk }
            for (c in candidates) {
                val check = validate(c)
                if (check == null) {
                    cache[key] = c to System.currentTimeMillis()
                    Diagnostics.log("OK $videoId via ${c.source}")
                    ServiceHealth.reportSuccess()
                    return c
                }
                errors += "${c.source}: $check"
            }
        } catch (e: Exception) {
            errors += "newpipe: ${e.javaClass.simpleName} ${e.message}"
        }

        // Ultima risorsa: l'account dell'utente, se ha fatto l'accesso (età, iscritti, controlli anti-bot)
        if (Account.isLoggedIn && "account:TV" !in exclude) {
            try {
                val acc = withContext(Dispatchers.IO) { accountCandidates(videoId, audioOnly) }
                    .filter(wanted)
                for (c in acc) {
                    val check = validate(c)
                    if (check == null) {
                        cache[key] = c to System.currentTimeMillis()
                        unplayable -= videoId
                        Diagnostics.log("OK $videoId via ${c.source} (con l'account)")
                        ServiceHealth.reportSuccess()
                        return c
                    }
                    errors += "${c.source}: $check"
                }
                if (acc.isEmpty()) errors += "account:TV: nessun URL"
            } catch (e: Exception) {
                errors += "account:TV: ${e.message}"
            }
        }

        // Piano B per la musica: lo stesso brano su SoundCloud (solo audio)
        if (audioOnly && exclude.none { it.startsWith("soundcloud") }) {
            try {
                val sc = withContext(Dispatchers.IO) { soundCloudCandidate(videoId) }
                if (sc != null) {
                    cache[key] = sc to System.currentTimeMillis()
                    Diagnostics.log("OK $videoId via soundcloud (${sc.author} — ${sc.title})")
                    return sc
                }
                errors += "soundcloud: nessun brano corrispondente"
            } catch (e: Exception) {
                errors += "soundcloud: ${e.javaClass.simpleName} ${e.message}"
            }
        }

        errors.forEach { Diagnostics.log("KO $videoId $it") }
        // Tutti i metodi chiedono l'accesso ma NON per il controllo anti-bot: il problema è il video
        // (limiti di età, riservato agli iscritti, privato). Inutile riprovare: si salta.
        val ytErrors = errors.filter { !it.startsWith("soundcloud") }
        if (ytErrors.isNotEmpty() && ytErrors.all { "LOGIN_REQUIRED" in it || "sign in" in it.lowercase() } &&
            ytErrors.none { "bot" in it.lowercase() }
        ) {
            unplayable += videoId
            Diagnostics.log("Salto $videoId: YouTube lo mostra solo con un account (età o accesso limitato)")
            throw LoginRequiredException(videoId)
        }
        ServiceHealth.reportFailure("Video $videoId:\n" + errors.joinToString("\n"))
        throw IOException("Nessuna sorgente funzionante:\n" + errors.joinToString("\n"))
    }

    /** Verifica in parallelo i link (inizio e metà file). @return null se ok, altrimenti l'errore. */
    private suspend fun validate(s: ResolvedStream): String? = withContext(Dispatchers.IO) {
        if (s.hlsUrl != null) return@withContext null
        val checks = listOfNotNull(s.videoUrl, s.audioUrl).flatMap { url ->
            val clen = Uri.parse(url).getQueryParameter("clen")?.toLongOrNull()
            buildList {
                add(url to 0L)
                if (clen != null && clen > 2_000_000) add(url to clen / 2)
            }
        }
        coroutineScope {
            checks.map { (url, start) ->
                async {
                    val code = runCatching {
                        Http.streamClient.newCall(
                            Request.Builder().url(url).header("Range", "bytes=$start-${start + 4095}").build()
                        ).execute().use { it.code }
                    }.getOrNull()
                    when {
                        code == null -> "rete non raggiungibile"
                        code in 200..299 -> null
                        else -> "HTTP $code (c=${Uri.parse(url).getQueryParameter("c")}, offset=$start)"
                    }
                }
            }.awaitAll().firstOrNull { it != null }
        }
    }


    /** Dimentica i link in cache di un video (es. dopo un errore in riproduzione). */
    fun invalidate(videoId: String) {
        cache.keys.removeAll { it.startsWith("$videoId|") }
    }

    /**
     * Cerca su SoundCloud lo stesso brano (titolo e artista noti dalla coda) e ne prende l'audio.
     * Scarta i risultati con durata troppo diversa (remix, versioni live, anteprime di 30 s).
     */
    private fun soundCloudCandidate(videoId: String): ResolvedStream? {
        val hint = hints[videoId] ?: return null
        val sc = ServiceList.SoundCloud
        val query = listOf(hint.title, hint.artist).filter { it.isNotBlank() }.joinToString(" ")
        if (query.isBlank()) return null
        val search = org.schabi.newpipe.extractor.search.SearchInfo.getInfo(
            sc, sc.searchQHFactory.fromQuery(query, listOf("tracks"), ""),
        )
        val items = search.relatedItems.filterIsInstance<org.schabi.newpipe.extractor.stream.StreamInfoItem>().take(8)
        val words = hint.title.lowercase().split(Regex("\\W+")).filter { it.length > 2 }
        val pick = items.firstOrNull { item ->
            val durOk = hint.durationMs <= 0 || item.duration <= 0 ||
                kotlin.math.abs(item.duration * 1000 - hint.durationMs) <= 20_000
            val nameOk = words.isEmpty() || words.count { item.name.lowercase().contains(it) } * 2 >= words.size
            durOk && nameOk && item.duration > 35
        } ?: return null

        val info = StreamInfo.getInfo(sc, pick.url)
        val audios = info.audioStreams.filter { it.isUrl }
        val progressive = audios.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }.maxByOrNull { it.averageBitrate }
        val hls = audios.filter { it.deliveryMethod == DeliveryMethod.HLS }.maxByOrNull { it.averageBitrate }
        val base = ResolvedStream(
            videoId = videoId,
            title = info.name,
            author = info.uploaderName.orEmpty(),
            thumbnail = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            durationMs = info.duration * 1000,
            videoUrl = null, audioUrl = null, hlsUrl = null,
            source = "soundcloud",
        )
        // Per ora solo i file audio diretti: i brani che SoundCloud offre solo a segmenti (HLS)
        // non passano dalla coda "pigra" del player.
        if (progressive == null) {
            if (hls != null) Diagnostics.log("soundcloud: ${pick.name} disponibile solo a segmenti, salto")
            return null
        }
        return base.copy(audioUrl = progressive.content)
    }

    /** Player con l'account: decifra firme e parametro "n" con il motore JavaScript di NewPipe. */
    private suspend fun accountCandidates(videoId: String, audioOnly: Boolean): List<ResolvedStream> {
        val sts = runCatching { YoutubeJavaScriptPlayerManager.getSignatureTimestamp(videoId) }.getOrNull()
        val json = api.playerAuthenticated(videoId, sts)
        json.optJSONObject("streamingData")?.let { sd ->
            listOf("formats", "adaptiveFormats").forEach { k ->
                val arr = sd.optJSONArray(k) ?: return@forEach
                for (i in 0 until arr.length()) {
                    val f = arr.optJSONObject(i) ?: continue
                    runCatching { decipher(videoId, f) }.onFailure { f.remove("url") }
                }
            }
        }
        return StreamParser.parsePlayer(json, maxHeight, audioOnly, "account:TV", audioMaxKbps)
    }

    private fun decipher(videoId: String, f: org.json.JSONObject) {
        val cipher = f.optString("signatureCipher").ifBlank { f.optString("cipher") }
        var url = if (cipher.isNotBlank()) {
            val q = cipher.split("&").associate { p -> p.substringBefore('=') to Uri.decode(p.substringAfter('=', "")) }
            val base = q["url"] ?: return
            val sig = YoutubeJavaScriptPlayerManager.deobfuscateSignature(videoId, q["s"].orEmpty())
            base + "&" + (q["sp"] ?: "sig") + "=" + Uri.encode(sig)
        } else {
            f.optString("url").ifBlank { return }
        }
        url = YoutubeJavaScriptPlayerManager.getUrlWithThrottlingParameterDeobfuscated(videoId, url)
        f.remove("signatureCipher")
        f.remove("cipher")
        f.put("url", url)
    }

    private fun newPipeCandidates(videoId: String, audioOnly: Boolean): List<ResolvedStream> {
        val info = StreamInfo.getInfo(ServiceList.YouTube, "https://www.youtube.com/watch?v=$videoId")
        val base = ResolvedStream(
            videoId = videoId,
            title = info.name,
            author = info.uploaderName.orEmpty(),
            thumbnail = info.thumbnails.maxByOrNull { it.height }?.url
                ?: "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            durationMs = info.duration * 1000,
            videoUrl = null, audioUrl = null, hlsUrl = null,
            source = "newpipe",
        )

        if (info.streamType == StreamType.LIVE_STREAM || info.streamType == StreamType.AUDIO_LIVE_STREAM) {
            val hls = info.hlsUrl.takeIf { !it.isNullOrBlank() } ?: throw IOException("Diretta senza HLS")
            return listOf(base.copy(hlsUrl = hls, source = "newpipe:hls"))
        }

        val out = mutableListOf<ResolvedStream>()
        val audios = info.audioStreams.filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val audio = audios.filter { it.averageBitrate in 1..audioMaxKbps }.maxByOrNull { it.averageBitrate }
            ?: audios.minByOrNull { it.averageBitrate }

        if (audio != null) {
            if (audioOnly) {
                out += base.copy(audioUrl = audio.content)
            } else {
                val video = info.videoOnlyStreams
                    .filter {
                        it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP &&
                            it.format == MediaFormat.MPEG_4 && it.height <= maxHeight
                    }
                    .maxByOrNull { it.height }
                if (video != null) out += base.copy(videoUrl = video.content, audioUrl = audio.content)
            }
        }

        info.videoStreams
            .filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .maxByOrNull { it.height }
            ?.let { out += base.copy(videoUrl = it.content, source = "newpipe:muxed") }

        return out
    }

    companion object {
        private const val CACHE_MS = 20 * 60 * 1000L
        private val cache = ConcurrentHashMap<String, Pair<ResolvedStream, Long>>()
        @Volatile private var preferred: String? = null

        /** Video che richiedono un account (età, iscritti): saltati per tutta la sessione. */
        private val unplayable = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

        /** Fino a quando usare solo lo stream unico (link separati interrotti da YouTube). */
        @Volatile private var adaptiveBlockedUntil = 0L
        private var prefs: android.content.SharedPreferences? = null
        private const val BLOCK_MS = 6 * 60 * 60_000L

        /** Titolo e artista dei brani in coda: servono al piano B (SoundCloud). */
        data class Hint(val title: String, val artist: String, val durationMs: Long)
        private val hints = ConcurrentHashMap<String, Hint>()

        fun hint(videoId: String, title: String?, artist: String?, durationMs: Long? = null) {
            if (title.isNullOrBlank()) return
            hints[videoId] = Hint(title, artist.orEmpty(), durationMs ?: 0L)
            if (hints.size > 2000) hints.keys.take(500).forEach { hints.remove(it) }
        }

        fun init(context: android.content.Context) {
            prefs = context.getSharedPreferences("resolver", android.content.Context.MODE_PRIVATE)
            adaptiveBlockedUntil = prefs?.getLong("adaptiveBlockedUntil", 0L) ?: 0L
        }

        private fun blockAdaptive(now: Long, source: String) {
            if (now < adaptiveBlockedUntil) return
            adaptiveBlockedUntil = now + BLOCK_MS
            prefs?.edit()?.putLong("adaptiveBlockedUntil", adaptiveBlockedUntil)?.apply()
            // anche i brani già preparati in coda con link separati vanno rifatti
            cache.entries.removeAll { !it.value.first.isMuxed }
            Diagnostics.log("$source: link separati interrotti, uso lo stream unico per 6 ore (tutti i client)")
        }
    }
}

/** Il video si può vedere solo con un account YouTube: non è un guasto dell'app, si passa oltre. */
class LoginRequiredException(val videoId: String) :
    IOException("Video non riproducibile senza account YouTube (limiti di età o accesso riservato)")
