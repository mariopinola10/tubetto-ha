package it.gerry.tubetto.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/**
 * Suggerimenti basati sulla cronologia d'ascolto, diversi per modalità:
 * video (tutto), musica (solo brani), playlist (playlist musicali), canali.
 */
class Recommender(private val api: YouTubeApiHelper) {

    data class Suggestions(val items: List<VideoItem>, val basedOn: List<String>)

    /** Video: correlati di tutto ciò che guardi/ascolti. */
    suspend fun forYou(limit: Int = 40): Suggestions =
        mix(ListenHistory.seeds(4), limit) { runCatching { api.searchMusic("hit del momento italia") }.getOrDefault(emptyList()) }

    /** Musica: solo brani, dalla radio di YouTube Music dei tuoi ascolti musicali. */
    suspend fun musicForYou(limit: Int = 40): Suggestions = coroutineScope {
        val news = Library.artists().take(3).map { a ->
            async { runCatching { api.searchRecent(a.id).take(3) }.getOrDefault(emptyList()) }
        }
        val base = mix(ListenHistory.seeds(4, musicOnly = true), limit, forceMusic = true) {
            // Nessun ascolto ancora: brani dei generi scelti al primo avvio, altrimenti le classifiche
            val genres = UserProfile.genreQueries().take(4)
            if (genres.isNotEmpty()) {
                interleave(genres.map { q -> runCatching { api.searchMusic(q).take(10) }.getOrDefault(emptyList()) }, limit)
            } else {
                runCatching { api.musicCharts() }.getOrDefault(emptyList())
            }
        }
        val fresh = news.awaitAll().flatten()
        val ids = fresh.map { it.id }.toSet()
        Suggestions(fresh + base.items.filter { it.id !in ids }, base.basedOn)
    }

    /** Playlist musicali dei tuoi artisti preferiti. */
    suspend fun playlistsForYou(): Suggestions = coroutineScope {
        val artists = ListenHistory.topArtists(4, musicOnly = true)
        val queries = if (artists.isEmpty()) {
            UserProfile.genres.take(3).map { "playlist $it" }.ifEmpty { listOf("playlist hit italiane", "playlist musica pop", "playlist relax musica") }
        }
        else artists.map { "$it playlist" }
        val lists = queries.map { q -> async { runCatching { api.searchPlaylists(q).take(6) }.getOrDefault(emptyList()) } }.awaitAll()
        Suggestions(interleave(lists, 40), artists)
    }

    /** Canali: solo quelli che segui. */
    suspend fun channelsForYou(): Suggestions = Suggestions(Library.channels(), emptyList())

    /**
     * "Il mio mix": canzoni preferite + brani più ascoltati + canzoni dei tuoi artisti
     * + brani simili (radio di YouTube Music partendo dai tuoi preferiti).
     * Le fonti si alternano e non ci sono doppioni, nemmeno tra video diversi della stessa canzone.
     */
    suspend fun myMix(limit: Int = 60): Suggestions = coroutineScope {
        val fav = Library.favorites().filter { it.kind == ItemKind.VIDEO }.shuffled()
        val top = ListenHistory.all().filter { it.music && it.count >= 2 }
            .sortedByDescending { it.count }.take(20).map { it.toVideoItem() }.shuffled()
        val artists = Library.artists().map { it.id }

        val perArtist = artists.shuffled().take(10).map { a ->
            async {
                runCatching {
                    api.searchMusic(a)
                        .filter { MetaCleaner.cleanArtist(it.author).contains(a, true) || it.title.contains(a, true) }
                        .take(6).shuffled()
                }.getOrDefault(emptyList())
            }
        }

        // Simili: radio dei preferiti (o dei più ascoltati se i preferiti sono pochi)
        val seeds = (fav.take(4) + top.take(3)).distinctBy { it.id }.take(5)
        val similar = seeds.map { seed ->
            async { runCatching { api.related(seed.id, music = true).take(8) }.getOrDefault(emptyList()) }
        }

        val artistLists = perArtist.awaitAll()
        val similarLists = similar.awaitAll()

        // Ordine di alternanza: preferito, artista, simile, più ascoltato, artista, simile…
        val sources = buildList {
            add(fav)
            artistLists.forEach { add(it) }
            similarLists.forEach { add(it) }
            add(top)
        }.filter { it.isNotEmpty() }

        val seenIds = HashSet<String>()
        val seenKeys = HashSet<String>()
        val out = mutableListOf<VideoItem>()
        var i = 0
        while (out.size < limit && sources.any { i < it.size }) {
            for (src in sources) {
                if (out.size >= limit) break
                val v = src.getOrNull(i) ?: continue
                if (v.kind != ItemKind.VIDEO) continue
                val k = MetaCleaner.key(v.title, v.author)
                if (v.id in seenIds || k in seenKeys) continue
                seenIds += v.id
                seenKeys += k
                out += v
            }
            i++
        }
        Suggestions(out, artists.ifEmpty { seeds.map { it.title } })
    }

    private suspend fun mix(
        seeds: List<Listen>,
        limit: Int,
        forceMusic: Boolean = false,
        fallback: suspend () -> List<VideoItem>,
    ): Suggestions = coroutineScope {
        if (seeds.isEmpty()) {
            Suggestions(fallback(), emptyList())
        } else {
            val lists = seeds.map { s ->
                async { runCatching { api.related(s.id, forceMusic || s.music) }.getOrDefault(emptyList()) }
            }.awaitAll()
            val heard = ListenHistory.all().filter { it.count >= 2 }.map { it.id }.toSet() + seeds.map { it.id }
            val items = interleave(lists, limit)
                .filter { it.kind == ItemKind.VIDEO && it.id !in heard && (!forceMusic || MusicFilter.isSong(it)) }
            Suggestions(items, seeds.map { it.title })
        }
    }

    private fun interleave(lists: List<List<VideoItem>>, limit: Int): List<VideoItem> {
        val out = LinkedHashMap<String, VideoItem>()
        var i = 0
        while (out.size < limit && lists.any { i < it.size }) {
            for (l in lists) l.getOrNull(i)?.let { out.putIfAbsent(it.id, it) }
            i++
        }
        return out.values.toList()
    }
}
