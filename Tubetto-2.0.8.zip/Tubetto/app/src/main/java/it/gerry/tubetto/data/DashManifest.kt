package it.gerry.tubetto.data

/**
 * Costruisce un manifest DASH (MPD) dai formati adattivi di /player.
 * Con più qualità disponibili ExoPlayer parte bassa per avviare subito
 * e poi sale da solo in base alla velocità della rete, senza bloccarsi.
 */
object DashManifest {

    data class Rep(
        val itag: Int,
        val url: String,
        val mime: String,      // es. video/mp4
        val codecs: String,    // es. avc1.4d401f
        val bitrate: Int,
        val width: Int,
        val height: Int,
        val fps: Int,
        val initRange: String, // "0-740"
        val indexRange: String,
        val audioSampleRate: Int,
    )

    fun build(videos: List<Rep>, audios: List<Rep>, durationMs: Long): String {
        val dur = "PT%.3fS".format(java.util.Locale.US, durationMs / 1000.0)
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8"?>""")
        sb.append("""<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" minBufferTime="PT1.5S" mediaPresentationDuration="$dur">""")
        sb.append("""<Period duration="$dur">""")
        var setId = 0
        for ((mime, reps) in videos.groupBy { it.mime }) {
            sb.append("""<AdaptationSet id="${setId++}" contentType="video" mimeType="$mime" subsegmentAlignment="true">""")
            reps.sortedBy { it.bitrate }.forEach { r ->
                sb.append("""<Representation id="${r.itag}" codecs="${r.codecs}" bandwidth="${r.bitrate}" width="${r.width}" height="${r.height}"""")
                if (r.fps > 0) sb.append(""" frameRate="${r.fps}"""")
                sb.append(">")
                segment(sb, r)
                sb.append("</Representation>")
            }
            sb.append("</AdaptationSet>")
        }
        for ((mime, reps) in audios.groupBy { it.mime }) {
            sb.append("""<AdaptationSet id="${setId++}" contentType="audio" mimeType="$mime" subsegmentAlignment="true">""")
            reps.sortedBy { it.bitrate }.forEach { r ->
                sb.append("""<Representation id="${r.itag}" codecs="${r.codecs}" bandwidth="${r.bitrate}"""")
                if (r.audioSampleRate > 0) sb.append(""" audioSamplingRate="${r.audioSampleRate}"""")
                sb.append(">")
                sb.append("""<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="2"/>""")
                segment(sb, r)
                sb.append("</Representation>")
            }
            sb.append("</AdaptationSet>")
        }
        sb.append("</Period></MPD>")
        return sb.toString()
    }

    private fun segment(sb: StringBuilder, r: Rep) {
        sb.append("<BaseURL>").append(xml(r.url)).append("</BaseURL>")
        sb.append("""<SegmentBase indexRange="${r.indexRange}"><Initialization range="${r.initRange}"/></SegmentBase>""")
    }

    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
}
