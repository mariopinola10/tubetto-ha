package it.gerry.tubetto.ui

import android.app.Activity
import android.app.SearchManager
import android.content.ComponentName
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.playback.PlaybackService

/**
 * Riceve dall'Assistente Google "riproduci <brano> su Tubetto"
 * (MEDIA_PLAY_FROM_SEARCH) e avvia la ricerca musicale nel player, senza mostrare nulla.
 */
class VoiceSearchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val query = intent.getStringExtra(SearchManager.QUERY).orEmpty().trim()
        val artist = intent.getStringExtra(MediaStore.EXTRA_MEDIA_ARTIST).orEmpty()
        val title = intent.getStringExtra(MediaStore.EXTRA_MEDIA_TITLE).orEmpty()
        val q = query.ifBlank { listOf(title, artist).filter { it.isNotBlank() }.joinToString(" ") }
        Diagnostics.log("Comando vocale dall'Assistente: \"$q\"")

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            runCatching {
                val c = future.get()
                c.setMediaItem(
                    MediaItem.Builder()
                        .setMediaId("")
                        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setSearchQuery(q).build())
                        .build()
                )
                c.prepare()
                c.play()
                Handler(Looper.getMainLooper()).postDelayed({ MediaController.releaseFuture(future) }, 5000)
            }.onFailure { Diagnostics.log("Comando vocale fallito: ${it.message}") }
            finish()
        }, ContextCompat.getMainExecutor(this))
    }
}
