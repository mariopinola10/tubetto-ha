package it.gerry.tubetto.data

import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import kotlin.math.abs

/**
 * Importa playlist, album e brani di Spotify cercandoli su YouTube Music.
 * Nessuna chiave: legge la pagina pubblica "embed" di Spotify (funziona con playlist e album pubblici;
 * Spotify ne mostra al massimo circa 100 brani).
 */
object SpotifyImport {

    data class Track(val title: String, val artist: String, val durationMs: Long)
    data class Source(val kind: String, val name: String, val tracks: List<Track>)
    data class Result(val name: String, val found: List<VideoItem>, val missing: List<Track>)

    private val LINK = Regex("""(?:open\.spotify\.com/(?:intl-[a-z]{2}/)?(?:embed/)?|spotify:)(playlist|album|track)[/:]([A-Za-z0-9]{10,})""")

    /** Riconosce un link Spotify in un testo (anche condiviso dall'app Spotify con altro testo intorno). */
    fun findLink(text: String?): Pair<String, String>? {
        val m = LINK.find(text ?: return null) ?: return null
        return m.groupValues[1] to m.groupValues[2]
    }

    /** Scarica l'elenco dei brani dalla pagina pubblica di Spotify. */
    suspend fun fetch(kind: String, id: String): Source = withContext(Dispatchers.IO) {
        val html = Http.client.newCall(
            Request.Builder()
                .url("https://open.spotify.com/embed/$kind/$id")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")
                .header("Accept-Language", "it-IT,it;q=0.9,en;q=0.8")
                .build()
        ).execute().use { r ->
            if (r.code == 404) throw IOException("Playlist non trovata o privata (rendila pubblica in Spotify)")
            if (!r.isSuccessful) throw IOException("Spotify ha risposto HTTP ${r.code}")
            r.body!!.string()
        }
        val json = Regex("""<script id="__NEXT_DATA__"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)
            ?: throw IOException("Spotify ha cambiato la pagina: dati non trovati")
        val root = JSONObject(json)
        val entity = findEntity(root) ?: throw IOException("Nessun brano trovato nella pagina Spotify")
        val name = entity.optString("name").ifBlank { entity.optString("title") }.ifBlank { "Spotify" }
        val list = entity.optJSONArray("trackList")
        val tracks = if (list != null) {
            (0 until list.length()).mapNotNull { i -> trackOf(list.optJSONObject(i)) }
        } else {
            listOfNotNull(trackOf(entity))
        }
        if (tracks.isEmpty()) throw IOException("La playlist è vuota o non è pubblica")
        Source(kind, name, tracks)
    }

    /** Cerca nel JSON l'oggetto con la lista dei brani (o il brano singolo). */
    private fun findEntity(node: Any?): JSONObject? {
        when (node) {
            is JSONObject -> {
                if (node.has("trackList")) return node
                node.optJSONObject("entity")?.let { e ->
                    if (e.has("trackList") || e.has("artists") || e.has("subtitle")) return e
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = findEntity(node.opt(keys.next()))
                    if (found != null) return found
                }
            }
            is JSONArray -> for (i in 0 until node.length()) {
                val found = findEntity(node.opt(i))
                if (found != null) return found
            }
        }
        return null
    }

    private fun trackOf(o: JSONObject?): Track? {
        o ?: return null
        val title = o.optString("title").ifBlank { o.optString("name") }
        if (title.isBlank()) return null
        val artist = o.optString("subtitle").ifBlank {
            val arr = o.optJSONArray("artists")
            if (arr == null) "" else (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("name") }.joinToString(", ")
        }.replace(' ', ' ')
        val dur = o.optLong("duration", 0L).let { if (it in 1L..10_000L) it * 1000 else it }
        return Track(title, artist, dur)
    }

    private fun parseDuration(s: String): Long? {
        val parts = s.trim().split(":").mapNotNull { it.toIntOrNull() }
        if (parts.isEmpty() || parts.size > 3) return null
        return parts.fold(0L) { acc, p -> acc * 60 + p } * 1000
    }

    /** Trova il brano su YouTube Music: titolo + primo artista, scegliendo la durata più vicina. */
    suspend fun match(api: YouTubeApiHelper, t: Track): VideoItem? {
        val firstArtist = t.artist.split(",").firstOrNull()?.trim().orEmpty()
        val results = runCatching { api.searchMusic("${t.title} $firstArtist".trim()) }.getOrDefault(emptyList())
            .filter { it.kind == ItemKind.VIDEO }
            .take(6)
        if (results.isEmpty()) return null
        if (t.durationMs <= 0) return results.first()
        val close = results.firstOrNull { r -> parseDuration(r.duration)?.let { abs(it - t.durationMs) <= 15_000 } == true }
        return close ?: results.firstOrNull { r -> parseDuration(r.duration)?.let { abs(it - t.durationMs) <= 45_000 } == true }
            ?: results.first()
    }

    /** Cerca tutti i brani (4 alla volta), mantenendo l'ordine. */
    suspend fun matchAll(api: YouTubeApiHelper, tracks: List<Track>, progress: (done: Int, total: Int) -> Unit): Pair<List<VideoItem>, List<Track>> =
        coroutineScope {
            val sem = Semaphore(4)
            var done = 0
            val found = tracks.map { t ->
                async {
                    sem.withPermit {
                        val v = match(api, t)
                        withContext(Dispatchers.Main) { progress(++done, tracks.size) }
                        t to v
                    }
                }
            }.awaitAll()
            found.mapNotNull { it.second }.distinctBy { it.id } to found.filter { it.second == null }.map { it.first }
        }
}
