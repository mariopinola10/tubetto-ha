package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Quando hai usato per l'ultima volta playlist, artisti e canali: le liste li mostrano
 * dal più recente, così in cima ci sono sempre le ultime cose ascoltate.
 * I brani usano la cronologia d'ascolto.
 */
object Recents {

    private var sp: SharedPreferences? = null
    private val map = HashMap<String, Long>()

    fun init(context: Context) {
        sp = context.getSharedPreferences("recents", Context.MODE_PRIVATE)
        runCatching {
            val o = JSONObject(sp?.getString("map", "{}") ?: "{}")
            o.keys().forEach { k -> map[k] = o.optLong(k) }
        }
    }

    fun keyOf(v: VideoItem): String = when (v.kind) {
        ItemKind.PLAYLIST -> "pl:" + v.id
        ItemKind.ARTIST -> "ar:" + v.title.lowercase()
        ItemKind.CHANNEL -> "ch:" + v.id
        else -> "v:" + v.id
    }

    fun artistKey(name: String) = "ar:" + name.lowercase()
    fun playlistKey(id: String) = "pl:$id"

    @Synchronized
    fun touch(key: String) {
        map[key] = System.currentTimeMillis()
        if (map.size > 600) map.entries.sortedBy { it.value }.take(map.size - 500).forEach { map.remove(it.key) }
        sp?.edit()?.putString("map", JSONObject(map as Map<*, *>).toString())?.apply()
    }

    fun touch(v: VideoItem) = touch(keyOf(v))

    @Synchronized
    fun at(key: String): Long {
        val own = map[key] ?: 0L
        val fromHistory = when {
            key.startsWith("v:") -> ListenHistory.lastAt(key.removePrefix("v:"))
            key.startsWith("ar:") -> ListenHistory.lastByAuthor(key.removePrefix("ar:"))
            else -> 0L
        }
        return maxOf(own, fromHistory)
    }

    /** Ordina dal più recente; ciò che non è mai stato usato resta nell'ordine originale, in fondo. */
    fun sort(list: List<VideoItem>): List<VideoItem> =
        list.withIndex()
            .sortedWith(compareByDescending<IndexedValue<VideoItem>> { at(keyOf(it.value)) }.thenBy { it.index })
            .map { it.value }
}
