package it.gerry.tubetto.net

import it.gerry.tubetto.data.Clients
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object Http {
    const val WEB_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

    /** Client per le API InnerTube, NewPipe e GitHub. */
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Client per googlevideo.com: lo User-Agent deve corrispondere al client che ha
     * generato l'URL (parametro c=ANDROID / IOS / ANDROID_VR / WEB...), altrimenti 403.
     */
    val streamClient: OkHttpClient by lazy {
        client.newBuilder()
            .addInterceptor(Interceptor { chain ->
                val req = chain.request()
                if (!req.url.host.endsWith("googlevideo.com")) return@Interceptor chain.proceed(req)
                val c = req.url.queryParameter("c")
                val b = req.newBuilder().header("User-Agent", Clients.userAgentFor(c))
                if (c != null && c.startsWith("WEB")) {
                    b.header("Origin", "https://www.youtube.com").header("Referer", "https://www.youtube.com/")
                }
                chain.proceed(b.build())
            })
            .build()
    }
}
