package it.gerry.tubetto.cast

import android.content.Context
import android.net.wifi.WifiManager
import it.gerry.tubetto.BuildConfig
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class RendererState(
    val transport: String,
    val uri: String,
    val metadata: String,
    val positionMs: Long,
    val durationMs: Long,
    val volume: Int,
    val mute: Boolean,
)

/** Azioni eseguite dal player che riceve. */
interface RendererBackend {
    fun setUri(uri: String, title: String, metadata: String)
    fun play()
    fun pause()
    fun stop()
    fun seek(ms: Long)
    fun setVolume(v: Int)
    fun setMute(m: Boolean)
    fun snapshot(): RendererState
}

/**
 * DLNA MediaRenderer (UPnP AV) minimale: SSDP, descrizione, SCPD, SOAP ed eventi GENA.
 * Viene trovato da Tubetto sul telefono, da altre app DLNA e dall'integrazione
 * "DLNA Digital Media Renderer" di Home Assistant.
 */
class TubettoRenderer(
    context: Context,
    private val backend: RendererBackend,
    private val friendlyName: String,
) {
    private val appContext = context.applicationContext
    private val uuid: String = context.getSharedPreferences("renderer", Context.MODE_PRIVATE).let { sp ->
        sp.getString("uuid", null) ?: UUID.randomUUID().toString().also { sp.edit().putString("uuid", it).apply() }
    }

    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var ssdp: MulticastSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val pool = Executors.newCachedThreadPool()
    private val events = Executors.newSingleThreadExecutor()

    private data class Sub(val sid: String, val service: String, val callback: String, var seq: Long, var expires: Long)
    private val subs = ConcurrentHashMap<String, Sub>()

    val port: Int get() = server?.localPort ?: 0
    val ip: String get() = StreamProxy.localIp()
    private val location get() = "http://$ip:$port/desc.xml"

    fun start() {
        if (running) return
        running = true
        multicastLock = appContext.getSystemService(WifiManager::class.java)
            ?.createMulticastLock("tubetto-renderer")?.apply { setReferenceCounted(false); acquire() }

        val s = runCatching { ServerSocket(PORT) }.getOrElse { ServerSocket(0) }
        server = s
        thread(isDaemon = true, name = "renderer-http") {
            while (running) {
                val c = runCatching { s.accept() }.getOrNull() ?: break
                pool.execute { runCatching { handle(c) }.onFailure { Diagnostics.log("Renderer HTTP: ${it.message}") } }
            }
        }
        thread(isDaemon = true, name = "renderer-ssdp") { ssdpLoop() }
        thread(isDaemon = true, name = "renderer-notify") {
            while (running) {
                runCatching { ssdpNotify("ssdp:alive") }
                Thread.sleep(30_000)
            }
        }
        Diagnostics.log("Ricevitore attivo su $location")
    }

    fun stop() {
        if (!running) return
        runCatching { ssdpNotify("ssdp:byebye") }
        running = false
        runCatching { server?.close() }
        runCatching { ssdp?.close() }
        multicastLock?.release()
    }

    /** Da chiamare quando cambia lo stato del player: invia gli eventi ai sottoscrittori (es. Home Assistant). */
    fun stateChanged() {
        if (subs.isEmpty()) return
        events.execute { subs.values.toList().forEach { sendEvent(it) } }
    }

    // ---------------------------------------------------------------- SSDP

    private val types get() = listOf(
        "upnp:rootdevice",
        "uuid:$uuid",
        DEVICE_TYPE,
        SERVICE_AVT,
        SERVICE_RCS,
        SERVICE_CMS,
    )

    private fun usn(st: String) = if (st == "uuid:$uuid") st else "uuid:$uuid::$st"

    private fun ssdpLoop() {
        val group = InetAddress.getByName("239.255.255.250")
        val sock = MulticastSocket(null).apply {
            reuseAddress = true
            bind(InetSocketAddress(1900))
            @Suppress("DEPRECATION")
            joinGroup(group)
        }
        ssdp = sock
        val buf = ByteArray(4096)
        while (running) {
            val p = DatagramPacket(buf, buf.size)
            try {
                sock.receive(p)
            } catch (e: Exception) {
                break
            }
            val text = String(p.data, 0, p.length)
            if (!text.startsWith("M-SEARCH")) continue
            val st = Regex("(?im)^st:\\s*(.+)$").find(text)?.groupValues?.get(1)?.trim() ?: continue
            val answers = when (st) {
                "ssdp:all" -> types
                in types -> listOf(st)
                else -> emptyList<String>()
            }
            for (a in answers) {
                val msg = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\nLOCATION: $location\r\n" +
                    "SERVER: Android/1 UPnP/1.0 Tubetto/${BuildConfig.VERSION_NAME}\r\nST: $a\r\nUSN: ${usn(a)}\r\n\r\n"
                val bytes = msg.toByteArray()
                runCatching { sock.send(DatagramPacket(bytes, bytes.size, p.address, p.port)) }
            }
        }
    }

    private fun ssdpNotify(nts: String) {
        val group = InetAddress.getByName("239.255.255.250")
        java.net.DatagramSocket().use { s ->
            for (t in types) {
                val msg = "NOTIFY * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nCACHE-CONTROL: max-age=1800\r\n" +
                    "LOCATION: $location\r\nNT: $t\r\nNTS: $nts\r\n" +
                    "SERVER: Android/1 UPnP/1.0 Tubetto/${BuildConfig.VERSION_NAME}\r\nUSN: ${usn(t)}\r\n\r\n"
                val b = msg.toByteArray()
                s.send(DatagramPacket(b, b.size, group, 1900))
            }
        }
    }

    // ---------------------------------------------------------------- HTTP

    private class Resp(val code: Int, val type: String = "text/xml; charset=\"utf-8\"", val body: ByteArray = ByteArray(0), val headers: Map<String, String> = emptyMap())

    private fun handle(sock: Socket) {
        sock.use { s -> serve(s) }
    }

    private fun serve(s: Socket) {
        s.soTimeout = 15_000
        val input = BufferedInputStream(s.getInputStream())
        val requestLine = readLine(input) ?: return
        val (method, rawPath) = requestLine.split(" ").let { it.getOrElse(0) { "" } to it.getOrElse(1) { "/" } }
        val path = rawPath.substringBefore('?')
        val headers = HashMap<String, String>()
        while (true) {
            val line = readLine(input) ?: break
            if (line.isEmpty()) break
            val i = line.indexOf(':')
            if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        val len = headers["content-length"]?.toIntOrNull() ?: 0
        val body = if (len > 0) String(readN(input, len), Charsets.UTF_8) else ""

        val resp = when {
            method == "GET" && path == "/desc.xml" -> Resp(200, body = descriptionXml().toByteArray())
            method == "GET" && path == "/scpd/avt.xml" -> Resp(200, body = Scpd.AVT.toByteArray())
            method == "GET" && path == "/scpd/rcs.xml" -> Resp(200, body = Scpd.RCS.toByteArray())
            method == "GET" && path == "/scpd/cms.xml" -> Resp(200, body = Scpd.CMS.toByteArray())
            method == "POST" && path.startsWith("/ctl/") -> soap(path.removePrefix("/ctl/"), headers, body)
            method == "SUBSCRIBE" && path.startsWith("/evt/") -> subscribe(path.removePrefix("/evt/"), headers)
            method == "UNSUBSCRIBE" -> { headers["sid"]?.let { subs.remove(it) }; Resp(200) }
            else -> Resp(404)
        }

        val sb = StringBuilder("HTTP/1.1 ${resp.code} ${if (resp.code == 200) "OK" else "Error"}\r\n")
        sb.append("Content-Type: ${resp.type}\r\nContent-Length: ${resp.body.size}\r\n")
        sb.append("Server: Android/1 UPnP/1.0 Tubetto/${BuildConfig.VERSION_NAME}\r\n")
        resp.headers.forEach { (k, v) -> sb.append("$k: $v\r\n") }
        sb.append("Connection: close\r\n\r\n")
        val out = s.getOutputStream()
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        out.write(resp.body)
        out.flush()

        // Evento iniziale dopo una nuova sottoscrizione
        if (resp.code == 200 && method == "SUBSCRIBE") {
            val sid = resp.headers["SID"]
            val sub = if (sid != null) subs[sid] else null
            if (sub != null) events.execute { sendEvent(sub) }
        }
    }

    private fun readLine(input: InputStream): String? {
        val b = ByteArrayOutputStream()
        while (true) {
            val c = input.read()
            if (c == -1) return if (b.size() == 0) null else b.toString("ISO-8859-1")
            if (c == '\n'.code) return b.toString("ISO-8859-1").trimEnd('\r')
            b.write(c)
        }
    }

    private fun readN(input: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) break
            off += r
        }
        return buf
    }

    private fun descriptionXml(): String = """<?xml version="1.0" encoding="utf-8"?>
<root xmlns="urn:schemas-upnp-org:device-1-0" xmlns:dlna="urn:schemas-dlna-org:device-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <device>
    <deviceType>$DEVICE_TYPE</deviceType>
    <friendlyName>${Dlna.esc(friendlyName)}</friendlyName>
    <manufacturer>Tubetto</manufacturer>
    <modelName>Tubetto Receiver</modelName>
    <modelNumber>${BuildConfig.VERSION_NAME}</modelNumber>
    <modelDescription>Ricevitore YouTube DLNA</modelDescription>
    <UDN>uuid:$uuid</UDN>
    <dlna:X_DLNADOC>DMR-1.50</dlna:X_DLNADOC>
    <serviceList>
      <service>
        <serviceType>$SERVICE_AVT</serviceType>
        <serviceId>urn:upnp-org:serviceId:AVTransport</serviceId>
        <SCPDURL>/scpd/avt.xml</SCPDURL>
        <controlURL>/ctl/avt</controlURL>
        <eventSubURL>/evt/avt</eventSubURL>
      </service>
      <service>
        <serviceType>$SERVICE_RCS</serviceType>
        <serviceId>urn:upnp-org:serviceId:RenderingControl</serviceId>
        <SCPDURL>/scpd/rcs.xml</SCPDURL>
        <controlURL>/ctl/rcs</controlURL>
        <eventSubURL>/evt/rcs</eventSubURL>
      </service>
      <service>
        <serviceType>$SERVICE_CMS</serviceType>
        <serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId>
        <SCPDURL>/scpd/cms.xml</SCPDURL>
        <controlURL>/ctl/cms</controlURL>
        <eventSubURL>/evt/cms</eventSubURL>
      </service>
    </serviceList>
  </device>
</root>"""

    // ---------------------------------------------------------------- SOAP

    private fun soap(service: String, headers: Map<String, String>, body: String): Resp {
        val action = headers["soapaction"].orEmpty().trim('"').substringAfter('#')
        fun arg(n: String): String =
            Regex("<(?:\\w+:)?$n(?:\\s[^>]*)?>(.*?)</(?:\\w+:)?$n>", RegexOption.DOT_MATCHES_ALL)
                .find(body)?.groupValues?.get(1)?.let(::unesc).orEmpty()
        val serviceType = when (service) { "avt" -> SERVICE_AVT; "rcs" -> SERVICE_RCS; else -> SERVICE_CMS }

        val none = emptyList<Pair<String, String>>()
        val out: List<Pair<String, String>> = try {
            when ("$service/$action") {
                "avt/SetAVTransportURI" -> {
                    val meta = arg("CurrentURIMetaData")
                    val title = Regex("<dc:title>(.*?)</dc:title>", RegexOption.DOT_MATCHES_ALL)
                        .find(meta)?.groupValues?.get(1)?.let(::unesc).orEmpty()
                    backend.setUri(arg("CurrentURI"), title, meta); none
                }
                "avt/Play" -> { backend.play(); none }
                "avt/Pause" -> { backend.pause(); none }
                "avt/Stop" -> { backend.stop(); none }
                "avt/Seek" -> { parseTime(arg("Target"))?.let { backend.seek(it) }; none }
                "avt/GetTransportInfo" -> {
                    val st = backend.snapshot()
                    listOf("CurrentTransportState" to st.transport, "CurrentTransportStatus" to "OK", "CurrentSpeed" to "1")
                }
                "avt/GetPositionInfo" -> {
                    val st = backend.snapshot()
                    listOf(
                        "Track" to if (st.uri.isEmpty()) "0" else "1",
                        "TrackDuration" to fmt(st.durationMs),
                        "TrackMetaData" to st.metadata,
                        "TrackURI" to st.uri,
                        "RelTime" to fmt(st.positionMs),
                        "AbsTime" to fmt(st.positionMs),
                        "RelCount" to "2147483647",
                        "AbsCount" to "2147483647",
                    )
                }
                "avt/GetMediaInfo" -> {
                    val st = backend.snapshot()
                    listOf(
                        "NrTracks" to if (st.uri.isEmpty()) "0" else "1",
                        "MediaDuration" to fmt(st.durationMs),
                        "CurrentURI" to st.uri,
                        "CurrentURIMetaData" to st.metadata,
                        "NextURI" to "", "NextURIMetaData" to "",
                        "PlayMedium" to "NETWORK", "RecordMedium" to "NOT_IMPLEMENTED",
                        "WriteStatus" to "NOT_IMPLEMENTED",
                    )
                }
                "avt/GetTransportSettings" -> listOf("PlayMode" to "NORMAL", "RecQualityMode" to "NOT_IMPLEMENTED")
                "avt/GetCurrentTransportActions" -> listOf("Actions" to "Play,Pause,Stop,Seek")
                "avt/GetDeviceCapabilities" -> listOf(
                    "PlayMedia" to "NETWORK", "RecMedia" to "NOT_IMPLEMENTED", "RecQualityModes" to "NOT_IMPLEMENTED",
                )
                "rcs/GetVolume" -> listOf("CurrentVolume" to backend.snapshot().volume.toString())
                "rcs/SetVolume" -> { backend.setVolume(arg("DesiredVolume").toIntOrNull() ?: 50); none }
                "rcs/GetMute" -> listOf("CurrentMute" to if (backend.snapshot().mute) "1" else "0")
                "rcs/SetMute" -> { backend.setMute(arg("DesiredMute") in setOf("1", "true")); none }
                "cms/GetProtocolInfo" -> listOf("Source" to "", "Sink" to SINK_PROTOCOLS)
                "cms/GetCurrentConnectionIDs" -> listOf("ConnectionIDs" to "0")
                "cms/GetCurrentConnectionInfo" -> listOf(
                    "RcsID" to "0", "AVTransportID" to "0", "ProtocolInfo" to "",
                    "PeerConnectionManager" to "", "PeerConnectionID" to "-1",
                    "Direction" to "Input", "Status" to "OK",
                )
                else -> return fault(401, "Invalid Action")
            }
        } catch (e: Exception) {
            Diagnostics.log("Renderer $action: ${e.message}")
            return fault(501, "Action Failed")
        }
        if (service != "cms" && action.startsWith("Set") || action in setOf("Play", "Pause", "Stop", "Seek")) stateChanged()

        val args = out.joinToString("") { (k, v) -> "<$k>${Dlna.esc(v)}</$k>" }
        val xml = """<?xml version="1.0" encoding="utf-8"?>""" +
            """<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">""" +
            """<s:Body><u:${action}Response xmlns:u="$serviceType">$args</u:${action}Response></s:Body></s:Envelope>"""
        return Resp(200, body = xml.toByteArray())
    }

    private fun fault(code: Int, desc: String): Resp {
        val xml = """<?xml version="1.0" encoding="utf-8"?>""" +
            """<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">""" +
            """<s:Body><s:Fault><faultcode>s:Client</faultcode><faultstring>UPnPError</faultstring><detail>""" +
            """<UPnPError xmlns="urn:schemas-upnp-org:control-1-0"><errorCode>$code</errorCode>""" +
            """<errorDescription>$desc</errorDescription></UPnPError></detail></s:Fault></s:Body></s:Envelope>"""
        return Resp(500, body = xml.toByteArray())
    }

    // ---------------------------------------------------------------- GENA (eventi)

    private fun subscribe(service: String, headers: Map<String, String>): Resp {
        val existing = headers["sid"]
        val expires = System.currentTimeMillis() + 1_800_000
        if (existing != null) {
            val sub = subs[existing] ?: return Resp(412)
            sub.expires = expires
            return Resp(200, headers = mapOf("SID" to existing, "TIMEOUT" to "Second-1800"))
        }
        val cb = Regex("<([^>]+)>").find(headers["callback"].orEmpty())?.groupValues?.get(1) ?: return Resp(412)
        val sid = "uuid:${UUID.randomUUID()}"
        subs[sid] = Sub(sid, service, cb, 0, expires)
        return Resp(200, headers = mapOf("SID" to sid, "TIMEOUT" to "Second-1800"))
    }

    private fun sendEvent(sub: Sub) {
        if (System.currentTimeMillis() > sub.expires) { subs.remove(sub.sid); return }
        val st = runCatching { backend.snapshot() }.getOrNull() ?: return
        val lastChange = when (sub.service) {
            "avt" -> """<Event xmlns="urn:schemas-upnp-org:metadata-1-0/AVT/"><InstanceID val="0">""" +
                """<TransportState val="${st.transport}"/><TransportStatus val="OK"/>""" +
                """<CurrentTransportActions val="Play,Pause,Stop,Seek"/>""" +
                """<AVTransportURI val="${Dlna.esc(st.uri)}"/><CurrentTrackURI val="${Dlna.esc(st.uri)}"/>""" +
                """<CurrentTrackMetaData val="${Dlna.esc(st.metadata)}"/>""" +
                """<CurrentTrackDuration val="${fmt(st.durationMs)}"/><CurrentMediaDuration val="${fmt(st.durationMs)}"/>""" +
                """<NumberOfTracks val="${if (st.uri.isEmpty()) 0 else 1}"/><CurrentTrack val="${if (st.uri.isEmpty()) 0 else 1}"/>""" +
                """</InstanceID></Event>"""
            "rcs" -> """<Event xmlns="urn:schemas-upnp-org:metadata-1-0/RCS/"><InstanceID val="0">""" +
                """<Volume channel="Master" val="${st.volume}"/><Mute channel="Master" val="${if (st.mute) 1 else 0}"/>""" +
                """</InstanceID></Event>"""
            else -> null
        }
        val props = if (lastChange != null) "<e:property><LastChange>${Dlna.esc(lastChange)}</LastChange></e:property>"
        else "<e:property><SinkProtocolInfo>${Dlna.esc(SINK_PROTOCOLS)}</SinkProtocolInfo></e:property>" +
            "<e:property><SourceProtocolInfo></SourceProtocolInfo></e:property>" +
            "<e:property><CurrentConnectionIDs>0</CurrentConnectionIDs></e:property>"
        val body = """<?xml version="1.0" encoding="utf-8"?><e:propertyset xmlns:e="urn:schemas-upnp-org:event-1-0">$props</e:propertyset>"""
        val req = Request.Builder()
            .url(sub.callback)
            .method("NOTIFY", body.toRequestBody("text/xml; charset=\"utf-8\"".toMediaType()))
            .header("NT", "upnp:event")
            .header("NTS", "upnp:propchange")
            .header("SID", sub.sid)
            .header("SEQ", (sub.seq++).toString())
            .build()
        runCatching { Http.client.newCall(req).execute().close() }
            .onFailure { Diagnostics.log("Evento a ${sub.callback} fallito: ${it.message}") }
    }

    // ---------------------------------------------------------------- utilità

    private fun unesc(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&amp;", "&")

    private fun fmt(ms: Long): String {
        val t = (ms.coerceAtLeast(0)) / 1000
        return "%d:%02d:%02d".format(t / 3600, (t % 3600) / 60, t % 60)
    }

    private fun parseTime(s: String): Long? {
        val p = s.trim().split(":")
        if (p.size != 3) return null
        val sec = p[2].toDoubleOrNull() ?: return null
        return ((p[0].toLongOrNull() ?: 0L) * 3600L + (p[1].toLongOrNull() ?: 0L) * 60L) * 1000L + (sec * 1000).toLong()
    }

    companion object {
        private const val PORT = 49494
        const val DEVICE_TYPE = "urn:schemas-upnp-org:device:MediaRenderer:1"
        const val SERVICE_AVT = "urn:schemas-upnp-org:service:AVTransport:1"
        const val SERVICE_RCS = "urn:schemas-upnp-org:service:RenderingControl:1"
        const val SERVICE_CMS = "urn:schemas-upnp-org:service:ConnectionManager:1"
        val SINK_PROTOCOLS = listOf(
            "http-get:*:video/mp4:*", "http-get:*:video/webm:*", "http-get:*:video/x-matroska:*",
            "http-get:*:application/vnd.apple.mpegurl:*", "http-get:*:application/x-mpegURL:*",
            "http-get:*:audio/mp4:*", "http-get:*:audio/mpeg:*", "http-get:*:audio/webm:*",
            "http-get:*:audio/aac:*", "http-get:*:audio/flac:*", "http-get:*:audio/ogg:*",
            "http-get:*:audio/x-wav:*", "http-get:*:video/*:*", "http-get:*:audio/*:*",
        ).joinToString(",")
    }
}
