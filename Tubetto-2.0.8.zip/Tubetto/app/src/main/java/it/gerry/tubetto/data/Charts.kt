package it.gerry.tubetto.data

import java.util.Calendar

/**
 * Classifiche ed eventi musicali. Ogni voce è una ricerca di playlist aggiornata:
 * toccandola si vedono le playlist più recenti per quella classifica/evento.
 */
object Charts {

    const val PREFIX = "q:"
    const val YTM_HITS = "ytm:charts"
    const val YTM_NEW = "ytm:new"

    fun items(): List<VideoItem> {
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) // 0 = gennaio
        val sanremo = if (month >= Calendar.FEBRUARY) year else year - 1
        val eurovision = if (month >= Calendar.MAY) year else year - 1
        val summer = if (month >= Calendar.JUNE) year else year - 1

        val ytm = listOf(
            VideoItem(id = YTM_HITS, title = "🔥 Hit del momento in Italia", author = "YouTube Music • classifica",
                duration = "", thumbnailUrl = "", kind = ItemKind.PLAYLIST),
            VideoItem(id = YTM_NEW, title = "🆕 Nuove uscite", author = "YouTube Music • singoli e album appena usciti",
                duration = "", thumbnailUrl = "", kind = ItemKind.PLAYLIST),
        )
        return ytm + listOf(
            Triple("Top 50 Italia", "Classifica", "top 50 italia"),
            Triple("Classifica FIMI singoli", "Classifica", "classifica fimi singoli"),
            Triple("Nuove uscite Italia", "Novità", "nuove uscite italia $year"),
            Triple("Nuove uscite internazionali", "Novità", "new music friday $year"),
            Triple("Sanremo $sanremo", "Evento", "sanremo $sanremo canzoni in gara"),
            Triple("Eurovision $eurovision", "Evento", "eurovision $eurovision all songs"),
            Triple("Top 50 Europa", "Classifica", "top 50 europe"),
            Triple("Top 50 Mondo", "Classifica", "top 50 global"),
            Triple("Tormentoni estate $summer", "Evento", "tormentoni estate $summer"),
            Triple("Rap italiano più ascoltato", "Classifica", "top rap italiano $year"),
            Triple("Radio hit Italia", "Classifica", "hit radio italia $year"),
        ).map { (title, tag, query) ->
            VideoItem(
                id = PREFIX + query,
                title = title,
                author = tag,
                duration = "",
                thumbnailUrl = "",
                kind = ItemKind.PLAYLIST,
            )
        }
    }
}
