package it.gerry.tubetto.playback

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Player
import it.gerry.tubetto.Diagnostics

/**
 * Gestione dell'audio focus su misura:
 * - notifiche, messaggi vocali brevi, navigatore → la musica continua (al massimo abbassata);
 * - telefonate (normali o VoIP, anche mentre squillano) → pausa, e ripresa a fine chiamata;
 * - un'altra app musicale prende il controllo in modo permanente → pausa.
 */
class FocusManager(context: Context, private val player: Player) {

    private val am = context.getSystemService(AudioManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var hasFocus = false
    private var pausedByCall = false

    private val listener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                player.volume = 1f
                if (pausedByCall && !inCall()) resumeAfterCall()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player.volume = 0.35f
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                // Spesso lo stato "in chiamata" arriva un attimo dopo: ricontrolliamo
                checkCall()
                main.postDelayed({ checkCall() }, 700)
                main.postDelayed({ checkCall() }, 2000)
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                hasFocus = false
                if (inCall()) pauseForCall() else {
                    Diagnostics.log("Focus perso: un'altra app riproduce, pausa")
                    player.pause()
                }
            }
        }
    }

    private val request: AudioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        .setWillPauseWhenDucked(false)
        .setOnAudioFocusChangeListener(listener, main)
        .build()

    private val modeListener: Any? = if (Build.VERSION.SDK_INT >= 31) {
        AudioManager.OnModeChangedListener { mode ->
            if (isCallMode(mode)) pauseForCall()
            else if (pausedByCall) main.postDelayed({ if (!inCall()) resumeAfterCall() }, 1500)
        }
    } else null

    init {
        if (Build.VERSION.SDK_INT >= 31) {
            am.addOnModeChangedListener(context.mainExecutor, modeListener as AudioManager.OnModeChangedListener)
        }
        player.addListener(object : Player.Listener {
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (playWhenReady) requestFocus()
            }
        })
    }

    fun requestFocus() {
        if (hasFocus) return
        hasFocus = am.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    fun release() {
        am.abandonAudioFocusRequest(request)
        if (Build.VERSION.SDK_INT >= 31) {
            am.removeOnModeChangedListener(modeListener as AudioManager.OnModeChangedListener)
        }
        hasFocus = false
    }

    private fun checkCall() {
        if (inCall()) pauseForCall()
    }

    private fun pauseForCall() {
        if (player.playWhenReady) {
            Diagnostics.log("Telefonata: pausa")
            pausedByCall = true
            player.pause()
        }
    }

    private fun resumeAfterCall() {
        Diagnostics.log("Fine telefonata: riprendo")
        pausedByCall = false
        hasFocus = false
        requestFocus()
        player.play()
    }

    private fun inCall(): Boolean = isCallMode(am.mode)

    private fun isCallMode(mode: Int) =
        mode == AudioManager.MODE_RINGTONE || mode == AudioManager.MODE_IN_CALL ||
            mode == AudioManager.MODE_IN_COMMUNICATION || mode == AudioManager.MODE_CALL_SCREENING
}
