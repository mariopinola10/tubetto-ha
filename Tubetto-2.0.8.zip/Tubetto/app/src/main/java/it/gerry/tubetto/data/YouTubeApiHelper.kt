package it.gerry.tubetto.data

import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.TimeZone

/**
 * Client minimale per le API interne (InnerTube) di YouTube e YouTube Music.
 * Gli endpoint /youtubei/v1/ sono POST con body JSON.
 */
class YouTubeApiHelper(
    private val http: OkHttpClient = Http.client,
    private val hl: String = "it",
    private val gl: String = "IT",
) {

    /** Genera dinamicamente l'INNERTUBE_CONTEXT per il client indicato. */
    fun buildContext(client: ClientProfile): JSONObject {
        val c = JSONObject()
            .put("clientName", client.clientName)
            .put("clientVersion", client.version)
            .put("hl", hl)
            .put("gl", gl)
            .put("utcOffsetMinutes", TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60_000)
        client.context.forEach { (k, v) -> c.put(k, v) }

        return JSONObject()
            .put("client", c)
            .put("user", JSONObject().put("lockedSafetyMode", false))
            .put("request", JSONObject().put("useSsl", true))
    }

    private suspend fun post(
        endpoint: String,
        client: ClientProfile,
        payload: JSONObject,
        origin: String = YT,
        headers: Map<String, String> = emptyMap(),
    ): JSONObject = withContext(Dispatchers.IO) {
        payload.put("context", buildContext(client))
        val builder = Request.Builder()
            .url("$origin/youtubei/v1/$endpoint?prettyPrint=false")
            .post(payload.toString().toRequestBody(JSON))
            .header("User-Agent", client.userAgent)
            .header("X-YouTube-Client-Name", client.nameId.toString())
            .header("X-YouTube-Client-Version", client.version)
            .header("Origin", origin)
            .header("Referer", "$origin/")
        headers.forEach { (k, v) -> builder.header(k, v) }
        val req = builder.build()

        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("InnerTube /$endpoint (${client.key}) HTTP ${r.code}")
            JSONObject(body)
        }
    }

    /** Video. */
    suspend fun search(query: String): List<VideoItem> =
        StreamParser.parseVideoItems(
            post("search", Clients.WEB, JSONObject().put("query", query).put("params", FILTER_VIDEOS))
        )

    /** Brani da YouTube Music; se fallisce ripiega sulla ricerca video. */
    suspend fun searchMusic(query: String): List<VideoItem> = MusicFilter.clean(searchMusicRaw(query), query)

    private suspend fun searchMusicRaw(query: String): List<VideoItem> = try {
        StreamParser.parseMusic(
            post(
                "search", Clients.WEB_REMIX,
                JSONObject().put("query", query).put("params", FILTER_SONGS),
                origin = YT_MUSIC,
            )
        ).ifEmpty { search(query) }
    } catch (e: Exception) {
        Diagnostics.log("Ricerca YouTube Music fallita (${e.message}), uso la ricerca video")
        search(query)
    }

    /**
     * Correlati di un brano/video: radio di YouTube Music per la musica,
     * "video successivi" di YouTube per i video.
     */
    suspend fun related(videoId: String, music: Boolean): List<VideoItem> {
        val radio = if (music) runCatching {
            StreamParser.parseVideoItems(
                post(
                    "next", Clients.WEB_REMIX,
                    JSONObject().put("videoId", videoId).put("playlistId", "RDAMVM$videoId").put("isAudioOnly", true),
                    origin = YT_MUSIC,
                )
            )
        }.getOrNull()?.takeIf { it.size > 1 } else null
        val list = radio ?: StreamParser.parseVideoItems(post("next", Clients.WEB, JSONObject().put("videoId", videoId)))
        val others = list.filter { it.id != videoId }
        return if (music) MusicFilter.clean(others) else others
    }

    /**
     * Artisti: da YouTube Music (con canale ufficiale); se non disponibile,
     * dai canali YouTube trattati come artisti.
     */
    suspend fun searchArtists(query: String): List<VideoItem> {
        val music = runCatching {
            StreamParser.parseMusicArtists(
                post(
                    "search", Clients.WEB_REMIX,
                    JSONObject().put("query", query).put("params", FILTER_ARTISTS),
                    origin = YT_MUSIC,
                )
            )
        }.onFailure { Diagnostics.log("Ricerca artisti YouTube Music fallita: ${it.message}") }.getOrDefault(emptyList())
        if (music.isNotEmpty()) return music
        return searchChannels(query).map {
            it.copy(id = it.title, author = "Artista", kind = ItemKind.ARTIST, channelId = it.id)
        }
    }

    /** Hit del momento: classifiche di YouTube Music per il paese (Italia). */
    suspend fun musicCharts(country: String = "IT"): List<VideoItem> {
        val list = runCatching {
            StreamParser.parseMusic(
                post(
                    "browse", Clients.WEB_REMIX,
                    JSONObject().put("browseId", "FEmusic_charts")
                        .put("formData", JSONObject().put("selectedValues", org.json.JSONArray().put(country))),
                    origin = YT_MUSIC,
                )
            )
        }.onFailure { Diagnostics.log("Classifiche YouTube Music non disponibili: ${it.message}") }
            .getOrDefault(emptyList())
        val clean = MusicFilter.clean(list)
        return clean.ifEmpty { searchMusic("hit del momento italia") }
    }

    /**
     * Nuove uscite di YouTube Music: singoli/EP/album appena pubblicati,
     * di ognuno si prendono i brani principali.
     */
    suspend fun musicNewReleases(limit: Int = 24): List<VideoItem> = coroutineScope {
        val releases = runCatching {
            StreamParser.parseReleases(
                post("browse", Clients.WEB_REMIX, JSONObject().put("browseId", "FEmusic_new_releases"), origin = YT_MUSIC)
            )
        }.onFailure { Diagnostics.log("Nuove uscite YouTube Music non disponibili: ${it.message}") }
            .getOrDefault(emptyList())
            .sortedBy { if (it.type in setOf("Singolo", "Single", "EP")) 0 else 1 }
            .take(18)
        val tracks = releases.map { rel ->
            async {
                runCatching {
                    val songs = StreamParser.parseMusic(
                        post("browse", Clients.WEB_REMIX, JSONObject().put("browseId", rel.browseId), origin = YT_MUSIC)
                    ).take(if (rel.type == "Album") 2 else 1)
                    songs.map { s ->
                        s.copy(
                            author = s.author.ifBlank { rel.artist },
                            thumbnailUrl = s.thumbnailUrl ?: rel.thumb,
                            published = rel.type,
                        )
                    }
                }.getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
        MusicFilter.clean(tracks).distinctBy { it.id }.take(limit)
    }

    /** Playlist. */
    suspend fun searchPlaylists(query: String): List<VideoItem> =
        StreamParser.parsePlaylists(
            post("search", Clients.WEB, JSONObject().put("query", query).put("params", FILTER_PLAYLISTS))
        )

    /** Dirette in corso. */
    suspend fun searchLive(query: String): List<VideoItem> =
        StreamParser.parseVideoItems(
            post("search", Clients.WEB, JSONObject().put("query", query).put("params", FILTER_LIVE))
        )

    /** Video caricati nell'ultimo mese (nuove uscite di un artista). */
    suspend fun searchRecent(query: String): List<VideoItem> =
        StreamParser.parseVideoItems(
            post("search", Clients.WEB, JSONObject().put("query", query).put("params", FILTER_THIS_MONTH))
        )

    /** Canali. */
    suspend fun searchChannels(query: String): List<VideoItem> =
        StreamParser.parseChannels(
            post("search", Clients.WEB, JSONObject().put("query", query).put("params", FILTER_CHANNELS))
        )

    /** Video di un canale (scheda "Video", dai più recenti). */
    suspend fun channelVideos(channelId: String): List<VideoItem> =
        StreamParser.parseVideoItems(
            post("browse", Clients.WEB, JSONObject().put("browseId", channelId).put("params", TAB_VIDEOS))
        ).ifEmpty { browse(channelId) }

    /** Playlist di un canale. */
    suspend fun channelPlaylists(channelId: String): List<VideoItem> =
        StreamParser.parsePlaylists(
            post("browse", Clients.WEB, JSONObject().put("browseId", channelId).put("params", TAB_PLAYLISTS))
        )

    /** Brani di una playlist (prima pagina, fino a ~100). */
    suspend fun playlist(playlistId: String): List<VideoItem> =
        StreamParser.parseVideoItems(post("browse", Clients.WEB, JSONObject().put("browseId", "VL$playlistId")))

    /** /youtubei/v1/browse generico, es. canale "UC...". */
    suspend fun browse(browseId: String, params: String? = null): List<VideoItem> {
        val payload = JSONObject().put("browseId", browseId)
        if (params != null) payload.put("params", params)
        return StreamParser.parseVideoItems(post("browse", Clients.WEB, payload))
    }

    /** /youtubei/v1/player con il client indicato. */
    suspend fun player(videoId: String, client: ClientProfile): JSONObject =
        post(
            "player", client,
            JSONObject()
                .put("videoId", videoId)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
                .put(
                    "playbackContext", JSONObject().put(
                        "contentPlaybackContext",
                        JSONObject().put("html5Preference", "HTML5_PREF_WANTS")
                    )
                )
        )

    /**
     * Player con l'account dell'utente (client TV, come yt-dlp con i cookie).
     * I link arrivano cifrati: li decifra chi chiama (vedi StreamResolver).
     */
    suspend fun playerAuthenticated(videoId: String, signatureTimestamp: Int?): JSONObject {
        val ctx = JSONObject().put("html5Preference", "HTML5_PREF_WANTS")
        if (signatureTimestamp != null) ctx.put("signatureTimestamp", signatureTimestamp)
        return post(
            "player", TV_CLIENT,
            JSONObject()
                .put("videoId", videoId)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
                .put("playbackContext", JSONObject().put("contentPlaybackContext", ctx)),
            headers = Account.authHeaders(YT),
        )
    }

    companion object {
        /** Client TV (TVHTML5): accetta l'accesso con i cookie dell'account. */
        val TV_CLIENT = ClientProfile(
            "TV", "TVHTML5", 7, "7.20250219.14.00",
            "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version", emptyMap(),
        )
        private const val YT = "https://www.youtube.com"
        private const val YT_MUSIC = "https://music.youtube.com"
        private const val FILTER_VIDEOS = "EgIQAQ=="
        private const val FILTER_PLAYLISTS = "EgIQAw=="
        private const val FILTER_CHANNELS = "EgIQAg=="
        private const val FILTER_THIS_MONTH = "EgQIBBAB"
        /** Solo dirette in corso. */
        private const val FILTER_LIVE = "EgJAAQ=="
        private const val TAB_VIDEOS = "EgZ2aWRlb3PyBgQKAjoA"
        private const val TAB_PLAYLISTS = "EglwbGF5bGlzdHPyBgQKAkIA"
        private const val FILTER_ARTISTS = "EgWKAQIgAWoMEA4QChADEAQQCRAF"
        private const val FILTER_SONGS = "EgWKAQIIAWoMEA4QChADEAQQCRAF"
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
