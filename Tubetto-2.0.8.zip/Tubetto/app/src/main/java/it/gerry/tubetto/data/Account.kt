package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Accesso facoltativo con un account Google/YouTube (cookie della sessione web).
 * Serve solo come ultima risorsa: video con limiti di età, riservati agli iscritti,
 * controlli "non sei un bot". Restano sul dispositivo; verso gli altri dispositivi
 * viaggiano solo CIFRATI con un codice scelto dall'utente.
 */
object Account {

    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.getSharedPreferences("account", Context.MODE_PRIVATE)
    }

    var cookies: String
        get() = sp.getString("cookies", "").orEmpty()
        private set(v) = sp.edit().putString("cookies", v).apply()

    /** Quando è stato fatto l'accesso (per capire quale copia è la più recente). */
    var updatedAt: Long
        get() = sp.getLong("updated", 0L)
        private set(v) = sp.edit().putLong("updated", v).apply()

    /** Codice per cifrare l'accesso nella sincronizzazione (vuoto = non sincronizzare l'accesso). */
    var syncCode: String
        get() = sp.getString("code", "").orEmpty()
        set(v) = sp.edit().putString("code", v.trim()).apply()

    val isLoggedIn: Boolean get() = sapisid() != null

    fun save(cookieHeader: String, at: Long = System.currentTimeMillis()) {
        cookies = cookieHeader.trim()
        updatedAt = at
    }

    fun logout() {
        sp.edit().remove("cookies").putLong("updated", System.currentTimeMillis()).apply()
    }

    private fun cookie(name: String): String? =
        cookies.split(";").map { it.trim() }.firstOrNull { it.startsWith("$name=") }?.substringAfter('=')?.ifBlank { null }

    private fun sapisid(): String? = cookie("SAPISID") ?: cookie("__Secure-3PAPISID")

    /** Intestazioni per le richieste autenticate a youtube.com. */
    fun authHeaders(origin: String = "https://www.youtube.com"): Map<String, String> {
        val sid = sapisid() ?: return emptyMap()
        val ts = System.currentTimeMillis() / 1000
        val hash = MessageDigest.getInstance("SHA-1").digest("$ts $sid $origin".toByteArray())
            .joinToString("") { "%02x".format(it) }
        return mapOf(
            "Cookie" to cookies,
            "Authorization" to "SAPISIDHASH ${ts}_$hash",
            "X-Origin" to origin,
            "X-Goog-AuthUser" to "0",
        )
    }

    // ---------------- Cifratura per la sincronizzazione ----------------

    private fun key(code: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(code.toCharArray(), salt, 20_000, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    /** Accesso cifrato da mettere nel file di sincronizzazione (null se manca l'accesso o il codice). */
    fun exportEncrypted(): JSONObject? {
        val code = syncCode
        if (code.isBlank() || updatedAt == 0L) return null
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(code, salt), GCMParameterSpec(128, iv))
        val data = c.doFinal(cookies.toByteArray())
        fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
        return JSONObject().put("updated", updatedAt).put("salt", b64(salt)).put("iv", b64(iv)).put("data", b64(data))
    }

    /**
     * Importa l'accesso arrivato da un altro dispositivo, se più recente.
     * @return true se è cambiato; false se uguale/più vecchio; null se il codice è sbagliato o manca.
     */
    fun importEncrypted(o: JSONObject): Boolean? {
        val updated = o.optLong("updated")
        if (updated <= updatedAt) return false
        val code = syncCode.ifBlank { return null }
        return runCatching {
            val salt = Base64.decode(o.getString("salt"), Base64.NO_WRAP)
            val iv = Base64.decode(o.getString("iv"), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(code, salt), GCMParameterSpec(128, iv))
            val plain = String(c.doFinal(Base64.decode(o.getString("data"), Base64.NO_WRAP)))
            save(plain, updated)
            true
        }.getOrNull()
    }
}
