package it.gerry.tubetto.data

import android.content.Context

/** Foto degli artisti (da YouTube Music), salvate in cache per non ricercarle ogni volta. */
object ArtistImages {
    private lateinit var sp: android.content.SharedPreferences

    fun init(context: Context) {
        sp = context.getSharedPreferences("artist_images", Context.MODE_PRIVATE)
    }

    fun cached(name: String): String? = sp.getString(name.lowercase(), null)?.ifBlank { null }

    suspend fun get(api: YouTubeApiHelper, name: String): String? {
        cached(name)?.let { return it }
        val found = runCatching { api.searchArtists(name).firstOrNull { it.title.equals(name, true) } ?: api.searchArtists(name).firstOrNull() }
            .getOrNull()
        val url = found?.thumbnailUrl
        if (url != null) sp.edit().putString(name.lowercase(), url).apply()
        return url
    }
}
