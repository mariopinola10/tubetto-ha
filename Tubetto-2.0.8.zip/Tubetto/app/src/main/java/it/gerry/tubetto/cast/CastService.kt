package it.gerry.tubetto.cast

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Tiene vivo il telefono mentre fa da ponte verso la TV:
 * servizio in primo piano + wake lock + Wi-Fi ad alte prestazioni.
 * Si ferma da solo quando la TV smette di riprodurre.
 */
class CastService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var monitor: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val r = current
            scope.launch {
                r?.let { runCatching { Dlna.stop(it) } }
                current = null
                stopSelf()
            }
            return START_NOT_STICKY
        }

        val r = current ?: run { stopSelf(); return START_NOT_STICKY }
        val title = intent?.getStringExtra(EXTRA_TITLE).orEmpty()
        startInForeground(r.name, title)
        acquireLocks()
        startMonitor(r)
        return START_NOT_STICKY
    }

    private fun startInForeground(device: String, title: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Trasmissione su TV", NotificationManager.IMPORTANCE_LOW))

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CastService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("In onda su $device")
            .setContentText(title)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Stop TV", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wakeLock == null) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tubetto:cast")
                .apply { setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L) }
        }
        if (wifiLock == null) {
            wifiLock = applicationContext.getSystemService(WifiManager::class.java)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "tubetto:cast")
                .apply { setReferenceCounted(false); acquire() }
        }
    }

    /** Controlla la TV ogni 20 s: se ha finito o è stata spenta, chiude il servizio. */
    private fun startMonitor(r: Renderer) {
        monitor?.cancel()
        monitor = scope.launch {
            delay(15_000)
            var idleChecks = 0
            while (isActive) {
                val state = runCatching { Dlna.transportState(r) }.getOrNull()
                idleChecks = if (state == null || state == "STOPPED" || state == "NO_MEDIA_PRESENT") idleChecks + 1 else 0
                if (idleChecks >= 3) {
                    Diagnostics.log("TV ${r.name} ferma ($state): chiudo la trasmissione")
                    current = null
                    stopSelf()
                    break
                }
                delay(20_000)
            }
        }
    }

    override fun onDestroy() {
        runCatching { wakeLock?.release() }
        runCatching { wifiLock?.release() }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "cast"
        private const val NOTIFICATION_ID = 42
        private const val ACTION_STOP = "it.gerry.tubetto.CAST_STOP"
        private const val EXTRA_TITLE = "title"

        @Volatile
        var current: Renderer? = null
            private set

        fun start(context: Context, renderer: Renderer, title: String) {
            current = renderer
            ContextCompat.startForegroundService(
                context, Intent(context, CastService::class.java).putExtra(EXTRA_TITLE, title)
            )
        }

        fun stop(context: Context) {
            current = null
            context.stopService(Intent(context, CastService::class.java))
        }
    }
}
