package it.gerry.tubetto.playback

import android.content.Context

/** Impostazioni audio: qualità (consumo dati) e profilo sonoro. */
object AudioPrefs {

    enum class Quality(val label: String, val maxKbps: Int) {
        AUTO("Automatica: massima su Wi-Fi, media su dati mobili", 0),
        HIGH("Massima — Opus ~160 kbps (~70 MB/ora)", 1000),
        MEDIUM("Media — ~128 kbps (~55 MB/ora)", 135),
        BALANCED("Bassa — Opus ~70 kbps (~30 MB/ora)", 90),
        SAVER("Risparmio — ~50 kbps (~22 MB/ora)", 55),
    }

    enum class Profile(val label: String) {
        NATURAL("Naturale (nessuna modifica)"),
        CAR("Auto: bassi e alti più presenti, volume uniforme"),
        BASS("Bassi potenti"),
    }

    private fun sp(c: Context) = c.getSharedPreferences("audio", Context.MODE_PRIVATE)

    fun quality(c: Context): Quality =
        runCatching { Quality.valueOf(sp(c).getString("quality", Quality.AUTO.name)!!) }.getOrDefault(Quality.AUTO)

    fun setQuality(c: Context, q: Quality) = sp(c).edit().putString("quality", q.name).apply()

    fun profile(c: Context): Profile =
        runCatching { Profile.valueOf(sp(c).getString("profile", Profile.CAR.name)!!) }.getOrDefault(Profile.CAR)

    fun setProfile(c: Context, p: Profile) = sp(c).edit().putString("profile", p.name).apply()

    /** kbps massimi per l'audio in base a impostazione e rete. */
    fun maxAudioKbps(c: Context): Int {
        val q = quality(c)
        if (q != Quality.AUTO) return q.maxKbps
        return if (Buffering.maxVideoHeight(c) >= 1080) Quality.HIGH.maxKbps else Quality.MEDIUM.maxKbps
    }

    fun register(c: Context, onChange: () -> Unit) =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> onChange() }
            .also { sp(c).registerOnSharedPreferenceChangeListener(it) }
}
