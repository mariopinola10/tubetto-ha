package it.gerry.tubetto.data

/**
 * Ripulisce titolo e artista dei video musicali:
 * "Vasco Rossi - Albachiara (Official Video)" di "VascoRossiVEVO"
 * → titolo "Albachiara", artista "Vasco Rossi".
 */
object MetaCleaner {

    private val BRACKETS = Regex(
        "(?i)\\s*[(\\[【][^)\\]】]*(official|ufficiale|video|audio|lyric|testo|visualizer|videoclip|\\bhd\\b|4k|remaster|explicit|clip)[^)\\]】]*[)\\]】]"
    )
    private val SUFFIX = Regex("(?i)\\s*[-|]\\s*(official (music )?video|videoclip ufficiale|video ufficiale|lyrics?|testo|audio)\\s*$")
    private val DASH = Regex("^(.+?)\\s+[-–—]\\s+(.+)$")

    fun cleanArtist(author: String): String =
        author.replace(Regex("(?i)\\s*-\\s*topic$"), "")
            .replace(Regex("(?i)\\s*vevo$"), "")
            .replace(Regex("(?i)\\s*official$"), "")
            .trim()

    /** @return titolo e artista puliti. */
    fun clean(title: String, author: String): Pair<String, String> {
        var t = title.replace(BRACKETS, "").replace(SUFFIX, "").trim()
        var a = cleanArtist(author)
        DASH.find(t)?.let { m ->
            val left = m.groupValues[1].trim()
            val right = m.groupValues[2].trim()
            if (a.isNotBlank() && right.contains(a, ignoreCase = true) && !left.contains(a, ignoreCase = true)) {
                t = left            // formato "Brano - Artista"
            } else {
                a = left            // formato "Artista - Brano"
                t = right
            }
        }
        if (t.isBlank()) t = title.trim()
        return t to a
    }

    /** Chiave per riconoscere la stessa canzone anche da video diversi (ufficiale, audio, lyric). */
    fun key(title: String, author: String): String {
        val (t, a) = clean(title, author)
        return (a + "|" + t).lowercase().replace(Regex("[^\\p{L}\\p{N}|]"), "")
    }
}
