package it.gerry.tubetto.ui

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

/** Riconosce telefono, tablet o TV (Fire TV / Android TV) e decide la griglia. */
object DeviceProfile {

    enum class Kind { PHONE, TABLET, TV }

    fun kind(context: Context): Kind {
        val ui = context.getSystemService(UiModeManager::class.java)
        val pm = context.packageManager
        val tv = ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature("amazon.hardware.fire_tv")
        return when {
            tv -> Kind.TV
            context.resources.configuration.smallestScreenWidthDp >= 600 -> Kind.TABLET
            else -> Kind.PHONE
        }
    }

    /** Colonne della lista in base a dispositivo e larghezza attuale (cambia ruotando). */
    fun columns(context: Context): Int {
        val w = context.resources.configuration.screenWidthDp
        return when (kind(context)) {
            Kind.TV -> 4 // la barra laterale occupa ~250dp
            Kind.TABLET -> if (w >= 900) 3 else 2
            Kind.PHONE -> if (w >= 600) 2 else 1
        }
    }
}
