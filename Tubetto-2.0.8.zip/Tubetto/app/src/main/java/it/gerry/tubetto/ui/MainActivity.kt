package it.gerry.tubetto.ui

import it.gerry.tubetto.playback.SponsorBlock
import android.Manifest
import android.app.UiModeManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import it.gerry.tubetto.data.UserProfile
import it.gerry.tubetto.data.SpotifyImport
import it.gerry.tubetto.data.Recents
import it.gerry.tubetto.data.Account
import it.gerry.tubetto.data.Radio
import it.gerry.tubetto.data.OwnSync
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.widget.doAfterTextChanged
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputLayout
import com.google.common.util.concurrent.ListenableFuture
import it.gerry.tubetto.BuildConfig
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.R
import it.gerry.tubetto.cast.CastService
import it.gerry.tubetto.cast.Dlna
import it.gerry.tubetto.cast.Renderer
import it.gerry.tubetto.cast.StreamProxy
import it.gerry.tubetto.data.ArtistImages
import it.gerry.tubetto.data.Charts
import it.gerry.tubetto.data.ServiceHealth
import it.gerry.tubetto.data.ItemKind
import it.gerry.tubetto.data.Library
import it.gerry.tubetto.data.MetaCleaner
import it.gerry.tubetto.data.MusicFilter
import it.gerry.tubetto.data.ListenHistory
import it.gerry.tubetto.data.Recommender
import it.gerry.tubetto.data.StreamResolver
import it.gerry.tubetto.data.SyncManager
import it.gerry.tubetto.data.VideoItem
import it.gerry.tubetto.data.YouTubeApiHelper
import it.gerry.tubetto.playback.AudioPrefs
import it.gerry.tubetto.playback.AutoplayPrefs
import it.gerry.tubetto.playback.PlaybackService
import it.gerry.tubetto.update.UpdatePrefs
import it.gerry.tubetto.update.Publisher
import it.gerry.tubetto.update.Updater
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private companion object {
        const val MIX_TITLE = "✨ Il mio mix"
        const val PIP_PLAY = "it.gerry.tubetto.PIP_PLAY"
        const val PIP_NEXT = "it.gerry.tubetto.PIP_NEXT"
        const val PIP_PREV = "it.gerry.tubetto.PIP_PREV"
        const val PIP_AUDIO = "it.gerry.tubetto.PIP_AUDIO"
    }


    private enum class Mode { VIDEO, MUSIC, PLAYLIST, ARTIST, CHANNEL, RADIO }

    /**
     * Pagina mostrata nella lista.
     * @param queue toccando un video parte la coda audio da quel punto (musica, playlist, preferiti)
     * @param localPlaylist nome della playlist personale mostrata
     * @param channel canale mostrato (per "Segui")
     */
    private data class Page(
        val items: List<VideoItem>,
        val title: String,
        val subtitle: String = "",
        val queue: Boolean = false,
        val playAll: Boolean = false,
        val localPlaylist: String? = null,
        val channel: VideoItem? = null,
        val favorites: Boolean = false,
        val artist: String? = null,
        val artistChannelId: String? = null,
        /** Home a scaffali orizzontali (se presente, al posto della griglia). */
        val shelves: List<Shelf>? = null,
    )

    private val api = YouTubeApiHelper()
    private val resolver = StreamResolver(api)
    private val recommender = Recommender(api)
    private lateinit var updater: Updater
    private lateinit var prefs: UpdatePrefs

    private lateinit var toolbar: MaterialToolbar
    private lateinit var playerView: PlayerView

    /** Telefono: video ridotto in un riquadro flottante mentre si scorre (stile picture-in-picture). */
    private var floatVideo: View? = null
    private var pipView: PlayerView? = null

    /** TV: video in piccolo nel mini player in basso. */
    private var tvMiniView: PlayerView? = null
    private var tvMini = false
    /** TV: un video appena scelto si apre a schermo intero (una volta). */
    private var tvWantFullscreen = false
    private var videoMini = false
    private var appliedNightMode = 0

    /** Player a schermo intero (telefono) e modalità "solo audio" per i video. */
    private var fullPlayer: FullPlayer? = null
    private var audioOnlyVideo = false
    private var pendingSeekMs = 0L
    private var playSource = ""
    private val fullPlayerBack = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { fullPlayer?.close() }
    }
    private lateinit var browseArea: View
    private lateinit var progress: ProgressBar
    private lateinit var query: EditText
    private lateinit var queryLayout: TextInputLayout
    private lateinit var sectionTitle: TextView
    private lateinit var sectionSubtitle: TextView
    private lateinit var playAllBtn: Button
    private lateinit var headerBtn: Button
    private lateinit var headerBtn2: Button
    private lateinit var chips: ChipGroup
    private lateinit var list: RecyclerView
    private lateinit var miniBar: View
    private lateinit var miniThumb: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageButton
    private lateinit var nowRow: LinearLayout
    private lateinit var nowInfo: View
    private lateinit var nowLabel: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var nowMeta: TextView
    private lateinit var nowDesc: TextView
    private lateinit var nowNext: TextView

    /** Dati completi dei video visti nelle liste (visualizzazioni, data, descrizione). */
    private val knownItems = HashMap<String, VideoItem>()
    private var contentPad = IntArray(4)
    private val adapter = VideoAdapter(::onItemClick, ::onItemLongClick)

    private var mode = Mode.MUSIC

    private enum class HomeFilter { ALL, MUSIC, VIDEO, LIVE, RADIO }
    private enum class Tab { HOME, SEARCH, LIBRARY }
    private var homeFilter = HomeFilter.ALL
    private var tab = Tab.HOME
    private var lastSearchPage: Page? = null
    private val shelfAdapter = ShelfAdapter(::onShelfClick, ::onItemLongClick)
    private val linear by lazy { LinearLayoutManager(this) }
    private lateinit var device: DeviceProfile.Kind
    private val isTv get() = device == DeviceProfile.Kind.TV
    private lateinit var grid: androidx.recyclerview.widget.GridLayoutManager
    private val pages = ArrayDeque<Page>()
    private var castTarget: Renderer? = null
    private var fullscreen = false
    private var ignoreChipEvents = false
    private var waitingPlayback = false
    private var previewFocused = false

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val controller: MediaController?
        get() = controllerFuture?.takeIf { it.isDone && !it.isCancelled }?.let { runCatching { it.get() }.getOrNull() }

    private val playerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            toast("Errore: ${Diagnostics.last()} — provo un'altra sorgente…")
        }

        override fun onEvents(player: Player, events: Player.Events) = updatePlayerUi()
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            when {
                fullscreen -> setFullscreen(false)
                pages.size > 1 -> {
                    pages.removeLast()
                    showPage(pages.last())
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Fire TV: sempre tema scuro ad alto contrasto (in salotto il chiaro abbaglia)
        if (DeviceProfile.kind(this) == DeviceProfile.Kind.TV) {
            delegate.localNightMode = androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
        }
        super.onCreate(savedInstanceState)

        device = DeviceProfile.kind(this)
        appliedNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        setContentView(R.layout.activity_main)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }

        updater = Updater(this)
        prefs = UpdatePrefs(this)
        toolbar = findViewById(R.id.toolbar)
        playerView = findViewById(R.id.playerView)
        floatVideo = findViewById(R.id.floatVideo)
        pipView = findViewById(R.id.pipView)
        tvMiniView = findViewById(R.id.tvMiniVideo)
        list = findViewById(R.id.list)
        setupMiniVideo()
        browseArea = findViewById(R.id.browseArea)
        progress = findViewById(R.id.progress)
        query = findViewById(R.id.query)
        queryLayout = findViewById(R.id.queryLayout)
        sectionTitle = findViewById(R.id.sectionTitle)
        sectionSubtitle = findViewById(R.id.sectionSubtitle)
        playAllBtn = findViewById(R.id.playAllBtn)
        headerBtn = findViewById(R.id.headerBtn)
        headerBtn2 = findViewById(R.id.headerBtn2)
        chips = findViewById(R.id.chips)
        list = findViewById(R.id.list)
        miniBar = findViewById(R.id.miniBar)
        miniThumb = findViewById(R.id.miniThumb)
        miniTitle = findViewById(R.id.miniTitle)
        miniArtist = findViewById(R.id.miniArtist)
        miniPlay = findViewById(R.id.miniPlay)
        nowRow = findViewById(R.id.nowPlayingRow)
        nowInfo = findViewById(R.id.nowInfo)
        nowLabel = findViewById(R.id.nowLabel)
        nowTitle = findViewById(R.id.nowTitle)
        nowArtist = findViewById(R.id.nowArtist)
        nowMeta = findViewById(R.id.nowMeta)
        nowDesc = findViewById(R.id.nowDesc)
        nowNext = findViewById(R.id.nowNext)

        // Margini originali (diversi tra telefono e layout TV con barra laterale)
        findViewById<View>(R.id.content).let { v -> contentPad = intArrayOf(v.paddingLeft, v.paddingTop, v.paddingRight, v.paddingBottom) }

        // Barra laterale TV: voci di menu come pulsanti (sul telefono non esistono)
        findViewById<View>(R.id.btnAudio)?.setOnClickListener { onMenu(R.id.action_audio) }
        findViewById<View>(R.id.btnReceiver)?.setOnClickListener { onMenu(R.id.action_receiver) }
        findViewById<View>(R.id.btnUpdate)?.setOnClickListener { onMenu(R.id.action_update) }
        findViewById<View>(R.id.btnSync)?.setOnClickListener { onMenu(R.id.action_sync) }
        findViewById<View>(R.id.btnSettings)?.setOnClickListener { onMenu(R.id.action_settings) }
        findViewById<View>(R.id.btnLog)?.setOnClickListener { onMenu(R.id.action_log) }

        toolbar.apply {
            title = "Tubetto" // la versione è in Aggiornamenti / Stato servizio
            inflateMenu(R.menu.main)
            setOnMenuItemClickListener { onMenu(it.itemId); true }
            if (isTv) {
                // Sulla TV non serve trasmettere verso altre TV; il ricevitore invece sì
                menu.findItem(R.id.action_cast)?.isVisible = false
                menu.findItem(R.id.action_tv)?.isVisible = false
                menu.findItem(R.id.action_share)?.isVisible = false
                menu.findItem(R.id.action_receiver)?.title = "📺 Ricevi dal telefono"
                menu.findItem(R.id.action_audio)?.title = "🎚 Audio e qualità"
                menu.findItem(R.id.action_spotify)?.isVisible = false
                // Su TV i tre puntini sostituiscono i pulsanti della barra laterale
                menu.add(0, R.id.action_update, 50, "⟳ Controlla aggiornamenti")
                if (UpdatePrefs(this@MainActivity).isAdmin) {
                    menu.add(0, R.id.action_sync, 51, "⇅ Sincronizza dispositivi")
                    menu.add(0, R.id.action_log, 52, "🧾 Log diagnostica")
                }
                menu.findItem(R.id.action_app_settings)?.title = "⚙ Impostazioni (aggiornamenti, sincronizzazione, log)"
                // La barra laterale resta pulita: queste voci sono tutte nei tre puntini
                listOf(R.id.sidebarDivider, R.id.btnAudio, R.id.btnReceiver, R.id.btnSync, R.id.btnUpdate, R.id.btnSettings, R.id.btnLog)
                    .forEach { id -> findViewById<View>(id)?.visibility = View.GONE }
            }
        }

        // Griglia adattiva: 1 colonna sul telefono, 2-3 sul tablet, 4 card grandi su TV
        adapter.tvMode = isTv
        shelfAdapter.tvMode = isTv
        if (isTv) {
            // TV: due righe intere di copertine sempre visibili; si ricalcola se cambia lo spazio
            list.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
                val hNow = bottom - top - list.paddingTop - list.paddingBottom
                if (hNow > 0 && hNow / 2 != shelfAdapter.tvRowHeightPx && list.adapter === shelfAdapter) {
                    shelfAdapter.tvRowHeightPx = hNow / 2
                    list.post { shelfAdapter.notifyDataSetChanged() }
                }
            }
        }
        grid = androidx.recyclerview.widget.GridLayoutManager(this, DeviceProfile.columns(this))
        grid.spanSizeLookup = object : androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (adapter.items.getOrNull(position)?.kind == ItemKind.HEADER) grid.spanCount else 1
        }
        list.layoutManager = grid
        list.adapter = adapter

        // Player video grande: 16:9, schermo intero col tasto del player (automatico su TV)
        applyPlayerSize()
        if (isTv) {
            // Anteprima piccola: niente comandi sopra, selezionabile col telecomando, OK = schermo intero
            playerView.useController = false
            playerView.isFocusable = true
            playerView.isFocusableInTouchMode = false
            playerView.foreground = ContextCompat.getDrawable(this, R.drawable.player_focus)
            playerView.setOnClickListener { if (!fullscreen) setFullscreen(true) }
            playerView.setOnKeyListener { _, keyCode, event ->
                if (!fullscreen && event.action == android.view.KeyEvent.ACTION_UP &&
                    (keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER || keyCode == android.view.KeyEvent.KEYCODE_ENTER)
                ) { setFullscreen(true); true } else false
            }
        } else {
            playerView.setFullscreenButtonClickListener { setFullscreen(it) }
        }

        findViewById<Button>(R.id.searchBtn).setOnClickListener { search() }
        query.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false
        }
        findViewById<ChipGroup>(R.id.modeGroup).setOnCheckedStateChangeListener { _, ids ->
            val id = ids.firstOrNull() ?: return@setOnCheckedStateChangeListener
            mode = when (id) {
                R.id.modeMusic -> Mode.MUSIC
                R.id.modePlaylist -> Mode.PLAYLIST
                R.id.modeArtist -> Mode.ARTIST
                R.id.modeChannel -> Mode.CHANNEL
                R.id.modeRadio -> Mode.RADIO
                else -> Mode.VIDEO
            }
            queryLayout.hint = "Cerca"
            if (query.text.isNotBlank()) search()
        }
        chips.setOnCheckedStateChangeListener { _, ids ->
            if (ignoreChipEvents) return@setOnCheckedStateChangeListener
            when (ids.firstOrNull()) {
                R.id.chipHome -> loadHome()
                R.id.chipLibAll -> showLibrary()
                R.id.chipMix -> showMyMix()
                R.id.chipCharts -> showCharts()
                R.id.chipArtists -> showArtists()
                R.id.chipFav -> showFavorites()
                R.id.chipMyPl -> showMyPlaylists()
                R.id.chipChannels -> showChannels()
                R.id.chipHistory -> showHistory()
            }
        }

        // Schede in basso (telefono/tablet)
        findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNav)
            ?.setOnItemSelectedListener { item ->
                showTab(
                    when (item.itemId) {
                        R.id.nav_search -> Tab.SEARCH
                        R.id.nav_library -> Tab.LIBRARY
                        else -> Tab.HOME
                    }
                )
                true
            }
        // Filtro della home: Tutti / Musica / Video
        findViewById<ChipGroup>(R.id.homeChips)?.setOnCheckedStateChangeListener { _, ids ->
            homeFilter = when (ids.firstOrNull()) {
                R.id.chipMusicF -> HomeFilter.MUSIC
                R.id.chipVideoF -> HomeFilter.VIDEO
                R.id.chipLiveF -> HomeFilter.LIVE
                R.id.chipRadioF -> HomeFilter.RADIO
                else -> HomeFilter.ALL
            }
            loadHome()
        }
        // Fire TV: barra laterale Home / Cerca / La tua libreria (come la barra in basso del telefono)
        findViewById<View>(R.id.navHome)?.setOnClickListener { showTab(Tab.HOME) }
        findViewById<View>(R.id.navSearch)?.setOnClickListener { showTab(Tab.SEARCH) }
        findViewById<View>(R.id.navLibrary)?.setOnClickListener { showTab(Tab.LIBRARY) }
        markNav(Tab.HOME)
        findViewById<ChipGroup>(R.id.modeGroup).check(R.id.modeMusic)
        // Cerca: "Cancella" ricerche recenti; campo svuotato con la X → torna la schermata iniziale di Cerca
        findViewById<View>(R.id.recentClear)?.setOnClickListener {
            saveRecent(emptyList())
            renderRecent()
        }
        query.doAfterTextChanged { t ->
            if (tab == Tab.SEARCH && t.isNullOrBlank() && findViewById<View>(R.id.bottomNav) != null) showSearchZero()
        }

        playAllBtn.setOnClickListener {
            controller?.shuffleModeEnabled = false
            pages.lastOrNull()?.let { p -> playQueue(p.items.filter { it.kind == ItemKind.VIDEO }, 0) }
        }
        // Riproduzione casuale della lista aperta
        findViewById<View>(R.id.shuffleBtn).setOnClickListener {
            pages.lastOrNull()?.let { p ->
                val vids = p.items.filter { it.kind == ItemKind.VIDEO }
                if (vids.isNotEmpty()) {
                    // coda già mescolata dall'inizio: ⏭/⏮ e "Poi:" seguono l'ordine che si vede
                    controller?.shuffleModeEnabled = false
                    playQueue(vids.shuffled(), 0)
                    refreshShuffle()
                    toast("🔀 Riproduzione casuale")
                }
            }
        }
        // Casuale acceso/spento sulla coda in corso
        findViewById<ImageButton>(R.id.miniShuffle).setOnClickListener {
            controller?.let { c ->
                c.shuffleModeEnabled = !c.shuffleModeEnabled
                refreshShuffle()
                toast(if (c.shuffleModeEnabled) "🔀 Casuale attivo" else "Casuale disattivato")
            }
        }
        headerBtn.setOnClickListener { onHeaderButton() }
        headerBtn2.setOnClickListener { onHeaderButton2() }

        // Tocco sul mini player = player a schermo intero (telefono)
        miniBar.setOnClickListener {
            if (isTv) {
                setFullscreen(true)
                updatePlayerUi()
                return@setOnClickListener
            }
            val fp = fullPlayer
            if (fp != null) fp.open() else controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        miniBar.setOnLongClickListener {
            currentItemAsVideo()?.let { onItemLongClick(it, miniBar) } ?: toast("Niente in riproduzione")
            true
        }
        findViewById<View>(R.id.fvAudio)?.setOnClickListener { audioOnly() }
        findViewById<View>(R.id.fvShare)?.setOnClickListener { shareCurrent() }
        // Schermo intero (telefono): riduci a riquadro, condividi, chiudi il video
        findViewById<View>(R.id.fsShrink)?.setOnClickListener { setFullscreen(false) }
        findViewById<View>(R.id.fsShare)?.setOnClickListener { shareCurrent() }
        findViewById<View>(R.id.fsClose)?.setOnClickListener { audioOnly() }
        if (!isTv) {
            playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
                findViewById<View>(R.id.fsBar)?.visibility = if (fullscreen && vis == View.VISIBLE) View.VISIBLE else View.GONE
            })
        }
        // Fire TV: le voci per l'amministratore solo se attive
        if (!UpdatePrefs(this).isAdmin) {
            listOf(R.id.btnSync, R.id.btnLog).forEach { findViewById<View>(it)?.visibility = View.GONE }
        }
        findViewById<View>(R.id.btnSettings)?.setOnClickListener { showAppSettings() }
        // Primo avvio: scelta di artisti e generi per riempire subito la home
        if (!UserProfile.onboardingDone) {
            if (Library.artists().isNotEmpty()) UserProfile.onboardingDone = true
            else list.post { showOnboarding() }
        }
        if (savedInstanceState == null) list.post { handleShared(intent) }
        // Telefono: se il profilo non ha ancora un nome, lo chiede all'apertura
        if (!isTv && UserProfile.onboardingDone && UserProfile.name.isBlank() && savedInstanceState == null) {
            list.post { askProfileName() }
        }
        miniPlay.setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        // TV: mostra/nascondi il video e apri il player a schermo intero solo su richiesta
        findViewById<View>(R.id.miniVideo)?.setOnClickListener {
            if (audioOnlyVideo) backToVideo() else audioOnly()
        }
        // TV: 👤 apre il canale/artista del video in riproduzione
        findViewById<View>(R.id.miniChannel)?.setOnClickListener { openCurrentChannel() }
        findViewById<View>(R.id.miniOpen)?.setOnClickListener {
            setFullscreen(true)
            updatePlayerUi()
        }
        findViewById<ImageButton>(R.id.miniNext).setOnClickListener {
            Diagnostics.log("Avanti (tasto)")
            controller?.seekToNextMediaItem()
        }
        findViewById<View>(R.id.miniPrev)?.setOnClickListener {
            Diagnostics.log("Indietro (tasto)")
            controller?.seekToPreviousMediaItem()
        }
        findViewById<ImageButton>(R.id.miniClose).setOnClickListener {
            controller?.let { it.stop(); it.clearMediaItems() }
            updatePlayerUi()
        }

        onBackPressedDispatcher.addCallback(this, backCallback)
        if (!isTv) {
            ContextCompat.registerReceiver(
                this, pipReceiver,
                android.content.IntentFilter().apply {
                    addAction(PIP_PLAY); addAction(PIP_NEXT); addAction(PIP_PREV); addAction(PIP_AUDIO)
                },
                ContextCompat.RECEIVER_NOT_EXPORTED,
            )
        }
        if (!isTv) {
            fullPlayer = FullPlayer(this, { controller }, object : FullPlayer.Callbacks {
                override fun onCast() { castMenu(null) }
                override fun onOpenChannel() { openCurrentChannel() }
                override fun onMore(item: VideoItem, anchor: View) { onItemLongClick(item, anchor) }
                override fun onWatchVideo(item: VideoItem, positionMs: Long) {
                    pendingSeekMs = positionMs
                    playVideo(item)
                }
                override fun onBackToVideo() { backToVideo() }
                override fun isAudioOnlyVideo() = audioOnlyVideo
                override fun sourceTitle() = playSource
                override fun onOpenChanged(open: Boolean) { fullPlayerBack.isEnabled = open }
                override fun onShare(item: VideoItem) { share(item.id, listOf(item.title, item.author).filter { it.isNotBlank() }.joinToString(" — ")) }
                override fun onAudioOnly() { audioOnly() }
                override fun isVideoPlaying(): Boolean =
                    controller?.currentMediaItem?.mediaId?.let { !isAudioId(it) } == true && !audioOnlyVideo
            })
            onBackPressedDispatcher.addCallback(this, fullPlayerBack)
        }

        if (!isTv && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            // Prima di chiedere il permesso spiego a cosa servono le notifiche (una volta sola)
            val sp = getSharedPreferences("ui", MODE_PRIVATE)
            if (!sp.getBoolean("notif_asked", false)) {
                sp.edit().putBoolean("notif_asked", true).apply()
                AlertDialog.Builder(this)
                    .setTitle("Notifiche di Tubetto")
                    .setMessage(
                        "Servono solo per:\n\n" +
                            "• i comandi della musica nella tendina e nella schermata di blocco (play, pausa, avanti) mentre ascolti in background;\n" +
                            "• la trasmissione in corso su TV / Fire TV;\n" +
                            "• l'avviso quando c'è una nuova versione.\n\n" +
                            "Niente pubblicità o messaggi promozionali."
                    )
                    .setPositiveButton("Consenti") { _, _ -> requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
                    .setNegativeButton("Non ora", null)
                    .show()
            }
        }

        loadHome()
        if (savedInstanceState == null) checkUpdate(silent = true)
    }

    override fun onStart() {
        super.onStart()
        syncNow(manual = false)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { f ->
            f.addListener({
                controller?.let {
                    it.addListener(playerListener)
                    playerView.player = it
                    setVideoEnabled(!audioOnlyVideo)
                    updatePlayerUi()
                }
            }, ContextCompat.getMainExecutor(this))
        }
    }

    override fun onStop() {
        // Finestrella PiP chiusa con la ✕: da ora solo audio (anche al rientro nell'app)
        if (inPip) audioOnlyVideo = true
        // Fire TV / Android TV: uscendo dall'app (Home, Indietro, altra app) la musica si ferma
        if (isTv && !isChangingConfigurations) {
            controller?.let {
                it.pause()
                if (isFinishing) {
                    it.stop()
                    it.clearMediaItems()
                }
            }
        }
        SyncManager.flush()
        setVideoEnabled(false)
        controller?.removeListener(playerListener)
        playerView.player = null
        pipView?.player = null
        videoMini = false
        tvMiniView?.player = null
        tvMiniView?.visibility = View.GONE
        if (isTv) miniThumb.visibility = View.VISIBLE
        tvMini = false
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    /** Altezza del player: 16:9, mai oltre metà schermo; su TV anteprima piccola (~1/3). */
    private fun playerHeight(): Int {
        val dm = resources.displayMetrics
        if (isTv) return (dm.heightPixels * 0.32).toInt()
        return minOf(dm.widthPixels * 9 / 16, (dm.heightPixels * 0.55).toInt())
    }

    /**
     * Riga "in riproduzione":
     * - telefono/tablet: video a tutta larghezza, sotto titolo/artista/dati compatti;
     * - TV: video piccolo a sinistra, a destra titolo grande, artista, dati, descrizione, prossimo brano;
     * - schermo intero: solo il video.
     */
    private fun applyPlayerSize() {
        val rowLp = nowRow.layoutParams as LinearLayout.LayoutParams
        val pvLp = playerView.layoutParams as LinearLayout.LayoutParams
        if (fullscreen) {
            rowLp.height = 0; rowLp.weight = 1f
            pvLp.width = LinearLayout.LayoutParams.MATCH_PARENT
            pvLp.height = LinearLayout.LayoutParams.MATCH_PARENT
            pvLp.weight = 0f
            nowInfo.visibility = View.GONE
        } else if (isTv) {
            nowRow.orientation = LinearLayout.HORIZONTAL
            val h = playerHeight()
            rowLp.height = h; rowLp.weight = 0f
            pvLp.height = h
            pvLp.width = h * 16 / 9
            pvLp.weight = 0f
            nowInfo.visibility = View.VISIBLE
            nowInfo.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        } else {
            nowRow.orientation = LinearLayout.VERTICAL
            rowLp.height = LinearLayout.LayoutParams.WRAP_CONTENT; rowLp.weight = 0f
            pvLp.width = LinearLayout.LayoutParams.MATCH_PARENT
            pvLp.height = playerHeight()
            pvLp.weight = 0f
            nowInfo.visibility = View.VISIBLE
            nowInfo.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        nowRow.layoutParams = rowLp
        playerView.layoutParams = pvLp
        // Telefono: niente etichetta né descrizione (resta compatto)
        nowLabel.visibility = if (isTv) View.VISIBLE else View.GONE
        nowDesc.visibility = if (isTv && nowDesc.text.isNotBlank()) View.VISIBLE else View.GONE
    }

    /** Titolo, artista e dati di ciò che sta suonando. */
    private fun updateNowInfo(c: MediaController, item: MediaItem) {
        val id = PlaybackService.videoIdOf(item.mediaId)
        val known = knownItems[id]
        val m = item.mediaMetadata
        nowTitle.text = m.title?.takeIf { it.isNotBlank() } ?: known?.title ?: ""
        nowArtist.text = m.artist?.takeIf { it.isNotBlank() } ?: known?.author ?: ""
        val dur = c.duration.takeIf { it > 0 }?.let { ms ->
            val t = ms / 1000
            if (t >= 3600) "%d:%02d:%02d".format(t / 3600, (t % 3600) / 60, t % 60) else "%d:%02d".format(t / 60, t % 60)
        }
        nowMeta.text = listOfNotNull(
            known?.views?.takeIf { it.isNotBlank() },
            known?.published?.takeIf { it.isNotBlank() },
            dur,
        ).joinToString(" • ")
        nowMeta.visibility = if (nowMeta.text.isNullOrBlank()) View.GONE else View.VISIBLE
        nowDesc.text = known?.description.orEmpty()
        nowDesc.visibility = if (isTv && !fullscreen && nowDesc.text.isNotBlank()) View.VISIBLE else View.GONE

        val next = if (c.hasNextMediaItem()) c.getMediaItemAt(c.nextMediaItemIndex).mediaMetadata else null
        val pos = if (c.mediaItemCount > 1) "Brano ${c.currentMediaItemIndex + 1} di ${c.mediaItemCount}" else null
        nowNext.text = listOfNotNull(pos, next?.title?.let { "Dopo: $it" + (next.artist?.let { a -> " — $a" } ?: "") })
            .joinToString("  •  ")
        nowNext.visibility = if (nowNext.text.isNullOrBlank()) View.GONE else View.VISIBLE
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        val nightNow = newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK
        super.onConfigurationChanged(newConfig)
        // Tema chiaro ↔ scuro (anche risparmio energetico): ricreo tutto, altrimenti restano
        // colori misti (testi chiari su sfondo chiaro). La musica continua nel servizio.
        if (!isTv && nightNow != appliedNightMode) {
            appliedNightMode = nightNow
            recreate()
            return
        }
        grid.spanCount = DeviceProfile.columns(this)
        applyPlayerSize()
    }

    /** Tasto MENU del telecomando (≡): opzioni dell'elemento selezionato, come la pressione lunga. */
    /**
     * Fire TV: dalla prima riga della lista, ↑ porta ai pulsanti della pagina (Riproduci tutto, Casuale…)
     * anche se stanno a destra del titolo; prima il fuoco finiva nella barra laterale.
     */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (isTv && event.action == android.view.KeyEvent.ACTION_DOWN && event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
            val f = currentFocus
            if (f != null && isInside(f, list)) {
                val nextUp = android.view.FocusFinder.getInstance().findNextFocus(window.decorView as android.view.ViewGroup, f, View.FOCUS_UP)
                val buttons = listOf(R.id.playAllBtn, R.id.shuffleBtn, R.id.headerBtn, R.id.headerBtn2)
                    .mapNotNull { findViewById<View>(it) }
                    .filter { it.visibility == View.VISIBLE && it.isShown }
                // se ↑ non resta dentro la lista e non arriva già su un pulsante della pagina, vai ai pulsanti
                if (buttons.isNotEmpty() && (nextUp == null || (!isInside(nextUp, list) && nextUp !in buttons))) {
                    val target = buttons.firstOrNull()
                    if (target != null) {
                        target.requestFocus()
                        return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun isInside(v: View, parent: View): Boolean {
        var p: android.view.ViewParent? = v.parent
        if (v === parent) return true
        while (p != null) {
            if (p === parent) return true
            p = p.parent
        }
        return false
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_MENU) {
            if (list.adapter !== adapter) {
                toolbar.showOverflowMenu()
                return true
            }
            val focused = list.focusedChild
            val pos = focused?.let { list.getChildAdapterPosition(it) } ?: RecyclerView.NO_POSITION
            val item = adapter.items.getOrNull(pos)
            if (item != null && focused != null) {
                onItemLongClick(item, focused)
                return true
            }
            toolbar.showOverflowMenu()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        adapter.refresh() // aggiorna i ❤ se cambiati altrove
        ServiceHealth.onLocalCrisis = { runOnUiThread { checkHealthAlert() } }
        lifecycleScope.launch {
            runCatching { ServiceHealth.refresh() }
            checkHealthAlert()
        }
    }

    override fun onPause() {
        super.onPause()
        ServiceHealth.onLocalCrisis = null
    }

    // ---------------- Salute del servizio ----------------

    private var healthDialog: AlertDialog? = null

    /** Mostra l'avviso se YouTube ha cambiato qualcosa (una volta per problema). */
    private fun checkHealthAlert() {
        if (isFinishing || healthDialog?.isShowing == true) return
        val a = ServiceHealth.alert() ?: return
        if (!ServiceHealth.shouldShow(a)) return
        healthDialog = AlertDialog.Builder(this)
            .setTitle(a.title)
            .setMessage(a.message)
            .setPositiveButton(if (isTv) "Invia rapporto" else "Copia rapporto") { _, _ ->
                copyHealthReport()
                ServiceHealth.acknowledge(a)
            }
            .setNeutralButton("Stato servizio") { _, _ -> showHealth() }
            .setNegativeButton("Ho capito") { _, _ -> ServiceHealth.acknowledge(a) }
            .show()
    }

    /** Telefono: copia il rapporto. Sempre: lo salva anche su GitHub in reports/ (su Fire TV è l'unico modo). */
    private fun copyHealthReport() {
        if (!isTv) {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Rapporto Tubetto", ServiceHealth.report()))
        }
        lifecycleScope.launch {
            val r = runCatching { ServiceHealth.uploadReport() }
            toast(
                r.fold(
                    { path -> if (isTv) "Rapporto inviato su GitHub: $path" else "Rapporto copiato e salvato su GitHub ($path)" },
                    { e -> if (isTv) "Invio non riuscito: ${e.message}" else "Rapporto copiato: incollalo nella chat con Claude" },
                )
            )
        }
    }

    private fun showHealth() {
        val dlg = AlertDialog.Builder(this)
            .setTitle("Stato servizio")
            .setMessage(ServiceHealth.summary())
            .setPositiveButton(if (isTv) "Invia rapporto" else "Copia rapporto") { _, _ -> copyHealthReport() }
            .setNeutralButton("Controlla ora", null)
            .setNegativeButton("Chiudi", null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            lifecycleScope.launch {
                val changed = runCatching { ServiceHealth.refresh(force = true) }.getOrDefault(false)
                dlg.setMessage(ServiceHealth.summary())
                toast(if (changed) "Configurazione client aggiornata" else "Stato aggiornato")
            }
        }
    }

    private fun setVideoEnabled(enabled: Boolean) {
        val c = controller ?: return
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !enabled)
            .build()
    }

    // ---------------- Player: grande solo per i video ----------------

    /** Pulsante casuale del mini player: pieno se attivo, sbiadito se spento. */
    private fun refreshShuffle() {
        val on = controller?.shuffleModeEnabled == true
        findViewById<ImageButton>(R.id.miniShuffle)?.let {
            it.alpha = if (on) 1f else 0.45f
            it.setColorFilter(if (on) ContextCompat.getColor(this, R.color.azure) else android.graphics.Color.GRAY)
        }
    }

    private fun updatePlayerUi() {
        refreshShuffle()
        val c = controller
        val item = c?.currentMediaItem
        val active = c != null && item != null &&
            c.playbackState != Player.STATE_IDLE && c.playbackState != Player.STATE_ENDED
        val isVideo = active && !isAudioId(item!!.mediaId) && !audioOnlyVideo
        // "Guarda il video" dal player: riparte dallo stesso punto del brano
        if (pendingSeekMs > 0 && c != null && c.playbackState == Player.STATE_READY) {
            c.seekTo(pendingSeekMs)
            pendingSeekMs = 0
        }
        fullPlayer?.update()

        if (waitingPlayback && c != null && (c.playbackState == Player.STATE_READY || c.playerError != null)) {
            waitingPlayback = false
            progress.visibility = View.GONE
        }

        // TV: il video si guarda solo a schermo intero; navigando resta il mini player in basso
        if (isTv) {
            if (isVideo && tvWantFullscreen && !fullscreen) {
                tvWantFullscreen = false
                setFullscreen(true)
            }
            if (!active && fullscreen) setFullscreen(false)
            // navigando, il video continua in piccolo nel mini player
            val wantMini = isVideo && !fullscreen
            if (wantMini && !tvMini) enterTvMini() else if (!wantMini && tvMini) exitTvMini()
        } else if (!isVideo && fullscreen && !inPip) {
            setFullscreen(false)
        }
        val showRow = if (isTv) active && fullscreen else isVideo
        if (videoMini && !isVideo) exitMiniVideo(show = false)
        nowRow.visibility = if (showRow && !videoMini) View.VISIBLE else View.GONE
        playerView.visibility = if (showRow) View.VISIBLE else View.GONE
        floatVideo?.visibility = if (videoMini && isVideo) View.VISIBLE else View.GONE
        // Telefono: il video sta sempre nel riquadro flottante (mai fisso in alto), tranne a schermo intero
        if (!isTv && !inPip && isVideo && !fullscreen && !videoMini && pipView != null) enterMiniVideo()
        if (showRow) updateNowInfo(c!!, item!!)
        if (!isTv) updatePipParams(isVideo, active && c!!.playWhenReady)
        // TV, player aperto senza video: copertina grande al posto del nero
        if (isTv && showRow && !isVideo) loadTvArtwork(item!!.mediaMetadata.artworkUri?.toString())

        // Niente screensaver né spegnimento schermo mentre scorre un video (su TV anche con la musica)
        val keepOn = active && c!!.playWhenReady && (isVideo || isTv)
        if (keepOn) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        miniBar.visibility = if (active && !fullscreen && (isTv || !isVideo)) View.VISIBLE else View.GONE

        if (active && (isTv || !isVideo)) {
            val m = item!!.mediaMetadata
            miniTitle.text = m.title ?: ""
            val artKey = item.mediaId + "|" + m.artworkUri
            if (artKey != miniArtKey) {
                miniArtKey = artKey
                NowArt.load(miniThumb, NowArt.candidates(item))
            }
            miniPlay.setImageResource(if (c!!.playWhenReady) R.drawable.ic_pause else R.drawable.ic_play)
            if (isTv) {
                val buffering = c.playbackState == Player.STATE_BUFFERING
                findViewById<View>(R.id.miniBuffer)?.visibility = if (buffering) View.VISIBLE else View.GONE
                findViewById<TextView>(R.id.miniLabel)?.text = when {
                    buffering -> "CARICAMENTO…"
                    !c.playWhenReady -> "IN PAUSA"
                    else -> "IN RIPRODUZIONE" + (if (isVideo) " · VIDEO" else " · SOLO AUDIO")
                }
                val nextIdx = c.nextMediaItemIndex
                val next = if (nextIdx != C.INDEX_UNSET) c.getMediaItemAt(nextIdx).mediaMetadata.title else null
                val from = playSource.takeIf { it.isNotBlank() && it != "Home" && !Radio.isRadio(item.mediaId) }?.let { "🎵 $it" }
                miniArtist.text = listOfNotNull(m.artist?.toString()?.takeIf { it.isNotBlank() }, from, next?.let { "Poi: $it" })
                    .joinToString("\n")
                findViewById<ImageButton>(R.id.miniVideo)?.apply {
                    visibility = if (item.mediaId.startsWith("a:")) View.GONE else View.VISIBLE
                    alpha = if (isVideo) 1f else 0.55f
                    contentDescription = if (isVideo) "Nascondi il video" else "Mostra il video"
                }
            } else {
                miniArtist.text = m.artist ?: ""
            }
        }
    }

    private fun enterTvMini() {
        val c = controller ?: return
        val mv = tvMiniView ?: return
        tvMini = true
        PlayerView.switchTargetView(c, playerView, mv)
        mv.visibility = View.VISIBLE
        miniThumb.visibility = View.GONE
    }

    private fun exitTvMini() {
        val c = controller
        tvMini = false
        if (c != null) PlayerView.switchTargetView(c, tvMiniView, playerView)
        tvMiniView?.visibility = View.GONE
        miniThumb.visibility = View.VISIBLE
    }

    private var miniArtKey: String? = null
    private var tvArtworkUri: String? = null

    private fun loadTvArtwork(uri: String?) {
        if (uri == null || uri == tvArtworkUri) return
        tvArtworkUri = uri
        val hd = uri.replace("/mqdefault.jpg", "/hq720.jpg").replace("/hqdefault.jpg", "/hq720.jpg")
        val req = coil.request.ImageRequest.Builder(this)
            .data(hd)
            .listener(onError = { _, _ ->
                coil.Coil.imageLoader(this).enqueue(
                    coil.request.ImageRequest.Builder(this).data(uri).target { d -> playerView.setDefaultArtwork(d) }.build()
                )
            })
            .target { d -> playerView.setDefaultArtwork(d) }
            .build()
        coil.Coil.imageLoader(this).enqueue(req)
    }

    // ---------------- Picture-in-picture di sistema (telefono) ----------------
    // Uscendo dall'app con un video in riproduzione, il video continua in una finestrella
    // sopra le altre app finché non la chiudi. Chiudendola, prosegue solo l'audio.

    private var inPip = false
    private var pipWasFullscreen = false
    private var pipKey = ""

    private val pipReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(ctx: android.content.Context, intent: Intent) {
            val c = controller ?: return
            when (intent.action) {
                PIP_PLAY -> if (c.isPlaying) c.pause() else c.play()
                PIP_NEXT -> c.seekToNextMediaItem()
                PIP_PREV -> c.seekToPreviousMediaItem()
                PIP_AUDIO -> {
                    // "Solo audio": chiude la finestrella e continua in background
                    audioOnlyVideo = true
                    setVideoEnabled(false)
                    moveTaskToBack(true)
                }
            }
        }
    }

    private fun pipAction(action: String, code: Int, icon: Int, title: String): android.app.RemoteAction {
        val pi = android.app.PendingIntent.getBroadcast(
            this, code, Intent(action).setPackage(packageName),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return android.app.RemoteAction(android.graphics.drawable.Icon.createWithResource(this, icon), title, title, pi)
    }

    private fun buildPipParams(isVideo: Boolean, playing: Boolean): android.app.PictureInPictureParams {
        val vs = controller?.videoSize
        val w = vs?.width ?: 0
        val h = vs?.height ?: 0
        // Android accetta rapporti tra 1:2,39 e 2,39:1
        val ratio = if (w > 0 && h > 0) {
            val r = w.toFloat() / h
            when {
                r > 2.39f -> android.util.Rational(239, 100)
                r < 1f / 2.39f -> android.util.Rational(100, 239)
                else -> android.util.Rational(w, h)
            }
        } else {
            android.util.Rational(16, 9)
        }
        val b = android.app.PictureInPictureParams.Builder()
            .setAspectRatio(ratio)
            .setActions(
                listOf(
                    pipAction(PIP_PREV, 1, R.drawable.ic_prev, "Precedente"),
                    if (playing) pipAction(PIP_PLAY, 2, R.drawable.ic_pause, "Pausa")
                    else pipAction(PIP_PLAY, 2, R.drawable.ic_play, "Riproduci"),
                    pipAction(PIP_NEXT, 3, R.drawable.ic_next, "Successivo"),
                ),
            )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+: entra da solo nel PiP quando torni alla Home con un video attivo
            b.setAutoEnterEnabled(isVideo)
            b.setSeamlessResizeEnabled(true)
        }
        return b.build()
    }

    private fun pipSupported(): Boolean =
        !isTv && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun updatePipParams(isVideo: Boolean, playing: Boolean) {
        if (!pipSupported()) return
        val vs = controller?.videoSize
        val key = "$isVideo|$playing|${vs?.width}x${vs?.height}"
        if (key == pipKey) return
        pipKey = key
        runCatching { setPictureInPictureParams(buildPipParams(isVideo, playing)) }
    }

    /** Elementi solo audio: brani "a:" e radio web. */
    private fun isAudioId(mediaId: String) = mediaId.startsWith("a:") || Radio.isRadio(mediaId)

    private fun videoPlayingNow(): Boolean {
        val c = controller ?: return false
        val item = c.currentMediaItem ?: return false
        return c.playbackState != Player.STATE_IDLE && c.playbackState != Player.STATE_ENDED &&
            !isAudioId(item.mediaId) && !audioOnlyVideo && c.playWhenReady
    }

    override fun onDestroy() {
        if (!isTv) runCatching { unregisterReceiver(pipReceiver) }
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Android 8–11: nessun ingresso automatico, lo avvio io
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && pipSupported() && videoPlayingNow()) {
            runCatching { enterPictureInPictureMode(buildPipParams(true, true)) }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            // Nella finestrella solo il video, senza barre né comandi
            fullPlayer?.close()
            if (videoMini) exitMiniVideo(show = true)
            pipWasFullscreen = fullscreen
            fullscreen = true
            applyPlayerSize()
            nowRow.visibility = View.VISIBLE
            playerView.visibility = View.VISIBLE
            listOf(R.id.toolbar, R.id.bottomNav, R.id.browseArea, R.id.miniBar, R.id.fsBar).forEach { findViewById<View>(it)?.visibility = View.GONE }
            findViewById<View>(R.id.content)?.setPadding(0, 0, 0, 0)
            findViewById<View>(R.id.root)?.setPadding(0, 0, 0, 0)
            playerView.useController = false
            playerView.hideController()
        } else {
            playerView.useController = true
            fullscreen = !pipWasFullscreen // così setFullscreen ripristina tutto
            setFullscreen(pipWasFullscreen)
            if (lifecycle.currentState == androidx.lifecycle.Lifecycle.State.CREATED) {
                // Finestrella chiusa con la ✕: il video si ferma, l'audio continua in background
                audioOnlyVideo = true
                setVideoEnabled(false)
            }
            updatePlayerUi()
        }
    }

    // ---------------- Video flottante (telefono) ----------------

    private fun setupMiniVideo() {
        val fv = floatVideo ?: return
        if (isTv) return
        // Scorrendo verso il basso con un video in riproduzione: il video diventa un riquadro flottante
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 12 && !videoMini && !fullscreen && nowRow.visibility == View.VISIBLE) enterMiniVideo()
            }
        })
        // Trascina per spostarlo, tocca per tornare al video grande
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startTx = 0f; var startTy = 0f; var dragging = false
        fv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startTx = v.translationX; startTy = v.translationY; dragging = false
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) dragging = true
                    if (dragging) {
                        val parent = v.parent as View
                        val lp = v.layoutParams as android.view.ViewGroup.MarginLayoutParams
                        // il riquadro parte in basso a destra: si può spostare a sinistra e in alto entro lo schermo
                        val minX = -(parent.width - v.width - lp.marginEnd - lp.marginStart).toFloat()
                        val minY = -(parent.height - v.height - lp.bottomMargin - lp.topMargin).toFloat()
                        v.translationX = (startTx + dx).coerceIn(minX, 0f)
                        v.translationY = (startTy + dy).coerceIn(minY, 0f)
                    }
                }
                // tocco = schermo intero (con i comandi); uscendo torna nel riquadro
                android.view.MotionEvent.ACTION_UP -> if (!dragging) setFullscreen(true)
            }
            true
        }
    }

    private fun enterMiniVideo() {
        val c = controller ?: return
        val pv = pipView ?: return
        videoMini = true
        PlayerView.switchTargetView(c, playerView, pv)
        nowRow.visibility = View.GONE
        floatVideo?.visibility = View.VISIBLE
    }

    /** @param show true = torna al video grande in alto; false = il video è finito o non c'è più */
    private fun exitMiniVideo(show: Boolean) {
        val c = controller
        videoMini = false
        if (c != null) PlayerView.switchTargetView(c, pipView, playerView)
        floatVideo?.visibility = View.GONE
        if (show) {
            nowRow.visibility = View.VISIBLE
            list.scrollToPosition(0)
        }
    }

    private fun setFullscreen(on: Boolean) {
        if (on && tvMini) exitTvMini()
        if (on && videoMini) exitMiniVideo(show = true)
        fullscreen = on
        findViewById<View>(R.id.fsBar)?.visibility = if (on && !isTv) View.VISIBLE else View.GONE
        val content = findViewById<View>(R.id.content)
        val root = findViewById<View>(R.id.root)
        val sidebar = findViewById<View>(R.id.sidebar)
        if (on) {
            content.setPadding(0, 0, 0, 0)
            root.setPadding(0, 0, 0, 0)
            root.fitsSystemWindows = false
            miniBar.visibility = View.GONE
            sidebar?.visibility = View.GONE
        } else {
            content.setPadding(contentPad[0], contentPad[1], contentPad[2], contentPad[3])
            sidebar?.visibility = View.VISIBLE
            if (!isTv) {
                root.fitsSystemWindows = true
                androidx.core.view.ViewCompat.requestApplyInsets(root)
            }
        }
        playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        val ctl = WindowCompat.getInsetsController(window, window.decorView)
        toolbar.visibility = if (on) View.GONE else View.VISIBLE
        findViewById<View>(R.id.bottomNav)?.visibility = if (on) View.GONE else View.VISIBLE
        browseArea.visibility = if (on) View.GONE else View.VISIBLE
        applyPlayerSize()
        if (isTv) {
            playerView.useController = on
            playerView.foreground = if (on) null else ContextCompat.getDrawable(this, R.drawable.player_focus)
            if (on) {
                playerView.requestFocus()
                playerView.showController()
            }
        }
        if (on) {
            ctl.hide(WindowInsetsCompat.Type.systemBars())
            if (device == DeviceProfile.Kind.PHONE) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ctl.show(WindowInsetsCompat.Type.systemBars())
            if (device == DeviceProfile.Kind.PHONE) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            if (isTv) nowRow.post {
                findViewById<View>(R.id.miniPlay)?.requestFocus()
                updatePlayerUi()
            }
            else playerView.post { updatePlayerUi() } // telefono: il video torna nel riquadro flottante
        }
        backCallback.isEnabled = on || pages.size > 1
        updatePlayerUi()
    }

    // ---------------- Menu ----------------

    private fun onMenu(id: Int) {
        when (id) {
            R.id.action_cast -> castMenu(null)
            R.id.action_app_settings -> showAppSettings()
            R.id.action_spotify -> askSpotifyLink()
            R.id.action_home -> loadHome()
            R.id.action_audio -> showAudioSettings()
            R.id.action_receiver -> startActivity(Intent(this, ReceiverActivity::class.java))
            R.id.action_tv -> castTarget?.let { showTvControls(it) } ?: toast("Nessuna TV collegata")
            R.id.action_share -> currentVideo()?.let { share(it.first, it.second) } ?: toast("Niente in riproduzione")
            R.id.action_update -> checkUpdate(silent = false)
            R.id.action_sync -> syncNow(manual = true)
            R.id.action_web -> showWebLink()
            R.id.action_health -> showHealth()
            R.id.action_settings -> showSettings()
            R.id.action_log -> showLog()
        }
    }

    /** Link della versione web per PC (GitHub Pages, repo pubblico "tubetto-web"). */
    private fun showWebLink() {
        val user = UpdatePrefs(this).user.ifBlank { "mariopinola10" }
        val url = "https://${user.lowercase()}.github.io/tubetto-web/"
        AlertDialog.Builder(this)
            .setTitle("Tubetto Web (PC)")
            .setMessage(
                "Apri questo link dal browser del PC:\n\n$url\n\n" +
                    "Usa la stessa libreria (preferiti, playlist, artisti, cronologia) tramite la sincronizzazione GitHub."
            )
            .setPositiveButton("Copia link") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Tubetto Web", url))
                toast("Link copiato")
            }
            .setNeutralButton("Condividi") { _, _ ->
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url), "Invia il link al PC"))
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun selectChip(id: Int) {
        if (chips.checkedChipId == id) {
            // già selezionato: ricarica
            when (id) {
                R.id.chipHome -> loadHome()
                R.id.chipLibAll -> showLibrary()
                R.id.chipMix -> showMyMix()
                R.id.chipCharts -> showCharts()
                R.id.chipArtists -> showArtists()
                R.id.chipFav -> showFavorites()
                R.id.chipMyPl -> showMyPlaylists()
                R.id.chipChannels -> showChannels()
                R.id.chipHistory -> showHistory()
            }
        } else {
            chips.check(id)
        }
    }

    private fun clearChips() {
        ignoreChipEvents = true
        chips.clearCheck()
        ignoreChipEvents = false
    }

    // ---------------- Pagine ----------------

    /** Home a scaffali come Spotify: Tutti / Musica / Video. */
    private fun loadHome() {
        progress.visibility = View.VISIBLE
        // Il filtro scelto si vede già dal chip in alto: niente titolo ripetuto (sulla TV neanche il saluto)
        val title = if (homeFilter == HomeFilter.ALL && !isTv) UserProfile.greeting() else ""
        sectionTitle.text = title
        lifecycleScope.launch {
            try {
                val shelves = when (homeFilter) {
                    HomeFilter.MUSIC -> musicShelves()
                    HomeFilter.VIDEO -> videoShelves()
                    HomeFilter.LIVE -> liveShelves()
                    HomeFilter.RADIO -> radioShelves()
                    HomeFilter.ALL -> coroutineScope {
                        val m = async { musicShelves() }
                        val v = async { videoShelves() }
                        val music = m.await()
                        val video = v.await()
                        music.take(2) + video.take(1) + music.drop(2) + video.drop(1)
                    }
                }.filter { it.items.isNotEmpty() }
                    // raccolte (playlist, artisti, canali): dalle ultime usate
                    .map { sh -> if (sh.items.isNotEmpty() && sh.items.all { it.kind != ItemKind.VIDEO } && !sh.items.any { it.id.startsWith(Charts.PREFIX) || it.id.startsWith("ytm:") }) sh.copy(items = Recents.sort(sh.items)) else sh }
                    // in cima: le tue playlist, poi visti/ascoltati di recente, poi il resto nell'ordine di sempre
                    .withIndex()
                    .sortedBy { (i, sh) ->
                        when (sh.title) {
                            "Le tue playlist" -> -3
                            "Visti di recente" -> -2
                            "Ascoltati di recente" -> -1
                            else -> i
                        }
                    }
                    .map { it.value }
                val subtitle = if (ListenHistory.all().isEmpty() && Library.artists().isEmpty())
                    "Ascolta qualcosa e segui i tuoi artisti: la home imparerà i tuoi gusti" else ""
                setPage(Page(emptyList(), title, subtitle, shelves = shelves), reset = true)
            } catch (e: Exception) {
                toast("Caricamento fallito: ${e.message}")
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    /** Scaffali musicali: artisti, playlist, per te, hit, nuove uscite, recenti, classifiche. */
    private suspend fun musicShelves(): List<Shelf> = coroutineScope {
        val forYou = async { runCatching { recommender.musicForYou().items }.getOrDefault(emptyList()) }
        val hits = async { runCatching { api.musicCharts() }.getOrDefault(emptyList()) }
        val news = async { runCatching { api.musicNewReleases() }.getOrDefault(emptyList()) }
        val pls = async { runCatching { recommender.playlistsForYou().items }.getOrDefault(emptyList()) }
        val artists = async { artistItems(12) }

        val recent = ListenHistory.all().filter { it.music }.take(15).map { it.toVideoItem() }
        val myPlaylists = buildList {
            add(VideoItem(id = ShelfAdapter.TILE_MIX, title = "Il mio mix", author = "Creato per te", duration = "", kind = ItemKind.PLAYLIST))
            add(VideoItem(id = ShelfAdapter.TILE_FAV, title = "Brani che ti piacciono", author = "${Library.favorites().size} brani", duration = "", kind = ItemKind.PLAYLIST))
            addAll(Library.playlistItems())
        }
        listOf(
            Shelf("I tuoi artisti", artists.await(), Shelf.Style.ROUND, queue = false),
            Shelf("Le tue playlist", myPlaylists, Shelf.Style.SQUARE, queue = false),
            Shelf("Per te", forYou.await().take(20)),
            Shelf("🔥 Hit del momento in Italia", hits.await().take(25)),
            Shelf("🆕 Nuove uscite", news.await().take(20)),
            Shelf("Ascoltati di recente", recent),
            Shelf("Playlist che potrebbero piacerti", pls.await().take(15), Shelf.Style.SQUARE, queue = false),
            Shelf("Classifiche ed eventi", Charts.items(), Shelf.Style.SQUARE, queue = false),
        )
    }

    /** Scaffali video: per te, dai canali seguiti, cronologia. */
    private suspend fun videoShelves(): List<Shelf> = coroutineScope {
        val forYou = async { runCatching { recommender.forYou().items }.getOrDefault(emptyList()) }
        val fromChannels = Library.channels().take(6).map { c ->
            async { runCatching { api.channelVideos(c.id).take(4) }.getOrDefault(emptyList()) }
        }
        val lists = fromChannels.awaitAll()
        val channelVideos = mutableListOf<VideoItem>()
        var i = 0
        while (lists.any { i < it.size }) {
            for (l in lists) l.getOrNull(i)?.let { channelVideos += it }
            i++
        }
        val history = ListenHistory.all().filter { !it.music }.take(15).map { it.toVideoItem() }
        listOf(
            Shelf("Video per te", forYou.await().take(20), Shelf.Style.WIDE, queue = false),
            Shelf("Dai canali che segui", channelVideos, Shelf.Style.WIDE, queue = false),
            Shelf("Canali che segui", Library.channels(), Shelf.Style.ROUND, queue = false),
            Shelf("Visti di recente", history, Shelf.Style.WIDE, queue = false),
        )
    }

    /** Dirette di YouTube in corso: canali che segui, musica, radio, notizie, generi del profilo. */
    private suspend fun liveShelves(): List<Shelf> = coroutineScope {
        fun live(q: String) = async { runCatching { api.searchLive(q).filter { it.kind == ItemKind.VIDEO }.take(16) }.getOrDefault(emptyList()) }
        val followed = Library.channels().take(6).map { c ->
            async {
                runCatching { api.searchLive(c.title).filter { it.channelId == c.id || it.author.equals(c.title, true) } }
                    .getOrDefault(emptyList())
            }
        }
        val music = live("music live radio 24/7")
        val italian = live("radio italiana in diretta")
        val news = live("notizie in diretta tg")
        val chill = live("lofi relax live")
        val world = live("webcam live 4k")
        val genres = UserProfile.genres.take(2).map { g -> g to live("$g live") }
        val mine = followed.awaitAll().flatten().distinctBy { it.id }
        buildList {
            add(Shelf("🔴 Dai canali che segui", mine, Shelf.Style.WIDE, queue = false))
            add(Shelf("Musica in diretta", music.await(), Shelf.Style.WIDE, queue = false))
            add(Shelf("Radio italiane", italian.await(), Shelf.Style.WIDE, queue = false))
            genres.forEach { (g, d) -> add(Shelf("$g in diretta", d.await(), Shelf.Style.WIDE, queue = false)) }
            add(Shelf("Notizie", news.await(), Shelf.Style.WIDE, queue = false))
            add(Shelf("Relax e lo-fi", chill.await(), Shelf.Style.WIDE, queue = false))
            add(Shelf("Webcam dal mondo", world.await(), Shelf.Style.WIDE, queue = false))
        }
    }

    /** Radio web: preferite, più ascoltate in Italia, Campania, generi. */
    private suspend fun radioShelves(): List<Shelf> = coroutineScope {
        fun rows(block: suspend () -> List<VideoItem>) = async { runCatching { block() }.getOrDefault(emptyList()) }
        val top = rows { Radio.top() }
        val campania = rows { Radio.byState("Campania") }
        val news = rows { Radio.byTag("news") }
        val dance = rows { Radio.byTag("dance") }
        val pop = rows { Radio.byTag("pop") }
        val jazz = rows { Radio.byTag("jazz", italianOnly = false) }
        val lofi = rows { Radio.byTag("lofi", italianOnly = false) }
        val searchTile = VideoItem(id = Radio.SEARCH_TILE, title = "🔍 Cerca una radio", author = "Per nome o città", duration = "", kind = ItemKind.PLAYLIST)
        listOf(
            Shelf("❤ Le tue radio", listOf(searchTile) + Radio.favorites(), Shelf.Style.SQUARE, queue = false),
            Shelf("Le più ascoltate in Italia", top.await(), Shelf.Style.SQUARE, queue = false),
            Shelf("Campania", campania.await(), Shelf.Style.SQUARE, queue = false),
            Shelf("Notizie e parlato", news.await(), Shelf.Style.SQUARE, queue = false),
            Shelf("Pop", pop.await(), Shelf.Style.SQUARE, queue = false),
            Shelf("Dance", dance.await(), Shelf.Style.SQUARE, queue = false),
            Shelf("Jazz dal mondo", jazz.await(), Shelf.Style.SQUARE, queue = false),
            Shelf("Lo-fi e relax", lofi.await(), Shelf.Style.SQUARE, queue = false),
        )
    }

    private fun playRadio(v: VideoItem) {
        val c = controller ?: return toast("Player non pronto")
        val url = v.description.ifBlank { Radio.urlOf(v.id).orEmpty() }
        if (url.isBlank()) return toast("Indirizzo della radio non disponibile")
        if (audioOnlyVideo) {
            audioOnlyVideo = false
            setVideoEnabled(true)
        }
        playSource = "Radio"
        NowArt.collectionCover = v.thumbnailUrl
        c.setMediaItem(
            MediaItem.Builder()
                .setMediaId(v.id)
                .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(url)).build())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(v.title)
                        .setArtist("📻 " + v.author.ifBlank { "Radio" })
                        .setArtworkUri(v.thumbnailUrl?.let { Uri.parse(it) })
                        .build()
                )
                .build()
        )
        c.prepare()
        c.play()
        toast("📻 ${v.title}")
        lifecycleScope.launch { Radio.countClick(v.id) }
    }

    private fun askRadioSearch() {
        val field = EditText(this).apply { hint = "Es. Radio Kiss Kiss, Napoli, RTL"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Cerca una radio")
            .setView(padded(field))
            .setPositiveButton("Cerca") { _, _ ->
                val q = field.text.toString().trim()
                if (q.isEmpty()) return@setPositiveButton
                load(title = "📻 Radio: $q", subtitle = "Tieni premuto una radio per aggiungerla alle preferite", reset = false) {
                    Radio.search(q) to emptyList<String>()
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun refreshAfterRadioChange() {
        val page = pages.lastOrNull()
        when {
            page?.shelves != null -> loadHome()
            page?.title == "La tua libreria" -> showLibrary()
        }
    }

    /** Artisti seguiti + più ascoltati, con la loro foto. */
    private suspend fun artistItems(limit: Int): List<VideoItem> = coroutineScope {
        val followed = Library.artists()
        val names = followed.map { it.id.lowercase() }.toSet()
        val top = ListenHistory.topArtists(limit, musicOnly = true).filter { it.lowercase() !in names }
            .map { VideoItem(id = it, title = it, author = "Artista", duration = "", kind = ItemKind.ARTIST) }
        (followed + top).take(limit).map { a ->
            async {
                val img = ArtistImages.cached(a.title) ?: ArtistImages.get(api, a.title)
                if (img != null) a.copy(thumbnailUrl = img) else a
            }
        }.awaitAll()
    }

    /** Tocco su un elemento di uno scaffale. */
    private fun onShelfClick(v: VideoItem, shelf: Shelf) {
        when {
            v.id == Radio.SEARCH_TILE -> askRadioSearch()
            Radio.isRadio(v.id) -> playRadio(v)
            v.id == ShelfAdapter.TILE_MIX -> showMyMix()
            v.id == ShelfAdapter.TILE_FAV -> showFavorites()
            v.kind == ItemKind.VIDEO && shelf.queue -> {
                val vids = shelf.items.filter { it.kind == ItemKind.VIDEO }
                playQueue(vids, vids.indexOf(v).coerceAtLeast(0))
            }
            v.kind == ItemKind.VIDEO -> playVideo(v)
            else -> onItemClick(v, 0)
        }
    }

    // ---------------- Schede: Home / Cerca / Libreria ----------------

    /** Evidenzia la voce attiva nella barra laterale TV. */
    private fun markNav(t: Tab) {
        findViewById<View>(R.id.navHome)?.isActivated = t == Tab.HOME
        findViewById<View>(R.id.navSearch)?.isActivated = t == Tab.SEARCH
        findViewById<View>(R.id.navLibrary)?.isActivated = t == Tab.LIBRARY
    }

    private fun showTab(t: Tab) {
        tab = t
        markNav(t)
        findViewById<View>(R.id.homeFilterRow)?.visibility = if (t == Tab.HOME) View.VISIBLE else View.GONE
        findViewById<View>(R.id.searchRow)?.visibility = if (t == Tab.SEARCH) View.VISIBLE else View.GONE
        findViewById<View>(R.id.libraryRow)?.visibility = if (t == Tab.LIBRARY) View.VISIBLE else View.GONE
        if (t != Tab.SEARCH) findViewById<View>(R.id.searchZero)?.visibility = View.GONE
        if (findViewById<View>(R.id.bottomNav) != null) {
            findViewById<View>(R.id.modeGroup).visibility = if (t == Tab.SEARCH) View.VISIBLE else View.GONE
        }
        when (t) {
            Tab.HOME -> loadHome()
            Tab.SEARCH -> {
                val last = lastSearchPage
                if (last != null) setPage(last, reset = true)
                else showSearchZero()
                query.requestFocus()
            }
            Tab.LIBRARY -> showLibrary()
        }
    }

    /** La tua libreria, come su Spotify: mix, preferiti, playlist, artisti, canali. */
    private fun showLibrary() {
        clearChips()
        ignoreChipEvents = true
        chips.check(R.id.chipLibAll)
        ignoreChipEvents = false
        val playlists = Recents.sort(Library.playlistItems())
        val artists = Recents.sort(Library.artists().map { a -> a.copy(thumbnailUrl = ArtistImages.cached(a.title) ?: a.thumbnailUrl) })
        val channels = Recents.sort(Library.channels())
        val items = buildList {
            add(header("In evidenza"))
            add(VideoItem(id = ShelfAdapter.TILE_MIX, title = "Il mio mix", author = "Creato per te: preferiti, artisti e brani simili", duration = "", kind = ItemKind.PLAYLIST))
            add(VideoItem(id = ShelfAdapter.TILE_FAV, title = "Brani che ti piacciono", author = "${Library.favorites().size} brani", duration = "", kind = ItemKind.PLAYLIST))
            if (playlists.isNotEmpty()) { add(header("Le tue playlist")); addAll(playlists) }
            if (artists.isNotEmpty()) { add(header("Artisti che segui")); addAll(artists) }
            if (channels.isNotEmpty()) { add(header("Canali che segui")); addAll(channels) }
            val radios = Radio.favorites()
            if (radios.isNotEmpty()) { add(header("📻 Le tue radio")); addAll(radios) }
        }
        setPage(Page(items, "La tua libreria", "Tocca ⋯ su un elemento per altre opzioni"), reset = true)
    }

    /** Mix automatico: preferiti, più ascoltati e i tuoi artisti, senza doppioni. */
    private fun showMyMix() {
        load(
            title = MIX_TITLE,
            subtitle = "Preferiti, canzoni dei tuoi artisti, brani simili e più ascoltati — senza doppioni",
            queue = true,
            playAll = true,
        ) {
            val m = recommender.myMix()
            if (m.items.isEmpty()) {
                toast("Aggiungi qualche preferito o segui un artista per comporre il mix")
            }
            m.items to m.basedOn
        }
    }

    private fun showCharts() {
        setPage(
            Page(Charts.items(), "Classifiche ed eventi", "Classifiche, nuove uscite e grandi eventi musicali: toccane uno"),
            reset = true,
        )
    }

    private fun showArtists() {
        val followed = Library.artists()
        load(
            title = "★ Artisti",
            subtitle = if (followed.isEmpty()) "Tieni premuto un brano → \"Segui artista\". Qui sotto quelli che ascolti di più"
            else "Artisti che segui e quelli che ascolti di più",
        ) {
            val names = followed.map { it.id.lowercase() }.toSet()
            val suggested = ListenHistory.topArtists(10, musicOnly = true)
                .filter { it.lowercase() !in names }
                .map { a ->
                    val thumb = ListenHistory.all().firstOrNull { it.author == a }?.thumb
                    VideoItem(id = a, title = a, author = "Ascoltato spesso", duration = "", thumbnailUrl = thumb, kind = ItemKind.ARTIST)
                }
            (followed + suggested) to emptyList<String>()
        }
    }

    /** Pagina artista: nuove uscite, ultimi video del canale, brani più ascoltati, playlist. */
    private fun openArtist(name: String, knownChannelId: String? = null) {
        lifecycleScope.launch {
            val channelId = knownChannelId ?: Library.artistChannel(name)
                ?: runCatching { api.searchArtists(name).firstOrNull { it.title.equals(name, true) }?.channelId }.getOrNull()
            load(title = name, subtitle = "Artista", queue = true, reset = false, artist = name, artistChannelId = channelId) {
                coroutineScope {
                    val recent = async { runCatching { api.searchRecent(name) }.getOrDefault(emptyList()) }
                    val channel = async {
                        if (channelId == null) emptyList()
                        else runCatching { api.channelVideos(channelId) }.getOrDefault(emptyList())
                    }
                    val songs = async { runCatching { api.searchMusic(name) }.getOrDefault(emptyList()) }
                    val pls = async { runCatching { api.searchPlaylists("$name playlist") }.getOrDefault(emptyList()) }
                    // Solo caricamenti dell'artista (canale ufficiale, VEVO, "- Topic") e solo canzoni:
                    // niente notizie o interviste di altri canali
                    val rec = recent.await().filter { v ->
                        val official = (channelId != null && v.channelId == channelId) ||
                            MetaCleaner.cleanArtist(v.author).equals(name, true) ||
                            v.author.contains(name, true)
                        official && MusicFilter.isSong(v)
                    }.take(8)
                    val recIds = rec.map { it.id }.toSet()
                    val items = buildList {
                        // Dalle più recenti: uscite dell'ultimo mese + caricamenti del canale ufficiale (già in ordine di data)
                        val ch = channel.await().filter { it.id !in recIds && MusicFilter.isSong(it) }.take(20)
                        val latest = (rec + ch).distinctBy { MetaCleaner.key(it.title, name) }
                        if (latest.isNotEmpty()) { add(header("Dalle più recenti")); addAll(latest) }
                        val sg = songs.await().take(20)
                        if (sg.isNotEmpty()) { add(header("Brani più ascoltati")); addAll(sg) }
                        val p = pls.await().take(6)
                        if (p.isNotEmpty()) { add(header("Playlist")); addAll(p) }
                    }
                    items to emptyList<String>()
                }
            }
        }
    }

    /** Musica: i tuoi brani, poi le hit del momento e le nuove uscite di YouTube Music. */
    private suspend fun musicHome(): Recommender.Suggestions = coroutineScope {
        val fy = async { runCatching { recommender.musicForYou() }.getOrNull() }
        val hits = async { runCatching { api.musicCharts() }.getOrDefault(emptyList()) }
        val news = async { runCatching { api.musicNewReleases() }.getOrDefault(emptyList()) }
        val f = fy.await()
        val seen = HashSet<String>()
        fun fresh(l: List<VideoItem>) = l.filter { seen.add(it.id) }
        val items = buildList {
            val mine = fresh(f?.items.orEmpty().take(25))
            if (mine.isNotEmpty()) { add(header("Per te")); addAll(mine) }
            val h = fresh(hits.await().take(20))
            if (h.isNotEmpty()) { add(header("🔥 Hit del momento in Italia")); addAll(h) }
            val n = fresh(news.await().take(20))
            if (n.isNotEmpty()) { add(header("🆕 Nuove uscite")); addAll(n) }
        }
        Recommender.Suggestions(items, f?.basedOn.orEmpty())
    }

    /** Artisti seguiti + artisti più ascoltati, con canale ufficiale quando trovato. */
    private suspend fun artistsForYou(): Recommender.Suggestions = coroutineScope {
        val followed = Library.artists()
        val names = followed.map { it.id.lowercase() }.toSet()
        val top = ListenHistory.topArtists(8, musicOnly = true).filter { it.lowercase() !in names }
        val found = top.map { a ->
            async { runCatching { api.searchArtists(a).firstOrNull { it.title.equals(a, true) } }.getOrNull() }
        }.awaitAll().filterNotNull()
        Recommender.Suggestions(followed + found, top)
    }

    private fun header(title: String) =
        VideoItem(id = "h:$title", title = title, author = "", duration = "", kind = ItemKind.HEADER)

    private fun showFavorites() {
        val fav = Recents.sort(Library.favorites())
        setPage(
            Page(
                fav, "❤ Preferiti",
                if (fav.isEmpty()) "Tieni premuto un brano o un video → \"Aggiungi ai preferiti\"" else "${fav.size} elementi",
                queue = true, playAll = fav.isNotEmpty(), favorites = true,
            ),
            reset = true,
        )
    }

    private fun showMyPlaylists() {
        val pls = Library.playlistItems()
        setPage(
            Page(
                pls, "Le mie playlist",
                if (pls.isEmpty()) "Tieni premuto un brano → \"Aggiungi a playlist…\" per crearne una" else "Tieni premuto una playlist per rinominarla o eliminarla",
            ),
            reset = true,
        )
        headerBtn.text = "＋ Nuova playlist"
        headerBtn.visibility = View.VISIBLE
    }

    private fun showChannels() {
        val ch = Library.channels()
        setPage(
            Page(
                ch, "Canali seguiti",
                if (ch.isEmpty()) "Apri un canale e premi \"☆ Segui\", oppure cerca in modalità Canali" else "${ch.size} canali",
            ),
            reset = true,
        )
    }

    private fun showHistory(reset: Boolean = true) {
        if (!reset) pages.removeLastOrNull()
        val h = ListenHistory.all().take(100).map { it.toVideoItem() }
        setPage(
            Page(h, "Cronologia", if (h.isEmpty()) "Niente qui: la cronologia è vuota" else "Ultimi ascolti e visioni • tieni premuto per rimuovere", queue = false),
            reset = reset,
        )
        headerBtn.text = "Cancella tutto"
        headerBtn.visibility = if (h.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setTitle("Cancellare tutta la cronologia?")
            .setMessage("Spariscono \"Visti di recente\" e \"Ascoltati di recente\"; anche i suggerimenti \"Per te\" ripartono da zero. Preferiti, playlist e artisti seguiti restano.")
            .setPositiveButton("Cancella") { _, _ ->
                ListenHistory.clear()
                toast("Cronologia cancellata")
                refreshAfterHistoryChange()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    /** Ridisegna la pagina corrente dopo aver tolto elementi dalla cronologia. */
    private fun refreshAfterHistoryChange() {
        val page = pages.lastOrNull()
        when {
            page?.title == "Cronologia" -> showHistory(reset = pages.size <= 1)
            page?.shelves != null -> loadHome()
        }
    }

    private fun openChannel(c: VideoItem) {
        load(title = c.title, subtitle = listOf(c.author, c.views).filter { it.isNotBlank() }.joinToString(" • "),
            reset = false, channel = c) {
            api.channelVideos(c.id) to emptyList<String>()
        }
    }

    private fun openLocalPlaylist(name: String) {
        val items = Library.playlist(name)
        setPage(
            Page(items, name, "${items.size} brani • la mia playlist", queue = true, playAll = items.isNotEmpty(), localPlaylist = name),
            reset = false,
        )
        headerBtn.text = "Rinomina"
        headerBtn.visibility = View.VISIBLE
    }

    // ---------------- Cerca: ricerche recenti ed "Esplora" ----------------

    private fun recentSearches(): List<String> {
        val raw = getSharedPreferences("ui", MODE_PRIVATE).getString("recent_searches", "[]") ?: "[]"
        return runCatching {
            val a = org.json.JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        }.getOrDefault(emptyList())
    }

    private fun saveRecent(list: List<String>) {
        getSharedPreferences("ui", MODE_PRIVATE).edit()
            .putString("recent_searches", org.json.JSONArray(list.take(12)).toString()).apply()
    }

    private fun addRecent(q: String) {
        saveRecent(listOf(q) + recentSearches().filterNot { it.equals(q, ignoreCase = true) })
    }

    /** Chip delle ricerche recenti: tocco = cerca di nuovo, tocco lungo = rimuovi. */
    private fun renderRecent() {
        val box = findViewById<View>(R.id.searchZero) ?: return
        val group = findViewById<ChipGroup>(R.id.recentChips)
        group.removeAllViews()
        val recent = recentSearches()
        recent.forEach { q ->
            group.addView(Chip(this).apply {
                text = q
                chipIcon = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_aa_recent)
                isChipIconVisible = true
                setChipIconTintResource(R.color.azure)
                setOnClickListener {
                    query.setText(q)
                    query.setSelection(q.length)
                    search()
                }
                setOnLongClickListener {
                    saveRecent(recentSearches().filterNot { it == q })
                    renderRecent()
                    toast("Rimossa: $q")
                    true
                }
            })
        }
        box.visibility = if (recent.isNotEmpty() && tab == Tab.SEARCH && query.text.isNullOrBlank()) View.VISIBLE else View.GONE
    }

    /** Cerca con il campo vuoto: ricerche recenti in alto e generi/classifiche da esplorare. */
    private fun showSearchZero() {
        lastSearchPage = null
        setPage(
            Page(emptyList(), "", "", shelves = listOf(Shelf("Esplora", Charts.items(), Shelf.Style.SQUARE, queue = false))),
            reset = true,
        )
        renderRecent()
    }

    private fun search() {
        val q = query.text.toString().trim()
        if (q.isEmpty()) return
        addRecent(q)
        findViewById<View>(R.id.searchZero)?.visibility = View.GONE
        clearChips()
        val label = when (mode) {
            Mode.VIDEO -> "Video"
            Mode.MUSIC -> "Brani"
            Mode.PLAYLIST -> "Playlist"
            Mode.ARTIST -> "Artisti"
            Mode.CHANNEL -> "Canali"
            Mode.RADIO -> "📻 Radio"
        }
        findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNav)?.let { nav ->
            if (tab != Tab.SEARCH) {
                tab = Tab.SEARCH
                nav.menu.findItem(R.id.nav_search)?.isChecked = true
                findViewById<View>(R.id.homeFilterRow)?.visibility = View.GONE
                findViewById<View>(R.id.libraryRow)?.visibility = View.GONE
                findViewById<View>(R.id.searchRow)?.visibility = View.VISIBLE
                findViewById<View>(R.id.modeGroup).visibility = View.VISIBLE
            }
        }
        // Fire TV: ricerca avviata da altrove (es. voce) → scheda Cerca
        if (findViewById<View>(R.id.bottomNav) == null && tab != Tab.SEARCH) {
            tab = Tab.SEARCH
            markNav(Tab.SEARCH)
            findViewById<View>(R.id.homeFilterRow)?.visibility = View.GONE
            findViewById<View>(R.id.libraryRow)?.visibility = View.GONE
            findViewById<View>(R.id.searchRow)?.visibility = View.VISIBLE
        }
        load(title = "$label: $q", queue = mode == Mode.MUSIC) {
            when (mode) {
                Mode.VIDEO -> api.search(q)
                Mode.MUSIC -> api.searchMusic(q)
                Mode.PLAYLIST -> api.searchPlaylists("$q playlist")
                Mode.ARTIST -> api.searchArtists(q)
                Mode.CHANNEL -> api.searchChannels(q)
                Mode.RADIO -> Radio.search(q)
            } to emptyList<String>()
        }
    }

    private fun load(
        title: String,
        subtitle: String = "",
        queue: Boolean = false,
        playAll: Boolean = false,
        reset: Boolean = true,
        channel: VideoItem? = null,
        artist: String? = null,
        artistChannelId: String? = null,
        subtitleFrom: ((List<String>) -> String)? = null,
        block: suspend () -> Pair<List<VideoItem>, List<String>>,
    ) {
        progress.visibility = View.VISIBLE
        sectionTitle.text = title
        lifecycleScope.launch {
            try {
                val (items, basedOn) = block()
                val sub = subtitleFrom?.invoke(basedOn) ?: subtitle
                setPage(
                    Page(items, title, sub, queue, playAll || (queue && items.isNotEmpty() && !reset), channel = channel, artist = artist, artistChannelId = artistChannelId),
                    reset,
                )
                if (items.isEmpty()) toast("Nessun risultato")
            } catch (e: Exception) {
                toast("Caricamento fallito: ${e.message}")
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private fun setPage(page: Page, reset: Boolean) {
        if (page.title.contains(": ") && page.shelves == null && reset) lastSearchPage = page
        if (reset) pages.clear()
        pages.addLast(page)
        showPage(page)
    }

    private fun showPage(page: Page) {
        page.items.forEach { if (it.kind == ItemKind.VIDEO) knownItems[it.id] = it }
        page.shelves?.forEach { sh -> sh.items.forEach { if (it.kind == ItemKind.VIDEO) knownItems[it.id] = it } }
        if (page.shelves != null) {
            if (list.adapter !== shelfAdapter) {
                list.layoutManager = linear
                list.adapter = shelfAdapter
            }
            shelfAdapter.submit(page.shelves)
        } else {
            if (list.adapter !== adapter) {
                list.layoutManager = grid
                list.adapter = adapter
            }
            adapter.hideAuthor = page.channel != null
            adapter.showDescription = page.title.startsWith("Video:")
            adapter.submit(page.items)
        }
        list.scrollToPosition(0)
        if (isTv && !fullscreen && page.items.isNotEmpty()) list.post { list.getChildAt(0)?.requestFocus() }
        sectionTitle.text = page.title
        sectionTitle.visibility = if (page.title.isBlank()) View.GONE else View.VISIBLE
        sectionSubtitle.text = page.subtitle
        sectionSubtitle.visibility = if (page.subtitle.isBlank()) View.GONE else View.VISIBLE
        // "Riproduci tutto" e "Casuale" su ogni lista con almeno 2 brani (preferiti, mix, playlist, ricerche, artisti…)
        val playable = page.shelves == null && page.items.count { it.kind == ItemKind.VIDEO } >= 2
        val showPlay = page.playAll || playable
        playAllBtn.visibility = if (showPlay) View.VISIBLE else View.GONE
        findViewById<View>(R.id.shuffleBtn).visibility = if (showPlay) View.VISIBLE else View.GONE

        headerBtn.visibility = View.GONE
        headerBtn2.visibility = View.GONE
        page.channel?.let { c ->
            headerBtn.text = if (Library.isFollowed(c.id)) "★ Canale seguito" else "☆ Segui canale"
            headerBtn.visibility = View.VISIBLE
            headerBtn2.text = if (Library.isArtistFollowed(c.title)) "★ Artista seguito" else "☆ Segui come artista"
            headerBtn2.visibility = View.VISIBLE
        }
        page.artist?.let { a ->
            headerBtn.text = if (Library.isArtistFollowed(a)) "★ Artista seguito" else "☆ Segui artista"
            headerBtn.visibility = View.VISIBLE
            page.artistChannelId?.let { id ->
                headerBtn2.text = if (Library.isFollowed(id)) "★ Canale seguito" else "☆ Segui canale"
                headerBtn2.visibility = View.VISIBLE
            }
        }
        if (page.localPlaylist != null) {
            headerBtn.text = "Rinomina"
            headerBtn.visibility = View.VISIBLE
        }
        if (page.title == MIX_TITLE && page.items.isNotEmpty()) {
            headerBtn.text = "Salva come playlist"
            headerBtn.visibility = View.VISIBLE
            headerBtn2.text = "↻ Rigenera"
            headerBtn2.visibility = View.VISIBLE
        }
        if (page.title == "Le mie playlist") {
            headerBtn.text = "＋ Nuova playlist"
            headerBtn.visibility = View.VISIBLE
        }
        backCallback.isEnabled = fullscreen || pages.size > 1
    }

    private fun onHeaderButton() {
        val page = pages.lastOrNull() ?: return
        when {
            page.channel != null -> followChannel(page.channel)
            page.artist != null -> followArtist(page.artist, page.items.firstOrNull { it.kind == ItemKind.VIDEO }?.thumbnail, page.artistChannelId)
            page.localPlaylist != null -> renamePlaylistDialog(page.localPlaylist)
            page.title == "Le mie playlist" -> newPlaylistDialog(null)
            page.title == "Cronologia" -> {
                confirmClearHistory()
                return
            }
            page.title == MIX_TITLE -> {
                val name = "Il mio mix " + java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.ITALY).format(java.util.Date())
                Library.createPlaylist(name)
                page.items.filter { it.kind == ItemKind.VIDEO }.forEach { Library.addToPlaylist(name, it) }
                toast("Salvata in \"Le mie playlist\" come \"$name\"")
                return
            }
        }
        showPage(page)
    }

    /** Secondo pulsante: canale ↔ artista, oppure rigenera il mix. */
    private fun onHeaderButton2() {
        val page = pages.lastOrNull() ?: return
        if (page.title == MIX_TITLE) {
            showMyMix()
            return
        }
        when {
            page.channel != null -> followArtist(page.channel.title, page.channel.thumbnailUrl, page.channel.id)
            page.artist != null && page.artistChannelId != null -> followChannel(
                VideoItem(
                    id = page.artistChannelId, title = page.artist, author = "Canale", duration = "",
                    thumbnailUrl = page.items.firstOrNull { it.kind == ItemKind.VIDEO }?.thumbnail, kind = ItemKind.CHANNEL,
                )
            )
        }
        showPage(page)
    }

    private fun followChannel(c: VideoItem) {
        val now = Library.toggleChannel(c)
        toast(if (now) "Canale \"${c.title}\" tra i seguiti" else "Canale \"${c.title}\" rimosso dai seguiti")
    }

    private fun followArtist(name: String, thumb: String?, channelId: String?) {
        val now = Library.toggleArtist(name, thumb, channelId)
        toast(if (now) "Ora segui l'artista $name" else "Non segui più l'artista $name")
    }

    /** Raccolta aperta per ultima (playlist, artista, canale): sale in cima quando ne ascolti qualcosa. */
    private var lastCollectionKey: String? = null

    private fun onItemClick(v: VideoItem, position: Int) {
        val page = pages.lastOrNull()
        if (v.id == Radio.SEARCH_TILE) return askRadioSearch()
        if (Radio.isRadio(v.id)) return playRadio(v)
        if (v.kind == ItemKind.PLAYLIST || v.kind == ItemKind.ARTIST || v.kind == ItemKind.CHANNEL) {
            lastCollectionKey = Recents.keyOf(v)
            Recents.touch(v)
            // copertina di riserva per il player se un brano non ne ha una sua
            NowArt.collectionCover = Collage.urlsFor(v)?.firstOrNull() ?: v.thumbnailUrl?.ifBlank { null } ?: v.thumbnail.takeIf { v.kind == ItemKind.VIDEO }
        }
        when {
            v.id == ShelfAdapter.TILE_MIX -> showMyMix()
            v.id == ShelfAdapter.TILE_FAV -> showFavorites()
            v.kind == ItemKind.HEADER -> Unit
            v.kind == ItemKind.ARTIST -> openArtist(v.title, v.channelId)
            v.id == Charts.YTM_HITS -> load(
                title = v.title, subtitle = v.author, queue = true, playAll = true, reset = false,
            ) { api.musicCharts() to emptyList<String>() }
            v.id == Charts.YTM_NEW -> load(
                title = v.title, subtitle = v.author, queue = true, playAll = true, reset = false,
            ) { api.musicNewReleases(40) to emptyList<String>() }
            v.kind == ItemKind.PLAYLIST && v.id.startsWith(Charts.PREFIX) -> load(
                title = v.title,
                subtitle = "${v.author} • playlist aggiornate",
                reset = false,
            ) { api.searchPlaylists(v.id.removePrefix(Charts.PREFIX)) to emptyList<String>() }
            v.kind == ItemKind.CHANNEL -> openChannel(v)
            v.kind == ItemKind.PLAYLIST && v.id.startsWith(Library.LOCAL_PREFIX) ->
                openLocalPlaylist(v.id.removePrefix(Library.LOCAL_PREFIX))
            v.kind == ItemKind.PLAYLIST -> load(
                title = v.title,
                subtitle = listOf(v.author, v.duration).filter { it.isNotBlank() }.joinToString(" • "),
                queue = true, playAll = true, reset = false,
            ) { api.playlist(v.id) to emptyList<String>() }
            page?.queue == true -> {
                val videos = page.items.filter { it.kind == ItemKind.VIDEO }
                playQueue(videos, videos.indexOf(v).coerceAtLeast(0))
            }
            else -> playVideo(v)
        }
    }

    private fun onItemLongClick(v: VideoItem, anchor: View) {
        if (v.id == Radio.SEARCH_TILE) return
        if (Radio.isRadio(v.id)) {
            PopupMenu(this, anchor).apply {
                menu.add(0, 1, 0, "▶ Ascolta")
                menu.add(0, 2, 1, if (Radio.isFavorite(v.id)) "Rimuovi dalle radio preferite" else "❤ Aggiungi alle radio preferite")
                setOnMenuItemClickListener {
                    when (it.itemId) {
                        1 -> playRadio(v)
                        2 -> {
                            val now = Radio.toggleFavorite(v)
                            toast(if (now) "Aggiunta alle radio preferite" else "Tolta dalle radio preferite")
                            refreshAfterRadioChange()
                        }
                    }
                    true
                }
            }.show()
            return
        }
        val page = pages.lastOrNull()
        if (v.kind == ItemKind.HEADER || v.id.startsWith(Charts.PREFIX) || v.id.startsWith("ytm:") || v.id.startsWith("tile:")) return
        PopupMenu(this, anchor).apply {
            when (v.kind) {
                ItemKind.HEADER -> Unit
                ItemKind.ARTIST -> {
                    menu.add(0, 40, 0, if (Library.isArtistFollowed(v.id)) "Smetti di seguire l'artista" else "☆ Segui artista")
                    if (v.channelId != null) {
                        menu.add(0, 44, 1, if (Library.isFollowed(v.channelId)) "Smetti di seguire il canale" else "☆ Segui anche il canale")
                        menu.add(0, 45, 2, "Apri canale")
                    }
                    menu.add(0, 41, 3, "Apri artista")
                    if (!isTv) menu.add(0, 52, 4, "↗ Condividi link")
                }
                ItemKind.CHANNEL -> {
                    menu.add(0, 20, 0, if (Library.isFollowed(v.id)) "Smetti di seguire il canale" else "☆ Segui canale")
                    menu.add(0, 46, 1, if (Library.isArtistFollowed(v.title)) "Smetti di seguire l'artista" else "☆ Segui come artista")
                    menu.add(0, 21, 2, "Apri canale")
                    menu.add(0, 47, 3, "Apri come artista")
                    if (!isTv) menu.add(0, 52, 4, "↗ Condividi link")
                }
                ItemKind.PLAYLIST -> if (v.id.startsWith(Library.LOCAL_PREFIX)) {
                    menu.add(0, 30, 0, "Rinomina")
                    menu.add(0, 31, 1, "Elimina playlist")
                    menu.add(0, 50, 2, "Condividi i link dei brani")
                } else {
                    menu.add(0, 32, 0, "▶ Riproduci tutta")
                    if (!isTv) menu.add(0, 52, 1, "↗ Condividi link YouTube")
                    if (!isTv) menu.add(0, 51, 2, "Copia link")
                }
                ItemKind.VIDEO -> {
                    menu.add(0, 5, 0, "Guarda il video")
                    menu.add(0, 3, 1, "Ascolta solo audio")
                    menu.add(0, 2, 2, "Aggiungi alla coda")
                    menu.add(0, 6, 3, if (Library.isFavorite(v.id)) "Rimuovi dai preferiti" else "❤ Aggiungi ai preferiti")
                    menu.add(0, 7, 4, "＋ Aggiungi o togli da playlist…")
                    if (page?.localPlaylist != null) menu.add(0, 8, 5, "Rimuovi da questa playlist")
                    if (ListenHistory.contains(v.id)) {
                        menu.add(0, 60, 10, "🗑 Rimuovi da \"Visti di recente\"")
                        menu.add(0, 61, 11, "🗑 Cancella tutta la cronologia…")
                    }
                    if (v.channelId != null) menu.add(0, 9, 6, "Vai al canale")
                    if (v.author.isNotBlank()) {
                        menu.add(0, 42, 6, "Apri artista: ${v.author}")
                        menu.add(
                            0, 43, 6,
                            if (Library.isArtistFollowed(v.author)) "Smetti di seguire ${v.author}" else "☆ Segui artista: ${v.author}",
                        )
                    }
                    if (!isTv) {
                        menu.add(0, 1, 7, "Trasmetti su TV")
                        menu.add(0, 4, 8, "↗ Condividi link YouTube")
                        menu.add(0, 51, 9, "Copia link")
                    }
                }
            }
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> castMenu(v)
                    2 -> controller?.addMediaItem(queueItem(v))?.also { toast("Aggiunto alla coda") }
                    3 -> playQueue(listOf(v), 0)
                    60 -> {
                        ListenHistory.remove(v.id)
                        toast("Rimosso dalla cronologia")
                        refreshAfterHistoryChange()
                    }
                    61 -> confirmClearHistory()
                    4 -> share(v.id, v.title)
                    50 -> shareText(
                        v.title,
                        Library.playlist(v.id.removePrefix(Library.LOCAL_PREFIX)).joinToString("\n") { "${it.title} — ${it.author}\nhttps://youtu.be/${it.id}" }
                            .let { "🎵 ${v.title}\n\n$it" },
                    )
                    51 -> copyLink(linkFor(v))
                    52 -> shareText(v.title, "${v.title}\n${linkFor(v)}")
                    5 -> playVideo(v)
                    6 -> {
                        val now = Library.toggleFavorite(v)
                        toast(if (now) "Aggiunto ai preferiti" else "Rimosso dai preferiti")
                        if (page?.favorites == true) showFavoritesInPlace() else adapter.refresh()
                    }
                    7 -> addToPlaylistDialog(v)
                    8 -> page?.localPlaylist?.let { name ->
                        Library.removeFromPlaylist(name, v.id)
                        pages.removeLast()
                        openLocalPlaylist(name)
                    }
                    9 -> v.channelId?.let { id -> openChannel(VideoItem(id = id, title = v.author, author = "", duration = "", kind = ItemKind.CHANNEL)) }
                    20 -> {
                        followChannel(v)
                        if (page?.title == "Canali seguiti") showChannels() else adapter.refresh()
                    }
                    21 -> openChannel(v)
                    40 -> {
                        followArtist(v.id, v.thumbnailUrl, v.channelId)
                        adapter.refresh()
                    }
                    41 -> openArtist(v.title, v.channelId)
                    44 -> v.channelId?.let { id ->
                        followChannel(VideoItem(id = id, title = v.title, author = "Canale", duration = "", thumbnailUrl = v.thumbnailUrl, kind = ItemKind.CHANNEL))
                    }
                    45 -> v.channelId?.let { id ->
                        openChannel(VideoItem(id = id, title = v.title, author = "", duration = "", thumbnailUrl = v.thumbnailUrl, kind = ItemKind.CHANNEL))
                    }
                    46 -> followArtist(v.title, v.thumbnailUrl, v.id)
                    47 -> openArtist(v.title, v.id)
                    42 -> openArtist(v.author, null)
                    43 -> followArtist(v.author, v.thumbnail, null)
                    30 -> renamePlaylistDialog(v.id.removePrefix(Library.LOCAL_PREFIX))
                    31 -> {
                        val name = v.id.removePrefix(Library.LOCAL_PREFIX)
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Eliminare \"$name\"?")
                            .setPositiveButton("Elimina") { _, _ -> Library.deletePlaylist(name); showMyPlaylists() }
                            .setNegativeButton("Annulla", null)
                            .show()
                    }
                    32 -> lifecycleScope.launch {
                        runCatching { api.playlist(v.id) }.onSuccess { playQueue(it, 0) }
                            .onFailure { e -> toast("Playlist non disponibile: ${e.message}") }
                    }
                }
                true
            }
            show()
        }
    }

    private fun showFavoritesInPlace() {
        pages.removeLastOrNull()
        showFavorites()
    }

    // ---------------- Playlist personali ----------------

    /**
     * Playlist del brano: ogni playlist con la spunta se lo contiene già.
     * Spunta = aggiungi, togli la spunta = rimuovi. "＋ Nuova playlist" lo mette in una playlist nuova.
     */
    private fun addToPlaylistDialog(v: VideoItem) {
        val names = Recents.sort(Library.playlistItems()).map { it.title }
        if (names.isEmpty()) {
            newPlaylistDialog(v)
            return
        }
        val checked = BooleanArray(names.size) { i -> Library.playlist(names[i]).any { it.id == v.id } }
        val before = checked.copyOf()
        AlertDialog.Builder(this)
            .setTitle("Playlist di «${v.title.take(40)}»")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, on -> checked[i] = on }
            .setPositiveButton("Salva") { _, _ ->
                val added = mutableListOf<String>()
                val removed = mutableListOf<String>()
                names.forEachIndexed { i, name ->
                    if (checked[i] && !before[i]) { Library.addToPlaylist(name, v); added += name }
                    if (!checked[i] && before[i]) { Library.removeFromPlaylist(name, v.id); removed += name }
                }
                val msg = listOfNotNull(
                    added.takeIf { it.isNotEmpty() }?.let { "Aggiunto a ${it.joinToString(", ") { n -> "«$n»" }}" },
                    removed.takeIf { it.isNotEmpty() }?.let { "Tolto da ${it.joinToString(", ") { n -> "«$n»" }}" },
                ).joinToString(" • ")
                if (msg.isNotEmpty()) toast(msg)
                // se sei dentro una di queste playlist, la lista si aggiorna subito
                pages.lastOrNull()?.localPlaylist?.let { cur ->
                    if (cur in added || cur in removed) { pages.removeLastOrNull(); openLocalPlaylist(cur) }
                }
            }
            .setNeutralButton("＋ Nuova playlist") { _, _ -> newPlaylistDialog(v) }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun newPlaylistDialog(first: VideoItem?) {
        val input = EditText(this).apply { hint = "Nome playlist"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Nuova playlist")
            .setView(padded(input))
            .setPositiveButton("Crea") { _, _ ->
                val name = input.text.toString().trim()
                if (!Library.createPlaylist(name)) {
                    toast("Nome vuoto o già esistente")
                    return@setPositiveButton
                }
                first?.let { Library.addToPlaylist(name, it) }
                toast("Playlist \"$name\" creata")
                if (pages.lastOrNull()?.title == "Le mie playlist") showMyPlaylists()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun renamePlaylistDialog(old: String) {
        val input = EditText(this).apply { setText(old); setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Rinomina playlist")
            .setView(padded(input))
            .setPositiveButton("Salva") { _, _ ->
                val name = input.text.toString().trim()
                if (Library.renamePlaylist(old, name)) {
                    toast("Rinominata")
                    if (pages.lastOrNull()?.localPlaylist == old) {
                        pages.removeLast()
                        openLocalPlaylist(name)
                    } else {
                        showMyPlaylists()
                    }
                } else {
                    toast("Nome vuoto o già esistente")
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun padded(v: View) = LinearLayout(this).apply {
        setPadding(dp(20), dp(8), dp(20), 0)
        addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    // ---------------- Riproduzione ----------------

    private fun metadataOf(v: VideoItem) = MediaMetadata.Builder()
        .setTitle(v.title)
        .setArtist(v.author)
        .setArtworkUri(Uri.parse(v.thumbnail))
        .build()

    /** Pagina del canale/artista di ciò che sta suonando (dal riquadro TV o dal player del telefono). */
    private fun openCurrentChannel() {
        val m = controller?.currentMediaItem?.mediaMetadata
        val name = MetaCleaner.cleanArtist(m?.artist?.toString().orEmpty()).trim()
        if (name.isBlank()) {
            toast("Canale non disponibile per questo elemento")
            return
        }
        if (fullscreen) setFullscreen(false)
        fullPlayer?.close()
        openArtist(name)
    }

    private fun shareCurrent() {
        currentVideo()?.let { share(it.first, it.second) } ?: toast("Niente in riproduzione")
    }

    // ---------------- Impostazioni, profilo, primo avvio ----------------

    private var infoTaps = 0

    /** Un solo punto per impostazioni, versione e (per l'amministratore) GitHub, sincronizzazione, log. */
    private fun showAppSettings() {
        val up = UpdatePrefs(this)
        val opts = mutableListOf<Pair<String, () -> Unit>>()
        opts += "👤  Profilo e gusti musicali" + (UserProfile.name.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: "") to { showOnboarding(edit = true) }
        opts += "🎚  Audio e qualità" to { showAudioSettings() }
        if (isTv) opts += "📺  Musica su TV: " + (if (UserProfile.tvMusicAudioOnly) "solo audio (video a richiesta)" else "con video") to {
            UserProfile.tvMusicAudioOnly = !UserProfile.tvMusicAudioOnly
            toast(if (UserProfile.tvMusicAudioOnly) "La musica partirà in solo audio" else "La musica partirà con il video")
        }
        if (!up.isAdmin) opts += "⇅  Sincronizza i tuoi dispositivi" + (if (OwnSync(this).isConfigured) " (attiva)" else "") to { showOwnSync() }
        opts += "🔐  Accesso YouTube" + (if (Account.isLoggedIn) " (collegato)" else " (facoltativo)") to { showAccount() }
        opts += "🗑  Cronologia: vedi o cancella" to { showHistory() }
        val sb = SponsorBlock.enabled(this)
        opts += "⏭  Salta parti parlate e sponsor (SponsorBlock): " + (if (sb) "attivo" else "spento") to {
            SponsorBlock.setEnabled(this, !sb)
            toast(if (!sb) "SponsorBlock attivo: dal prossimo brano" else "SponsorBlock spento")
        }
        opts += "⟳  Aggiornamenti — versione ${BuildConfig.VERSION_NAME}" to { checkUpdate(silent = false) }
        if (up.isAdmin) {
            if (up.token.isNotBlank()) opts += "🚀  Pubblica versione per tutti" to { showPublish() }
            opts += "⇅  Sincronizza dispositivi" to { syncNow(manual = true) }
            opts += "🩺  Stato servizio" to { showHealth() }
            opts += "💻  Tubetto Web (PC)" to { showWebLink() }
            opts += "🔑  GitHub (repo, token, sincronizzazione)" to { showSettings() }
            opts += "🧾  Log diagnostica" to { showLog() }
            if (up.adminUnlocked && up.token.isBlank()) opts += "🔒  Disattiva modalità amministratore" to {
                up.adminUnlocked = false
                toast("Modalità amministratore disattivata")
            }
        }
        opts += "ℹ  Tubetto ${BuildConfig.VERSION_NAME}" to {
            if (!up.isAdmin) {
                infoTaps++
                if (infoTaps >= 7) {
                    infoTaps = 0
                    up.adminUnlocked = true
                    toast("Modalità amministratore attivata")
                    showAppSettings()
                } else if (infoTaps >= 4) {
                    toast("Ancora ${7 - infoTaps} tocchi")
                    showAppSettings()
                }
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Impostazioni")
            .setItems(opts.map { it.first }.toTypedArray()) { _, i -> opts[i].second() }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShared(intent)
    }

    // ---------------- Importa da Spotify / link condivisi ----------------

    /** Testo condiviso da un'altra app: link Spotify → importa; link YouTube → riproduce. */
    private fun handleShared(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        i.action = null // non rielaborarlo ruotando lo schermo
        SpotifyImport.findLink(text)?.let { (kind, id) ->
            importSpotify(kind, id)
            return
        }
        val yt = Regex("""(?:youtu\.be/|[?&]v=|/shorts/)([A-Za-z0-9_-]{11})""").find(text)?.groupValues?.get(1)
        if (yt != null) {
            playVideo(VideoItem(id = yt, title = text.lineSequence().firstOrNull { !it.contains("http") }.orEmpty().ifBlank { "Video condiviso" }, author = "", duration = ""))
            return
        }
        toast("Nessun link Spotify o YouTube nel testo condiviso")
    }

    private fun askSpotifyLink() {
        val clip = runCatching {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString()
        }.getOrNull()
        val field = EditText(this).apply {
            hint = "https://open.spotify.com/playlist/…"
            setSingleLine()
            if (SpotifyImport.findLink(clip) != null) setText(clip)
        }
        val dp = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), 0)
            addView(TextView(this@MainActivity).apply {
                text = "Incolla il link di una playlist, album o brano Spotify (pubblici). " +
                    "Più comodo: in Spotify tocca Condividi → Tubetto.\n\n" +
                    "Discover Weekly e i mix di Spotify: prima copiali in una tua playlist (Aggiungi a playlist)."
                textSize = 14f
            })
            addView(field)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Importa da Spotify")
            .setView(box)
            .setPositiveButton("Importa", null)
            .setNegativeButton("Annulla", null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val link = SpotifyImport.findLink(field.text.toString())
            if (link == null) {
                field.error = "Non è un link Spotify"
                return@setOnClickListener
            }
            dlg.dismiss()
            importSpotify(link.first, link.second)
        }
    }

    private fun importSpotify(kind: String, id: String) {
        val dp = resources.displayMetrics.density
        val status = TextView(this).apply {
            text = "Leggo la playlist da Spotify…"
            textSize = 15f
            setPadding((24 * dp).toInt(), (16 * dp).toInt(), (24 * dp).toInt(), (8 * dp).toInt())
        }
        val bar = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            setPadding((24 * dp).toInt(), 0, (24 * dp).toInt(), 0)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status)
            addView(bar)
        }
        var cancelled = false
        val dlg = AlertDialog.Builder(this)
            .setTitle("Importa da Spotify")
            .setView(box)
            .setNegativeButton("Annulla") { _, _ -> cancelled = true }
            .setCancelable(false)
            .show()
        lifecycleScope.launch {
            try {
                val src = SpotifyImport.fetch(kind, id)
                if (cancelled) return@launch
                status.text = "«${src.name}»: cerco ${src.tracks.size} brani su YouTube…"
                bar.isIndeterminate = false
                bar.max = src.tracks.size
                val (found, missing) = SpotifyImport.matchAll(api, src.tracks) { done, total ->
                    bar.progress = done
                    status.text = "«${src.name}»: $done di $total brani"
                }
                if (cancelled) return@launch
                dlg.dismiss()
                if (found.isEmpty()) {
                    toast("Nessun brano trovato su YouTube")
                    return@launch
                }
                // nome libero: "Nome (Spotify)", "Nome (Spotify) 2"…
                val base = "${src.name} (Spotify)"
                var name = base
                var n = 2
                while (!Library.createPlaylist(name)) name = "$base ${n++}"
                found.forEach { Library.addToPlaylist(name, it) }
                val msg = StringBuilder("Trovati ${found.size} brani su ${src.tracks.size}.")
                if (missing.isNotEmpty()) {
                    msg.append("\n\nNon trovati:\n")
                    missing.take(15).forEach { msg.append("• ${it.title} — ${it.artist}\n") }
                    if (missing.size > 15) msg.append("… e altri ${missing.size - 15}")
                }
                if (src.tracks.size >= 100) msg.append("\n\nSpotify mostra al massimo circa 100 brani per playlist.")
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("✔ Playlist «$name» creata")
                    .setMessage(msg.toString())
                    .setPositiveButton("Riproduci") { _, _ -> playQueue(found, 0) }
                    .setNeutralButton("Apri") { _, _ -> openLocalPlaylist(name) }
                    .setNegativeButton("Chiudi", null)
                    .show()
            } catch (e: Exception) {
                dlg.dismiss()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Importazione non riuscita")
                    .setMessage(e.message ?: e.javaClass.simpleName)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    /** Chiede il nome del profilo (telefono). "Più tardi" lo richiede al prossimo avvio. */
    private fun askProfileName() {
        if (isFinishing) return
        val dp = resources.displayMetrics.density
        val field = EditText(this).apply {
            hint = "Il tuo nome"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), 0)
            addView(TextView(this@MainActivity).apply {
                text = "Come ti chiami? Lo usiamo per il tuo profilo e per salutarti nella Home."
                textSize = 14f
            })
            addView(field)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Crea il tuo profilo 👤")
            .setView(box)
            .setPositiveButton("Salva", null)
            .setNegativeButton("Più tardi", null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val n = field.text.toString().trim()
            if (n.isEmpty()) {
                field.error = "Scrivi un nome"
                return@setOnClickListener
            }
            UserProfile.name = n
            dlg.dismiss()
            toast("Ciao $n!")
            if (pages.size <= 1) loadHome()
        }
        field.requestFocus()
        dlg.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    // ---------------- Accesso con account YouTube (facoltativo) ----------------

    private val loginLauncher = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && Account.isLoggedIn) {
            if (SyncManager.enabled()) askAccountSyncCode(afterLogin = true)
            else toast("✔ Accesso eseguito: verrà usato solo quando senza account un video non parte")
        }
    }

    private fun showAccount() {
        if (Account.isLoggedIn) {
            val syncTxt = if (Account.syncCode.isNotBlank()) "inviato cifrato agli altri tuoi dispositivi" else "solo su questo dispositivo"
            AlertDialog.Builder(this)
                .setTitle("🔐 Accesso YouTube attivo")
                .setMessage(
                    "L'account viene usato solo quando un video non parte senza (limiti di età, controllo \"non sei un bot\", contenuti riservati).\n\n" +
                        "Accesso: $syncTxt."
                )
                .setItems(arrayOf("🔑  Codice per gli altri dispositivi", "↻  Rifai l'accesso", "⎋  Esci dall'account")) { _, i ->
                    when (i) {
                        0 -> askAccountSyncCode(afterLogin = false)
                        1 -> loginLauncher.launch(Intent(this, LoginActivity::class.java))
                        2 -> {
                            Account.logout()
                            SyncManager.schedule(3_000)
                            toast("Uscito dall'account" + if (Account.syncCode.isNotBlank()) ": anche gli altri dispositivi si scollegano" else "")
                        }
                    }
                }
                .setNegativeButton("Chiudi", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("🔐 Accesso YouTube (facoltativo)")
            .setMessage(
                "Tubetto funziona senza account. Accedere serve solo per i video che YouTube mostra agli utenti collegati: " +
                    "con limiti di età (l'account deve avere l'età verificata), riservati agli iscritti/Premium " +
                    "(se il tuo account li ha) o quando YouTube chiede \"conferma di non essere un bot\".\n\n" +
                    "Da sapere prima:\n" +
                    "• Usa preferibilmente un ACCOUNT SECONDARIO, non quello principale con mail e foto: " +
                    "usare l'account in un'app non ufficiale è contro le regole di YouTube e Google potrebbe chiedere verifiche o bloccarlo.\n" +
                    "• Si apre la pagina di accesso di Google: password e codici restano tra te e Google, l'app conserva solo la sessione su questo dispositivo.\n" +
                    "• Google ogni tanto chiude le sessioni: basterà rifare l'accesso.\n" +
                    "• Fire TV: fai l'accesso dal telefono e, con la sincronizzazione attiva, sulla TV inserisci lo stesso codice segreto (Impostazioni → Accesso YouTube → Ricevi dal telefono).\n" +
                    "• Puoi uscire quando vuoi da qui."
            )
            .setPositiveButton("Accedi") { _, _ -> loginLauncher.launch(Intent(this, LoginActivity::class.java)) }
            .setNeutralButton("Ricevi dal telefono") { _, _ -> receiveAccountFromSync() }
            .setNegativeButton("Non ora", null)
            .show()
    }

    /** Codice segreto con cui l'accesso viaggia cifrato verso gli altri dispositivi (uguale ovunque). */
    private fun askAccountSyncCode(afterLogin: Boolean) {
        val field = EditText(this).apply {
            hint = "Almeno 6 caratteri"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Account.syncCode)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val dp = resources.displayMetrics.density
            setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), 0)
            addView(TextView(this@MainActivity).apply {
                text = "Scegli un codice: l'accesso viene cifrato con questo codice prima di andare nella sincronizzazione. " +
                    "Sugli altri dispositivi inserisci lo stesso codice. Chi non lo conosce non può usare il tuo accesso."
            })
            addView(field)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(if (afterLogin) "✔ Accesso eseguito — portarlo sugli altri dispositivi?" else "Codice per gli altri dispositivi")
            .setView(box)
            .setPositiveButton("Salva e invia", null)
            .setNegativeButton(if (afterLogin) "Solo qui" else "Annulla", null)
            .setNeutralButton("Non inviare più") { _, _ ->
                Account.syncCode = ""
                toast("L'accesso resta solo su questo dispositivo")
            }
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val code = field.text.toString().trim()
            if (code.length < 6) {
                field.error = "Almeno 6 caratteri"
                return@setOnClickListener
            }
            Account.syncCode = code
            dlg.dismiss()
            if (!SyncManager.enabled()) {
                toast("Attiva prima la sincronizzazione: Impostazioni → Sincronizza")
                return@setOnClickListener
            }
            lifecycleScope.launch {
                runCatching { SyncManager.sync() }
                toast("Accesso inviato cifrato: sugli altri dispositivi usa \"Ricevi dal telefono\" con lo stesso codice")
            }
        }
    }

    /** Fire TV (o altro dispositivo): riceve l'accesso fatto sul telefono tramite la sincronizzazione. */
    private fun receiveAccountFromSync() {
        if (!SyncManager.enabled()) {
            AlertDialog.Builder(this)
                .setTitle("Serve la sincronizzazione")
                .setMessage("Per ricevere l'accesso dal telefono, attiva prima la sincronizzazione con gli stessi dati del telefono (Impostazioni → Sincronizza).")
                .setPositiveButton("Apri") { _, _ -> if (UpdatePrefs(this).isAdmin) showSettings() else showOwnSync() }
                .setNegativeButton("Chiudi", null)
                .show()
            return
        }
        val field = EditText(this).apply {
            hint = "Codice scelto sul telefono"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Ricevi l'accesso dal telefono")
            .setView(padded(field))
            .setPositiveButton("Ricevi") { _, _ ->
                Account.syncCode = field.text.toString().trim()
                toast("Sincronizzo…")
                lifecycleScope.launch {
                    runCatching { SyncManager.sync() }
                    when {
                        Account.isLoggedIn -> toast("✔ Accesso ricevuto")
                        SyncManager.accountCodeMissing -> toast("Codice sbagliato: deve essere uguale a quello del telefono")
                        else -> toast("Nessun accesso trovato: fai prima l'accesso sul telefono e scegli \"Salva e invia\"")
                    }
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    // ---------------- Sincronizzazione personale (per tutti, senza l'amministratore) ----------------

    private fun showOwnSync() {
        val own = OwnSync(this)
        if (own.isConfigured) {
            val opts = arrayOf("⇅  Sincronizza ora", "✎  Cambia repository o token", "✕  Scollega questo dispositivo")
            AlertDialog.Builder(this)
                .setTitle("Sincronizzazione attiva")
                .setMessage("Repository: ${own.repo}\nUltimo stato: ${SyncManager.lastStatus}")
                .setItems(opts) { _, i ->
                    when (i) {
                        0 -> syncNow(manual = true)
                        1 -> ownSyncForm()
                        2 -> {
                            own.clear()
                            toast("Sincronizzazione scollegata: i dati restano su questo dispositivo")
                        }
                    }
                }
                .setNegativeButton("Chiudi", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Sincronizza i tuoi dispositivi")
            .setMessage(
                "Preferiti, playlist, artisti, canali e cronologia uguali su telefono, tablet e Fire TV. " +
                    "I dati vanno in un tuo spazio privato e gratuito su GitHub: nessun altro li vede.\n\n" +
                    "Una volta sola (dal telefono o dal PC):\n" +
                    "1. Crea un account gratuito su github.com\n" +
                    "2. Crea un repository PRIVATO, es. \"tubetto-sync\", spuntando \"Add a README\" (github.com/new)\n" +
                    "3. Crea un token: Settings → Developer settings → Fine-grained tokens → Generate new token. " +
                    "In \"Repository access\" scegli solo tubetto-sync; in \"Permissions\" → Contents: Read and write. Scadenza: la più lunga.\n" +
                    "4. Copia il token (inizia con github_pat_)\n\n" +
                    "Poi, su OGNI dispositivo: Impostazioni → Sincronizza i tuoi dispositivi → Inserisci i dati, " +
                    "con lo stesso repository e lo stesso token.\n\n" +
                    "Il token è come una password: non darlo a nessuno."
            )
            .setPositiveButton("Inserisci i dati") { _, _ -> ownSyncForm() }
            .setNeutralButton("Apri GitHub") { _, _ ->
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/new"))) }
                    .onFailure { toast("Apri github.com/new dal telefono o dal PC") }
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun ownSyncForm() {
        val own = OwnSync(this)
        val dp = resources.displayMetrics.density
        val repoField = EditText(this).apply {
            hint = "utente/tubetto-sync"
            setSingleLine()
            setText(own.repo)
        }
        val tokenField = EditText(this).apply {
            hint = "github_pat_…"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(own.token)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), 0)
            addView(TextView(this@MainActivity).apply { text = "Repository (utente/nome o link)" })
            addView(repoField)
            addView(TextView(this@MainActivity).apply { text = "Token"; setPadding(0, (10 * dp).toInt(), 0, 0) })
            addView(tokenField)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Dati di sincronizzazione")
            .setView(box)
            .setPositiveButton("Collega", null)
            .setNegativeButton("Annulla", null)
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val token = tokenField.text.toString().trim()
            if (!own.setRepo(repoField.text.toString())) {
                repoField.error = "Scrivi utente/nome del repository"
                return@setOnClickListener
            }
            if (token.length < 20) {
                tokenField.error = "Incolla il token completo"
                return@setOnClickListener
            }
            own.token = token
            UpdatePrefs(this).syncEnabled = true
            dlg.dismiss()
            toast("Collego e sincronizzo…")
            lifecycleScope.launch {
                val ok = runCatching { SyncManager.sync() }.isSuccess
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(if (ok) "✔ Sincronizzazione attiva" else "Collegamento non riuscito")
                    .setMessage(
                        if (ok) "Fatto. Ripeti gli stessi dati sugli altri tuoi dispositivi: da ora si aggiornano da soli.\n\n${SyncManager.lastStatus}"
                        else "${SyncManager.lastStatus}\n\nControlla che il repository esista, che il token sia di quel repository e che abbia \"Contents: Read and write\"."
                    )
                    .setPositiveButton("OK", null)
                    .show()
                if (ok) refreshLibraryPage()
            }
        }
    }

    /** Amministratore: decide quando la versione compilata arriva a tutti gli utenti. */
    private fun showPublish() {
        toast("Controllo le versioni…")
        lifecycleScope.launch {
            val st = runCatching { Publisher(this@MainActivity).state() }.getOrElse {
                AlertDialog.Builder(this@MainActivity).setTitle("Pubblica versione")
                    .setMessage(it.message ?: "Errore").setPositiveButton("OK", null).show()
                return@launch
            }
            val priv = st.privateVersion
            val pub = st.publicVersion ?: "nessuna"
            val info = "Ultima compilata (solo tu): ${priv ?: "nessuna"}\n" +
                "Pubblicata per tutti: $pub\n" +
                "Su questo telefono: ${BuildConfig.VERSION_NAME}"
            val b = AlertDialog.Builder(this@MainActivity).setTitle("Pubblica versione")
            when {
                st.running -> b.setMessage("$info\n\n⏳ Pubblicazione in corso, riprova tra un minuto.")
                    .setPositiveButton("OK", null).show()
                priv == null -> b.setMessage("$info\n\nNessuna release nel repo privato.").setPositiveButton("OK", null).show()
                st.publicVersion != null && !Updater.isNewer(priv, st.publicVersion) ->
                    b.setMessage("$info\n\n✔ Gli utenti hanno già l'ultima versione.").setPositiveButton("OK", null).show()
                else -> {
                    val dp = resources.displayMetrics.density
                    val box = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), 0)
                    }
                    box.addView(TextView(this@MainActivity).apply {
                        text = "$info\n\nPubblicare la $priv? Gli utenti riceveranno l'avviso di aggiornamento."
                        textSize = 15f
                    })
                    val notes = EditText(this@MainActivity).apply {
                        hint = "Novità (facoltativo)"
                        setText(st.privateNotes.takeIf { !it.startsWith("Build automatica") }.orEmpty())
                        minLines = 2
                    }
                    box.addView(notes)
                    b.setView(box)
                        .setPositiveButton("Pubblica $priv") { _, _ ->
                            lifecycleScope.launch {
                                runCatching { Publisher(this@MainActivity).publish(priv, notes.text.toString().trim()) }
                                    .onSuccess { toast("🚀 Pubblicazione avviata: tra 1-2 minuti la $priv è disponibile per tutti") }
                                    .onFailure { e ->
                                        AlertDialog.Builder(this@MainActivity).setTitle("Pubblicazione non riuscita")
                                            .setMessage(e.message ?: "Errore").setPositiveButton("OK", null).show()
                                    }
                            }
                        }
                        .setNegativeButton("Non ora", null)
                        .show()
                }
            }
        }
    }

    /**
     * Primo avvio (o "Profilo e gusti musicali"): nome, almeno 3 artisti, generi.
     * Gli artisti diventano "Artisti che segui"; i generi riempiono "Per te" finché non c'è cronologia.
     */
    private fun showOnboarding(edit: Boolean = false) {
        val dp = resources.displayMetrics.density
        val pad = (20 * dp).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, (8 * dp).toInt(), pad, 0)
        }
        fun label(t: String, top: Int = 18) = TextView(this).apply {
            text = t
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (top * dp).toInt(), 0, (6 * dp).toInt())
        }
        box.addView(TextView(this).apply {
            text = "Scegli qualche artista e genere: la Home partirà già con la musica che ti piace. Puoi cambiarli quando vuoi in Impostazioni."
            textSize = 14f
        })
        box.addView(label(if (isTv) "Come ti chiami? (facoltativo)" else "Come ti chiami?"))
        val nameField = EditText(this).apply {
            setText(UserProfile.name)
            hint = "Nome"
            setSingleLine()
        }
        box.addView(nameField)

        box.addView(label("Artisti: scegline almeno 3"))
        val followed = Library.artists().map { it.id }
        val artistGroup = ChipGroup(this)
        fun addArtistChip(name: String, checked: Boolean) {
            artistGroup.addView(Chip(this).apply {
                text = name
                isCheckable = true
                isChecked = checked
            })
        }
        (UserProfile.ARTISTS + followed.filter { f -> UserProfile.ARTISTS.none { it.equals(f, true) } })
            .forEach { addArtistChip(it, followed.any { f -> f.equals(it, true) }) }
        box.addView(artistGroup)
        val other = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val otherField = EditText(this).apply {
            hint = "Altro artista…"
            setSingleLine()
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val addBtn = Button(this).apply { text = "Aggiungi" }
        addBtn.setOnClickListener {
            val n = otherField.text.toString().trim()
            if (n.isNotEmpty()) {
                addArtistChip(n, true)
                otherField.setText("")
            }
        }
        other.addView(otherField)
        other.addView(addBtn)
        box.addView(other)

        box.addView(label("Generi"))
        val genreGroup = ChipGroup(this)
        val myGenres = UserProfile.genres
        UserProfile.GENRES.forEach { (g, _) ->
            genreGroup.addView(Chip(this).apply {
                text = g
                isCheckable = true
                isChecked = g in myGenres
            })
        }
        box.addView(genreGroup)

        val dlg = AlertDialog.Builder(this)
            .setTitle(if (edit) "Profilo e gusti musicali" else "Benvenuto in Tubetto 🎧")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton(if (edit) "Salva" else "Inizia", null)
            .setNegativeButton(if (edit) "Annulla" else "Salta") { _, _ ->
                if (!edit) {
                    UserProfile.onboardingDone = true
                    if (!isTv && UserProfile.name.isBlank()) list.post { askProfileName() }
                }
            }
            .setCancelable(edit)
            .show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val artists = (0 until artistGroup.childCount).map { artistGroup.getChildAt(it) as Chip }.filter { it.isChecked }.map { it.text.toString() }
            if (!isTv && nameField.text.isNullOrBlank()) {
                nameField.error = "Scrivi un nome"
                nameField.requestFocus()
                return@setOnClickListener
            }
            if (artists.size < 3) {
                toast("Scegli almeno 3 artisti")
                return@setOnClickListener
            }
            val genres = (0 until genreGroup.childCount).map { genreGroup.getChildAt(it) as Chip }.filter { it.isChecked }.map { it.text.toString() }
            UserProfile.name = nameField.text.toString()
            UserProfile.genres = genres
            UserProfile.onboardingDone = true
            // segue i nuovi artisti; in modifica, smette di seguire quelli tolti dalla lista proposta
            artists.filter { a -> !Library.isArtistFollowed(a) }.forEach { Library.toggleArtist(it, null, null) }
            if (edit) followed.filter { f -> artists.none { it.equals(f, true) } }.forEach { f ->
                if (Library.isArtistFollowed(f)) Library.toggleArtist(f, null, null)
            }
            dlg.dismiss()
            toast("Fatto! Preparo la tua Home…")
            lifecycleScope.launch {
                artists.forEach { a -> runCatching { ArtistImages.get(api, a) } }
                loadHome()
            }
        }
    }

    /** Chiude il video e continua solo con l'audio (stesso brano, stesso punto). */
    private fun audioOnly() {
        audioOnlyVideo = true
        setVideoEnabled(false)
        if (videoMini) exitMiniVideo(show = false)
        if (fullscreen) setFullscreen(false)
        updatePlayerUi()
        if (!isTv) toast("🎧 Solo audio: tocca il mini player per tornare al video")
    }

    private fun backToVideo() {
        audioOnlyVideo = false
        setVideoEnabled(true)
        updatePlayerUi()
    }

    /** Video completo: risolto subito nel service, player grande. */
    private fun playVideo(v: VideoItem) {
        val c = controller ?: return toast("Player non pronto")
        if (audioOnlyVideo) {
            audioOnlyVideo = false
            setVideoEnabled(true)
        }
        if (isTv) tvWantFullscreen = true
        playSource = sourceName()
        c.stop() // interrompe subito il brano/video attuale
        showLoading()
        c.setMediaItem(MediaItem.Builder().setMediaId(v.id).setMediaMetadata(metadataOf(v)).build())
        c.prepare()
        c.play()
    }

    /** Elemento solo audio risolto al momento (code lunghe, background e auto). */
    private fun queueItem(v: VideoItem) =
        MediaItem.Builder().setMediaId((if (isTv) "v:" else "a:") + v.id).setMediaMetadata(metadataOf(v)).build()

    private fun playQueue(list: List<VideoItem>, start: Int) {
        lastCollectionKey?.let { Recents.touch(it) }
        pages.lastOrNull()?.localPlaylist?.let { Recents.touch(Recents.playlistKey(Library.LOCAL_PREFIX + it)) }
        pages.lastOrNull()?.artist?.let { Recents.touch(Recents.artistKey(it)) }
        val c = controller ?: return toast("Player non pronto")
        if (list.isEmpty()) return
        playSource = sourceName()
        if (isTv) {
            // Fire TV: le code musicali partono in solo audio (il video si apre dal mini player)
            audioOnlyVideo = UserProfile.tvMusicAudioOnly
            setVideoEnabled(!audioOnlyVideo)
        }
        c.stop()
        showLoading()
        c.setMediaItems(list.map(::queueItem), start.coerceIn(0, list.lastIndex), C.TIME_UNSET)
        c.prepare()
        c.play()
    }

    private fun sourceName(): String {
        val t = pages.lastOrNull()?.title.orEmpty()
        return if (t == UserProfile.greeting() || t.startsWith("Ciao ")) "Home" else t
    }

    private fun showLoading() {
        waitingPlayback = true
        progress.visibility = View.VISIBLE
    }

    private fun currentVideo(): Pair<String, String>? {
        val item = controller?.currentMediaItem ?: return null
        return PlaybackService.videoIdOf(item.mediaId) to item.mediaMetadata.title?.toString().orEmpty()
    }

    /** Ciò che sta suonando, come elemento di lista (per menu e playlist). */
    private fun currentItemAsVideo(): VideoItem? {
        val item = controller?.currentMediaItem ?: return null
        val m = item.mediaMetadata
        val id = PlaybackService.videoIdOf(item.mediaId)
        return VideoItem(
            id = id,
            title = m.title?.toString().orEmpty(),
            author = m.artist?.toString().orEmpty(),
            duration = "",
            thumbnailUrl = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
        )
    }

    /** Link YouTube di un elemento: video, playlist, canale/artista. */
    private fun linkFor(v: VideoItem): String = when (v.kind) {
        ItemKind.PLAYLIST -> "https://www.youtube.com/playlist?list=${v.id}"
        ItemKind.CHANNEL -> "https://www.youtube.com/channel/${v.id}"
        ItemKind.ARTIST -> v.channelId?.let { "https://www.youtube.com/channel/$it" }
            ?: "https://music.youtube.com/search?q=${Uri.encode(v.title)}"
        else -> "https://youtu.be/${v.id}"
    }

    private fun copyLink(link: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Link", link))
        toast("Link copiato")
    }

    private fun shareText(subject: String, text: String) {
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, subject)
                    .putExtra(Intent.EXTRA_TEXT, text),
                "Condividi",
            )
        )
    }

    private fun share(videoId: String, title: String) {
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, title)
                    .putExtra(Intent.EXTRA_TEXT, "$title\nhttps://youtu.be/$videoId"),
                "Condividi"
            )
        )
    }

    // ---------------- DLNA / Fire TV ----------------

    private fun castMenu(v: VideoItem?) {
        val target = v?.let { it.id to it.title } ?: currentVideo() ?: return toast("Scegli prima un video")
        val searching = AlertDialog.Builder(this)
            .setTitle("Cerco TV e dispositivi DLNA…")
            .setView(ProgressBar(this).apply { setPadding(dp(20), dp(20), dp(20), dp(20)) })
            .setNegativeButton("Annulla", null)
            .show()
        lifecycleScope.launch {
            val found = runCatching { Dlna.discover(this@MainActivity) }.getOrElse {
                Diagnostics.log("DLNA discover: ${it.message}"); emptyList()
            }
            if (!searching.isShowing) return@launch
            searching.dismiss()
            if (found.isEmpty()) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Nessun dispositivo trovato")
                    .setMessage(
                        "Telefono e TV devono essere sulla stessa rete Wi-Fi.\n\n" +
                            "Fire TV: installa Tubetto anche sulla Fire TV e aprilo: diventa un ricevitore " +
                            "(compare con ★, qualità piena). In alternativa Kodi con UPnP attivo.\n\n" +
                            "In alternativa usa \"Condividi link\"."
                    )
                    .setPositiveButton("OK", null)
                    .show()
                return@launch
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Trasmetti su…")
                .setItems(found.map { it.name }.toTypedArray()) { _, i -> cast(found[i], target.first, target.second) }
                .setNegativeButton("Annulla", null)
                .show()
        }
    }

    private fun cast(r: Renderer, videoId: String, title: String) {
        progress.visibility = View.VISIBLE
        controller?.pause()
        val previous = castTarget
        lifecycleScope.launch {
            if (previous != null && previous.avTransportUrl != r.avTransportUrl) {
                runCatching { Dlna.stop(previous) }
                CastService.stop(this@MainActivity)
            }
            try {
                val url = if (r.isTubetto) {
                    "https://www.youtube.com/watch?v=$videoId"
                } else {
                    resolver.maxHeight = it.gerry.tubetto.playback.Buffering.maxVideoHeight(this@MainActivity)
                    val s = resolver.resolve(videoId, audioOnly = false, muxedOnly = true)
                    StreamProxy.publish(s.videoUrl!!, "mp4", videoId = videoId, source = s.source)
                }
                Dlna.play(r, url, title, "video/mp4")
                if (!r.isTubetto) CastService.start(this@MainActivity, r, title)
                ListenHistory.record(videoId, title, "", "https://i.ytimg.com/vi/$videoId/hqdefault.jpg", music = false)
                controller?.pause()
                castTarget = r
                toast("In onda su ${r.name}")
                showTvControls(r)
            } catch (e: Exception) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Trasmissione fallita")
                    .setMessage(e.message)
                    .setPositiveButton("OK", null)
                    .show()
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private fun showTvControls(r: Renderer) {
        AlertDialog.Builder(this)
            .setTitle(r.name)
            .setItems(arrayOf("▶ Riprendi", "⏸ Pausa", "⏹ Stop")) { _, i ->
                lifecycleScope.launch {
                    runCatching {
                        when (i) {
                            0 -> Dlna.resume(r)
                            1 -> Dlna.pause(r)
                            else -> {
                                Dlna.stop(r)
                                castTarget = null
                                CastService.stop(this@MainActivity)
                            }
                        }
                    }.onFailure { toast("TV: ${it.message}") }
                }
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    // ---------------- Sincronizzazione tra dispositivi ----------------

    private fun syncNow(manual: Boolean) {
        if (!SyncManager.enabled() && manual && !UpdatePrefs(this).isAdmin) {
            showOwnSync()
            return
        }
        if (!SyncManager.enabled()) {
            if (manual) {
                AlertDialog.Builder(this)
                    .setTitle("Sincronizzazione tra dispositivi")
                    .setMessage(
                        "Per avere gli stessi preferiti, playlist, artisti, canali e cronologia su telefono e Fire TV:\n\n" +
                            "1. Su ogni dispositivo inserisci in Impostazioni GitHub lo stesso utente, repo e token.\n" +
                            "2. Il token deve avere il permesso \"Contents: Read and write\" sul repo.\n" +
                            "3. Attiva \"Sincronizza tra dispositivi\" nelle impostazioni."
                    )
                    .setPositiveButton("Impostazioni") { _, _ -> showSettings() }
                    .setNegativeButton("Chiudi", null)
                    .show()
            }
            return
        }
        lifecycleScope.launch {
            val changed = runCatching { SyncManager.sync() }.getOrElse {
                if (manual) toast("Sincronizzazione non riuscita: ${SyncManager.lastStatus}")
                return@launch
            }
            if (manual) toast(SyncManager.lastStatus)
            if (changed) refreshLibraryPage()
        }
    }

    /** Dopo una sincronizzazione ricarica la pagina se mostra dati della libreria. */
    private fun refreshLibraryPage() {
        adapter.refresh()
        when (chips.checkedChipId) {
            R.id.chipLibAll -> showLibrary()
            R.id.chipFav -> showFavorites()
            R.id.chipMyPl -> showMyPlaylists()
            R.id.chipChannels -> showChannels()
            R.id.chipArtists -> showArtists()
            R.id.chipHistory -> showHistory()
        }
    }

    // ---------------- Audio ----------------

    private fun showAudioSettings() {
        val q = AudioPrefs.quality(this)
        val p = AudioPrefs.profile(this)
        AlertDialog.Builder(this)
            .setTitle("Audio e qualità")
            .setItems(
                arrayOf(
                    "Qualità audio / consumo dati\n${q.label}",
                    "Profilo sonoro\n${p.label}",
                    "Riproduzione automatica\n" + if (AutoplayPrefs.enabled(this))
                        "Attiva: alla fine continua con video/brani simili" else "Disattivata: si ferma alla fine della coda",
                )
            ) { _, i ->
                when (i) {
                    0 -> chooseQuality()
                    1 -> chooseProfile()
                    else -> {
                        val now = !AutoplayPrefs.enabled(this)
                        AutoplayPrefs.set(this, now)
                        toast(if (now) "Riproduzione automatica attiva" else "Riproduzione automatica disattivata")
                    }
                }
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun chooseQuality() {
        val all = AudioPrefs.Quality.values()
        AlertDialog.Builder(this)
            .setTitle("Qualità audio")
            .setSingleChoiceItems(all.map { it.label }.toTypedArray(), all.indexOf(AudioPrefs.quality(this))) { d, i ->
                AudioPrefs.setQuality(this, all[i])
                toast("Qualità: dal prossimo brano")
                d.dismiss()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun chooseProfile() {
        val all = AudioPrefs.Profile.values()
        AlertDialog.Builder(this)
            .setTitle("Profilo sonoro")
            .setSingleChoiceItems(all.map { it.label }.toTypedArray(), all.indexOf(AudioPrefs.profile(this))) { d, i ->
                AudioPrefs.setProfile(this, all[i])
                toast("Profilo applicato")
                d.dismiss()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    // ---------------- Diagnostica ----------------

    private fun showLog() {
        val text = Diagnostics.dump()
        val pad = dp(16)
        val tv = TextView(this).apply {
            this.text = text
            setTextIsSelectable(true)
            textSize = 11f
            setPadding(pad, pad / 2, pad, 0)
        }
        AlertDialog.Builder(this)
            .setTitle("Log ${BuildConfig.VERSION_NAME}")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copia") { _, _ ->
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("Tubetto log", text))
                toast("Log copiato")
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    // ---------------- Aggiornamento da GitHub ----------------

    private fun showSettings() {
        val pad = dp(20)
        fun label(t: String) = TextView(this).apply {
            text = t
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        }
        val user = EditText(this).apply {
            hint = "es. gerry-dev (o incolla il link del repo)"
            setText(prefs.user)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val repo = EditText(this).apply {
            hint = "Tubetto"
            setText(prefs.repoName)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val token = EditText(this).apply {
            hint = "github_pat_… (vuoto se il repo è pubblico)"
            setText(prefs.token)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val sync = android.widget.CheckBox(this).apply {
            text = "Sincronizza preferiti, playlist e cronologia tra i dispositivi (token con Contents: Read and write)"
            isChecked = prefs.syncEnabled
        }
        val status = TextView(this).apply {
            text = "Stato: ${SyncManager.lastStatus}"
            textSize = 12f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, 0, pad, 0)
            addView(label("Utente GitHub (proprietario del repo)")); addView(user)
            addView(label("Nome repository")); addView(repo)
            addView(label("Token GitHub")); addView(token)
            addView(sync); addView(status)
        }
        AlertDialog.Builder(this)
            .setTitle("Aggiornamenti da GitHub")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Salva e verifica") { _, _ ->
                prefs.setFromInput(user.text.toString(), repo.text.toString())
                prefs.token = token.text.toString()
                prefs.syncEnabled = sync.isChecked
                checkUpdate(silent = false)
                if (sync.isChecked) syncNow(manual = true)
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    /** Senza token si usa il repo pubblico delle release: funziona per tutti, senza configurare niente. */
    private fun checkUpdate(silent: Boolean) {
        lifecycleScope.launch {
            try {
                val rel = updater.latest()
                if (Updater.isNewer(rel.version, BuildConfig.VERSION_NAME)) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Nuova versione ${rel.version}")
                        .setMessage(rel.notes.ifBlank { "Installata: ${BuildConfig.VERSION_NAME}" })
                        .setPositiveButton("Scarica e installa") { _, _ -> downloadAndInstall(rel) }
                        .setNegativeButton("Dopo", null)
                        .show()
                } else if (!silent) {
                    toast("Sei aggiornato ✓ (ultima versione ${rel.version})")
                }
            } catch (e: Exception) {
                if (!silent) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Controllo aggiornamenti fallito")
                        .setMessage("Controlla la connessione e riprova.\n\n${e.message}")
                        .setPositiveButton("Riprova") { _, _ -> checkUpdate(silent = false) }
                        .setNegativeButton("Chiudi", null)
                        .show()
                }
            }
        }
    }

    private fun downloadAndInstall(rel: Updater.Release) {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Download ${rel.version}")
            .setView(bar)
            .setCancelable(false)
            .show()
        lifecycleScope.launch {
            try {
                val apk = updater.download(rel) { bar.progress = it }
                dialog.dismiss()
                if (!updater.install(apk)) {
                    toast("Consenti l'installazione da Tubetto, poi premi di nuovo Aggiorna")
                }
            } catch (e: Exception) {
                dialog.dismiss()
                toast("Download fallito: ${e.message}")
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
