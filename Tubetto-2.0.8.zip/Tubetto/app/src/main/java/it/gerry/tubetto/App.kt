package it.gerry.tubetto

import android.app.Application
import it.gerry.tubetto.data.ArtistImages
import it.gerry.tubetto.data.Library
import it.gerry.tubetto.data.ListenHistory
import it.gerry.tubetto.data.ServiceHealth
import it.gerry.tubetto.data.SyncManager
import it.gerry.tubetto.data.UserProfile
import it.gerry.tubetto.net.NewPipeDownloader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization

class App : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        ListenHistory.init(this)
        Library.init(this)
        ArtistImages.init(this)
        SyncManager.init(this)
        ServiceHealth.init(this)
        it.gerry.tubetto.data.StreamResolver.init(this)
        UserProfile.init(this)
        it.gerry.tubetto.data.Account.init(this)
        it.gerry.tubetto.data.Radio.init(this)
        it.gerry.tubetto.data.Recents.init(this)
        // Configurazione client aggiornata anche quando l'app parte solo per Android Auto
        appScope.launch { runCatching { ServiceHealth.refresh() } }
        // NewPipeExtractor: usato come fallback per stream cifrati (signatureCipher / n-param)
        NewPipe.init(NewPipeDownloader.instance, Localization("it", "IT"), ContentCountry("IT"))
    }
}
