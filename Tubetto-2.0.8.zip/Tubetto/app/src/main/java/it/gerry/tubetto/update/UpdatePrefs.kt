package it.gerry.tubetto.update

import android.content.Context

/** Utente GitHub, nome repository e token (necessario se il repo è privato). */
class UpdatePrefs(context: Context) {
    private val sp = context.getSharedPreferences("update", Context.MODE_PRIVATE)

    var user: String
        get() = sp.getString("user", "").orEmpty()
        set(v) = sp.edit().putString("user", v.trim()).apply()

    var repoName: String
        get() = sp.getString("repoName", "Tubetto").orEmpty()
        set(v) = sp.edit().putString("repoName", v.trim()).apply()

    var token: String
        get() = sp.getString("token", "").orEmpty()
        set(v) = sp.edit().putString("token", v.trim()).apply()

    /** "utente/repo" per le API GitHub. */
    val repo: String get() = "$user/$repoName"

    val isConfigured: Boolean get() = user.isNotBlank() && repoName.isNotBlank()

    /** Con il token si usa il repo privato; senza, le release pubbliche (aggiornamenti per tutti, nessuna configurazione). */
    val releasesRepo: String get() = if (token.isNotBlank() && isConfigured) repo else PUBLIC_RELEASES

    /** Modalità amministratore (sincronizzazione, stato servizio, log, GitHub): attiva col token o sbloccata a mano. */
    var adminUnlocked: Boolean
        get() = sp.getBoolean("admin", false)
        set(v) = sp.edit().putBoolean("admin", v).apply()

    val isAdmin: Boolean get() = adminUnlocked || token.isNotBlank()

    companion object {
        /** Repository pubblico con le sole release (APK): lo aggiorna il workflow di build. */
        const val PUBLIC_RELEASES = "mariopinola10/tubetto-releases"
    }

    /** Sincronizza preferiti/playlist/cronologia tra i dispositivi tramite il repo. */
    var syncEnabled: Boolean
        get() = sp.getBoolean("sync", true)
        set(v) = sp.edit().putBoolean("sync", v).apply()

    /** Accetta anche un link incollato, es. https://github.com/utente/Tubetto */
    fun setFromInput(userInput: String, repoInput: String) {
        val link = Regex("""github\.com/([^/\s]+)/([^/\s?#]+)""").find(userInput + " " + repoInput)
        if (link != null) {
            user = link.groupValues[1]
            repoName = link.groupValues[2].removeSuffix(".git")
        } else {
            user = userInput.trim().trimStart('@')
            repoName = repoInput.trim().ifBlank { "Tubetto" }
        }
    }
}
