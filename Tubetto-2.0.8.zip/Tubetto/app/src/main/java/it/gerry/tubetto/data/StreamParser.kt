package it.gerry.tubetto.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

object StreamParser {

    private val VIDEO_RENDERERS = setOf(
        "videoRenderer", "compactVideoRenderer", "gridVideoRenderer",
        "playlistVideoRenderer", "playlistPanelVideoRenderer",
    )

    // ---------------- search / browse ----------------

    fun parseVideoItems(root: Any): List<VideoItem> = collect(root).filter { it.kind == ItemKind.VIDEO }

    fun parsePlaylists(root: Any): List<VideoItem> = collect(root).filter { it.kind == ItemKind.PLAYLIST }

    fun parseChannels(root: Any): List<VideoItem> = collect(root).filter { it.kind == ItemKind.CHANNEL }

    /** Visita ricorsiva: robusta ai cambi di layout (videoRenderer, playlistRenderer, lockupViewModel). */
    private fun collect(root: Any): List<VideoItem> {
        val out = LinkedHashMap<String, VideoItem>()
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> for (key in node.keys()) {
                    val child = node.opt(key)
                    val item = when {
                        child !is JSONObject -> null
                        key in VIDEO_RENDERERS -> videoItem(child)
                        key == "playlistRenderer" -> playlistItem(child)
                        key == "channelRenderer" -> channelItem(child)
                        key == "lockupViewModel" -> lockupItem(child)
                        else -> null
                    }
                    if (item != null) out.putIfAbsent("${item.kind}:${item.id}", item) else walk(child)
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(root)
        return out.values.toList()
    }

    private fun videoItem(r: JSONObject): VideoItem? {
        val id = r.optString("videoId").ifBlank { return null }
        val live = text(r.opt("viewCountText")).isEmpty() && r.has("badges")
        return VideoItem(
            id = id,
            title = text(r.opt("title")),
            author = text(r.opt("ownerText") ?: r.opt("shortBylineText") ?: r.opt("longBylineText"))
                .substringBefore(" • "),
            duration = text(r.opt("lengthText")).ifEmpty { if (live) "LIVE" else "" },
            views = text(r.opt("shortViewCountText")).ifEmpty { text(r.opt("viewCountText")) },
            published = text(r.opt("publishedTimeText")),
            description = description(r),
            channelAvatar = r.optJSONObject("channelThumbnailSupportedRenderers")
                ?.optJSONObject("channelThumbnailWithLinkRenderer")
                ?.optJSONObject("thumbnail")
                ?.let { bestThumb(it.optJSONArray("thumbnails")) },
            thumbnailUrl = bestThumb(r.optJSONObject("thumbnail")?.optJSONArray("thumbnails")),
            channelId = (findFirst(r.opt("ownerText") ?: r.opt("shortBylineText") ?: r.opt("longBylineText"), "browseId") as? String)
                ?.takeIf { it.startsWith("UC") },
        )
    }

    private fun channelItem(r: JSONObject): VideoItem? {
        val id = r.optString("channelId").ifBlank { return null }
        val subs = text(r.opt("videoCountText")).ifEmpty { text(r.opt("subscriberCountText")) }
        return VideoItem(
            id = id,
            title = text(r.opt("title")),
            author = text(r.opt("subscriberCountText")).takeIf { it.startsWith("@") }.orEmpty(),
            duration = "",
            views = subs,
            description = text(r.opt("descriptionSnippet")),
            thumbnailUrl = bestThumb(r.optJSONObject("thumbnail")?.optJSONArray("thumbnails")),
            kind = ItemKind.CHANNEL,
        )
    }

    private fun playlistItem(r: JSONObject): VideoItem? {
        val id = r.optString("playlistId").ifBlank { return null }
        val count = text(r.opt("videoCountText")).ifEmpty {
            r.optString("videoCount").takeIf { it.isNotBlank() }?.let { "$it video" }.orEmpty()
        }
        val thumbs = r.optJSONArray("thumbnails")?.optJSONObject(0)?.optJSONArray("thumbnails")
            ?: r.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
        return VideoItem(
            id = id,
            title = text(r.opt("title")),
            author = text(r.opt("shortBylineText") ?: r.opt("longBylineText")),
            duration = count,
            thumbnailUrl = bestThumb(thumbs),
            kind = ItemKind.PLAYLIST,
        )
    }

    /** Nuovo formato YouTube (lockupViewModel) usato per playlist, mix e a volte video. */
    private fun lockupItem(l: JSONObject): VideoItem? {
        val id = l.optString("contentId").ifBlank { return null }
        val type = l.optString("contentType")
        val meta = l.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")
        val title = meta?.optJSONObject("title")?.optString("content").orEmpty()

        val parts = mutableListOf<String>()
        meta?.optJSONObject("metadata")?.optJSONObject("contentMetadataViewModel")
            ?.optJSONArray("metadataRows")?.let { rows ->
                for (i in 0 until rows.length()) {
                    val mp = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
                    for (j in 0 until mp.length()) {
                        mp.optJSONObject(j)?.optJSONObject("text")?.optString("content")
                            ?.takeIf { it.isNotBlank() }?.let { parts += it }
                    }
                }
            }

        val image = l.optJSONObject("contentImage")
        val sources = findFirst(image, "sources") as? JSONArray
        val badge = (findFirst(image, "thumbnailBadgeViewModel") as? JSONObject)?.optString("text").orEmpty()
        val isList = listOf("PLAYLIST", "ALBUM", "PODCAST").any { it in type }

        val published = parts.firstOrNull { PUBLISHED.containsMatchIn(it) }.orEmpty()
        val views = parts.firstOrNull { VIEWS.containsMatchIn(it) }.orEmpty()
        val rest = parts.filter { it != published && it != views }
        return VideoItem(
            id = id,
            title = title,
            author = rest.firstOrNull().orEmpty(),
            duration = badge,
            views = (listOf(views) + rest.drop(1)).filter { it.isNotBlank() }.joinToString(" • "),
            published = published,
            thumbnailUrl = bestThumb(sources),
            kind = if (isList) ItemKind.PLAYLIST else ItemKind.VIDEO,
        )
    }

    // ---------------- YouTube Music ----------------

    fun parseMusic(root: Any): List<VideoItem> {
        val out = LinkedHashMap<String, VideoItem>()
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> for (key in node.keys()) {
                    val child = node.opt(key)
                    if (key == "musicResponsiveListItemRenderer" && child is JSONObject) {
                        musicItem(child)?.let { out.putIfAbsent(it.id, it) }
                    } else if (key == "musicTwoRowItemRenderer" && child is JSONObject) {
                        twoRowSong(child)?.let { out.putIfAbsent(it.id, it) }
                    } else walk(child)
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(root)
        return out.values.toList()
    }

    private val RELEASE_TYPES = setOf("Brano", "Song", "Video", "Singolo", "Single", "EP", "Album", "Video musicale")

    /** Riquadro di YouTube Music che punta direttamente a un brano (classifiche video, tendenze). */
    private fun twoRowSong(r: JSONObject): VideoItem? {
        val vid = findFirst(r.optJSONObject("navigationEndpoint"), "videoId") as? String ?: return null
        val parts = text(r.opt("subtitle")).split(" • ").map { it.trim() }.filter { it.isNotEmpty() }
        return VideoItem(
            id = vid,
            title = text(r.opt("title")),
            author = parts.firstOrNull { it !in RELEASE_TYPES && !it.contains("visualizz", true) && !it.contains("views", true) }.orEmpty(),
            duration = "",
            views = parts.firstOrNull { it.contains("visualizz", true) || it.contains("views", true) }.orEmpty(),
            thumbnailUrl = bestThumb(findFirst(r.optJSONObject("thumbnailRenderer"), "thumbnails") as? JSONArray)
                ?.replace(Regex("=w\\d+-h\\d+"), "=w320-h320"),
        )
    }

    /** Uscita (singolo/EP/album) di YouTube Music. */
    data class Release(val browseId: String, val title: String, val artist: String, val type: String, val thumb: String?)

    fun parseReleases(root: Any): List<Release> {
        val out = LinkedHashMap<String, Release>()
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> for (key in node.keys()) {
                    val child = node.opt(key)
                    if (key == "musicTwoRowItemRenderer" && child is JSONObject) {
                        val id = (findFirst(child.optJSONObject("navigationEndpoint"), "browseId") as? String)
                            ?.takeIf { it.startsWith("MPRE") }
                        if (id != null) {
                            val parts = text(child.opt("subtitle")).split(" • ").map { it.trim() }
                            out.putIfAbsent(
                                id,
                                Release(
                                    id, text(child.opt("title")),
                                    parts.firstOrNull { it !in RELEASE_TYPES && !it.matches(Regex("\\d{4}")) }.orEmpty(),
                                    parts.firstOrNull { it in RELEASE_TYPES }.orEmpty(),
                                    bestThumb(findFirst(child.optJSONObject("thumbnailRenderer"), "thumbnails") as? JSONArray),
                                ),
                            )
                        }
                    } else walk(child)
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(root)
        return out.values.toList()
    }

    /** Artisti dalla ricerca di YouTube Music (con ID del canale ufficiale). */
    fun parseMusicArtists(root: Any): List<VideoItem> {
        val out = LinkedHashMap<String, VideoItem>()
        fun walk(node: Any?) {
            when (node) {
                is JSONObject -> for (key in node.keys()) {
                    val child = node.opt(key)
                    if (key == "musicResponsiveListItemRenderer" && child is JSONObject) {
                        artistItem(child)?.let { out.putIfAbsent(it.id.lowercase(), it) }
                    } else walk(child)
                }
                is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i))
            }
        }
        walk(root)
        return out.values.toList()
    }

    private fun artistItem(r: JSONObject): VideoItem? {
        val browse = r.optJSONObject("navigationEndpoint")?.optJSONObject("browseEndpoint") ?: return null
        val channelId = browse.optString("browseId").takeIf { it.startsWith("UC") } ?: return null
        val pageType = findFirst(browse, "pageType") as? String
        if (pageType != null && "ARTIST" !in pageType) return null
        val cols = r.optJSONArray("flexColumns") ?: return null
        fun col(i: Int) = cols.optJSONObject(i)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")?.optJSONObject("text")
        val name = text(col(0)).ifBlank { return null }
        val info = text(col(1)).split(" • ").map { it.trim() }.filter { it.isNotEmpty() && it != "Artista" && it != "Artist" }
        val thumb = bestThumb(findFirst(r.optJSONObject("thumbnail"), "thumbnails") as? JSONArray)
            ?.replace(Regex("=w\\d+-h\\d+"), "=w320-h320")
        return VideoItem(
            id = name,
            title = name,
            author = "Artista",
            duration = "",
            views = info.joinToString(" • "),
            thumbnailUrl = thumb,
            kind = ItemKind.ARTIST,
            channelId = channelId,
        )
    }

    private val PUBLISHED = Regex("(?i)(\\bfa$|\\bago$|^(in streaming|trasmesso|streamed|premiered))")
    private val VIEWS = Regex("(?i)(visualizzazion|views|spettatori|watching)")

    private val DURATION = Regex("""^\d{1,2}(:\d{2}){1,2}$""")

    private fun musicItem(r: JSONObject): VideoItem? {
        val cols = r.optJSONArray("flexColumns") ?: return null
        fun col(i: Int) = cols.optJSONObject(i)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")?.optJSONObject("text")
        val id = r.optJSONObject("playlistItemData")?.optString("videoId")?.ifBlank { null }
            ?: (findFirst(col(0), "videoId") as? String)
            ?: return null

        val parts = text(col(1)).split(" • ").map { it.trim() }.filter { it.isNotEmpty() }
        val duration = parts.lastOrNull { DURATION.matches(it) }.orEmpty()
        val rest = parts.filter { it != duration && it !in setOf("Brano", "Song", "Video") }

        val thumb = bestThumb(findFirst(r.optJSONObject("thumbnail"), "thumbnails") as? JSONArray)
            ?.replace(Regex("=w\\d+-h\\d+"), "=w320-h320")

        return VideoItem(
            id = id,
            title = text(col(0)),
            author = rest.firstOrNull().orEmpty(),
            duration = duration,
            views = rest.drop(1).joinToString(" • "),
            thumbnailUrl = thumb,
        )
    }

    // ---------------- utilità JSON ----------------

    private fun description(r: JSONObject): String {
        r.optJSONArray("detailedMetadataSnippets")?.optJSONObject(0)?.opt("snippetText")
            ?.let { text(it) }?.takeIf { it.isNotBlank() }?.let { return it }
        return text(r.opt("descriptionSnippet"))
    }

    private fun text(node: Any?): String {
        if (node !is JSONObject) return ""
        node.optString("simpleText").takeIf { it.isNotEmpty() }?.let { return it }
        node.optString("content").takeIf { it.isNotEmpty() }?.let { return it }
        val runs = node.optJSONArray("runs") ?: return ""
        return buildString { for (i in 0 until runs.length()) append(runs.optJSONObject(i)?.optString("text").orEmpty()) }
    }

    /** URL dell'immagine più grande; corregge gli URL che iniziano con "//". */
    private fun bestThumb(arr: JSONArray?): String? {
        if (arr == null) return null
        var best: JSONObject? = null
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue
            if (best == null || t.optInt("width") > best.optInt("width")) best = t
        }
        val url = best?.optString("url")?.ifBlank { null } ?: return null
        return if (url.startsWith("//")) "https:$url" else url
    }

    private fun findFirst(node: Any?, key: String): Any? {
        when (node) {
            is JSONObject -> {
                if (node.has(key)) return node.opt(key)
                for (k in node.keys()) findFirst(node.opt(k), key)?.let { return it }
            }
            is JSONArray -> for (i in 0 until node.length()) findFirst(node.opt(i), key)?.let { return it }
        }
        return null
    }

    // ---------------- player ----------------

    private data class Format(
        val itag: Int,
        val mime: String,
        val url: String?,
        val ciphered: Boolean,
        val bitrate: Int,
        val avgBitrate: Int,
        val height: Int,
        val width: Int,
        val fps: Int,
        val initRange: String?,
        val indexRange: String?,
        val audioSampleRate: Int,
    ) {
        val baseMime: String get() = mime.substringBefore(';').trim()
        val effectiveBitrate: Int get() = if (avgBitrate > 0) avgBitrate else bitrate
        val codecs: String get() = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.get(1).orEmpty()

        fun toRep() = DashManifest.Rep(
            itag, url!!, baseMime, codecs, bitrate, width, height, fps, initRange!!, indexRange!!, audioSampleRate,
        )
    }

    /**
     * Candidati riproducibili da /player, in ordine di preferenza:
     * 1) DASH adattivo (video)  2) video-only mp4 + audio separato  3) audio-only  4) muxed (360p).
     */
    /** Audio migliore entro il limite di kbps; a parità preferisce Opus (più qualità per MB). */
    private fun pickAudio(audios: List<Format>, maxKbps: Int): Format? {
        if (audios.isEmpty()) return null
        val within = audios.filter { it.effectiveBitrate <= maxKbps * 1000 }
        val pool = within.ifEmpty { listOf(audios.minByOrNull { it.effectiveBitrate }!!) }
        return pool.maxWithOrNull(compareBy<Format>({ it.effectiveBitrate }, { if ("opus" in it.mime) 1 else 0 }))
    }

    fun parsePlayer(
        json: JSONObject,
        maxHeight: Int,
        audioOnly: Boolean,
        source: String,
        audioMaxKbps: Int = 1000,
    ): List<ResolvedStream> {
        val status = json.optJSONObject("playabilityStatus")
        if (status?.optString("status") != "OK") {
            throw IOException("${status?.optString("status")}: ${status?.optString("reason") ?: "sconosciuto"}")
        }
        val details = json.optJSONObject("videoDetails") ?: JSONObject()
        val sd = json.optJSONObject("streamingData") ?: throw IOException("streamingData assente")

        val id = details.optString("videoId")
        val durationMs = details.optString("lengthSeconds").toLongOrNull()?.times(1000) ?: 0L
        val base = ResolvedStream(
            videoId = id,
            title = details.optString("title"),
            author = details.optString("author"),
            thumbnail = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
            durationMs = durationMs,
            videoUrl = null, audioUrl = null, hlsUrl = null,
            source = source,
        )

        val hls = sd.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
        if (details.optBoolean("isLive") && hls != null) return listOf(base.copy(hlsUrl = hls, source = "$source:hls"))

        val out = mutableListOf<ResolvedStream>()
        val adaptive = toFormats(sd.optJSONArray("adaptiveFormats")).filter { !it.ciphered && it.url != null }
        val audios = adaptive.filter { it.mime.startsWith("audio/") }
        val audio = pickAudio(audios, audioMaxKbps)

        if (audio != null) {
            if (audioOnly) {
                out += base.copy(audioUrl = audio.url)
            } else {
                val mp4 = adaptive.filter { it.mime.startsWith("video/mp4") && it.height in 1..maxHeight }
                val avc = mp4.filter { "avc1" in it.mime }

                // 1) DASH: tutte le qualità H.264 con indici, ExoPlayer sceglie e adatta
                val dashVideos = avc.filter { it.initRange != null && it.indexRange != null }
                val dashAudios = listOfNotNull(
                    pickAudio(audios.filter { it.initRange != null && it.indexRange != null }, audioMaxKbps)
                )
                if (dashVideos.isNotEmpty() && dashAudios.isNotEmpty() && durationMs > 0) {
                    val mpd = DashManifest.build(dashVideos.map { it.toRep() }, dashAudios.map { it.toRep() }, durationMs)
                    out += base.copy(
                        videoUrl = dashVideos.minByOrNull { it.bitrate }?.url,
                        audioUrl = dashAudios.maxByOrNull { it.bitrate }?.url,
                        dashManifest = mpd,
                        source = "$source:dash",
                    )
                }

                // 2) Progressivo: una qualità fissa
                val video = avc.maxWithOrNull(compareBy({ it.height }, { it.bitrate }))
                    ?: mp4.maxWithOrNull(compareBy({ it.height }, { it.bitrate }))
                if (video != null) out += base.copy(videoUrl = video.url, audioUrl = audio.url)
            }
        }

        val muxed = toFormats(sd.optJSONArray("formats"))
            .filter { !it.ciphered && it.url != null && it.mime.startsWith("video/mp4") }
            .maxByOrNull { it.height }
        if (muxed != null) out += base.copy(videoUrl = muxed.url, source = "$source:muxed")

        return out
    }

    private fun toFormats(arr: JSONArray?): List<Format> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val f = arr.optJSONObject(i) ?: return@mapNotNull null
            fun range(name: String): String? = f.optJSONObject(name)?.let { r ->
                val a = r.optString("start"); val b = r.optString("end")
                if (a.isNotBlank() && b.isNotBlank()) "$a-$b" else null
            }
            Format(
                itag = f.optInt("itag"),
                mime = f.optString("mimeType"),
                url = f.optString("url").ifBlank { null },
                ciphered = f.has("signatureCipher") || f.has("cipher"),
                bitrate = f.optInt("bitrate"),
                avgBitrate = f.optInt("averageBitrate"),
                height = f.optInt("height"),
                width = f.optInt("width"),
                fps = f.optInt("fps"),
                initRange = range("initRange"),
                indexRange = range("indexRange"),
                audioSampleRate = f.optString("audioSampleRate").toIntOrNull() ?: 0,
            )
        }
    }
}
