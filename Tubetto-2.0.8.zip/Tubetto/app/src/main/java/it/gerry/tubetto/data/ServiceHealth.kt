package it.gerry.tubetto.data

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import it.gerry.tubetto.BuildConfig
import it.gerry.tubetto.Diagnostics
import it.gerry.tubetto.net.Http
import it.gerry.tubetto.update.UpdatePrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Salute del servizio:
 *  - legge config/tubetto-config.json (versioni client aggiornate in automatico) e la applica al volo;
 *  - legge config/tubetto-status.json (controllo automatico ogni 6 ore su GitHub);
 *  - conta i fallimenti di riproduzione sul dispositivo;
 *  - decide quando mostrare un avviso nell'app, con un rapporto pronto da incollare a Claude.
 */
object ServiceHealth {

    private const val CONFIG_PATH = "config/tubetto-config.json"
    private const val STATUS_PATH = "config/tubetto-status.json"
    private const val REFRESH_MS = 3 * 60 * 60 * 1000L
    private const val LOCAL_THRESHOLD = 3

    private lateinit var app: Context
    private lateinit var sp: SharedPreferences

    @Volatile var remoteStatus: JSONObject? = null
        private set
    @Volatile var configVersion: String = "integrata nell'app"
        private set
    @Volatile private var lastFetch = 0L
    @Volatile private var consecutiveFailures = 0
    @Volatile private var lastError = ""
    @Volatile private var lastErrorAt = 0L

    /** Avvisa la UI quando la riproduzione fallisce di continuo. */
    @Volatile var onLocalCrisis: (() -> Unit)? = null

    fun init(context: Context) {
        app = context.applicationContext
        sp = app.getSharedPreferences("health", Context.MODE_PRIVATE)
        sp.getString("config", null)?.let { s ->
            runCatching {
                val o = JSONObject(s)
                if (Clients.apply(o)) configVersion = o.optString("updated", "salvata")
            }
        }
        sp.getString("status", null)?.let { s -> remoteStatus = runCatching { JSONObject(s) }.getOrNull() }
        lastFetch = sp.getLong("fetched", 0L)
    }

    /**
     * Scarica configurazione e stato dal repository (al massimo ogni 3 ore, salvo [force]).
     * @return true se la configurazione dei client è cambiata.
     */
    suspend fun refresh(force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (!::app.isInitialized) return@withContext false
        if (!force && System.currentTimeMillis() - lastFetch < REFRESH_MS) return@withContext false
        val prefs = UpdatePrefs(app)
        if (!prefs.isConfigured) return@withContext false
        lastFetch = System.currentTimeMillis()
        sp.edit().putLong("fetched", lastFetch).apply()
        var changed = false
        runCatching { fetch(prefs, CONFIG_PATH) }
            .onFailure { Diagnostics.log("Config remota non letta: ${it.message}") }
            .getOrNull()?.let { o ->
                val v = o.optString("updated", "?")
                if (v != configVersion) {
                    if (Clients.apply(o)) {
                        sp.edit().putString("config", o.toString()).apply()
                        configVersion = v
                        changed = true
                        Diagnostics.log("Configurazione client aggiornata ($v)")
                    } else {
                        Diagnostics.log("Config remota non valida: tengo quella precedente")
                    }
                }
            }
        runCatching { fetch(prefs, STATUS_PATH) }.getOrNull()?.let { o ->
            remoteStatus = o
            sp.edit().putString("status", o.toString()).apply()
        }
        changed
    }

    private fun fetch(prefs: UpdatePrefs, path: String): JSONObject? {
        val b = Request.Builder()
            .url("https://api.github.com/repos/${prefs.repo}/contents/$path")
            .header("Accept", "application/vnd.github.raw+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
        if (prefs.token.isNotBlank()) b.header("Authorization", "Bearer ${prefs.token}")
        Http.client.newCall(b.build()).execute().use { r ->
            if (r.code == 404) return null
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
            return JSONObject(r.body!!.string())
        }
    }

    // ---------------- fallimenti sul dispositivo ----------------

    fun reportSuccess() {
        consecutiveFailures = 0
    }

    fun reportFailure(message: String) {
        if (!online()) return // senza rete non è colpa di YouTube
        consecutiveFailures++
        lastError = message.take(1500)
        lastErrorAt = System.currentTimeMillis()
        if (consecutiveFailures == LOCAL_THRESHOLD) {
            Diagnostics.log("⚠ $LOCAL_THRESHOLD riproduzioni fallite di seguito con tutti i client")
            onLocalCrisis?.invoke()
        }
    }

    private fun online(): Boolean {
        return try {
            val cm = app.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            true
        }
    }

    // ---------------- avvisi ----------------

    data class Alert(val key: String, val title: String, val message: String)

    /** L'avviso da mostrare ora, se c'è. */
    fun alert(): Alert? {
        if (consecutiveFailures >= LOCAL_THRESHOLD) {
            return Alert(
                "local:${lastErrorAt / 600_000}",
                "⚠ Riproduzione non riuscita",
                "Gli ultimi $consecutiveFailures brani non sono partiti con nessun metodo: probabilmente YouTube ha cambiato qualcosa.\n\n" +
                    "L'app continua a provare i metodi alternativi e si aggiorna da sola appena arriva una configurazione nuova.\n\n" +
                    "Se non si risolve: tocca \"Copia rapporto\" e incollalo a Claude.",
            )
        }
        val st = remoteStatus ?: return null
        if (st.optString("overall") != "broken") return null
        return Alert(
            "remote:" + st.optString("since"),
            "⚠ Tubetto: servizio in difficoltà",
            st.optString("message").ifBlank { "Il controllo automatico ha rilevato un problema con YouTube." } +
                "\n\n" + checksText(onlyFailed = true) +
                "\n\nIl sistema riprova da solo ogni 6 ore. Se dura: \"Copia rapporto\" e incollalo a Claude.",
        )
    }

    fun shouldShow(a: Alert): Boolean = sp.getString("ack", "") != a.key

    fun acknowledge(a: Alert) {
        sp.edit().putString("ack", a.key).apply()
    }

    /** Testo per la finestra "Stato servizio". */
    fun summary(): String = buildString {
        val st = remoteStatus
        val overall = when (st?.optString("overall")) {
            "ok" -> "✔ Tutto funziona"
            "degraded" -> "▲ Funziona: qualche metodo è giù, l'app usa gli altri"
            "broken" -> "✖ Problema rilevato"
            else -> "○ Nessun controllo automatico ancora (serve il workflow \"Salute Tubetto\")"
        }
        appendLine(overall)
        st?.optString("checked")?.takeIf { it.isNotBlank() }?.let { appendLine("Ultimo controllo: ${fmtIso(it)}") }
        st?.optString("message")?.takeIf { it.isNotBlank() }?.let { appendLine(it) }
        if (st != null) {
            appendLine()
            appendLine(checksText(onlyFailed = false))
            st.optJSONObject("newpipe")?.let { np ->
                val cur = np.optString("current"); val latest = np.optString("latest")
                if (latest.isNotBlank() && cur.isNotBlank() && latest != cur) {
                    appendLine()
                    appendLine("ℹ Estrattore di riserva: è uscita la $latest (l'app ha la $cur). Chiedi a Claude una nuova build.")
                }
            }
        }
        appendLine()
        appendLine("Configurazione client: $configVersion")
        if (consecutiveFailures > 0) appendLine("Fallimenti di fila su questo dispositivo: $consecutiveFailures")
    }

    private fun checksText(onlyFailed: Boolean): String {
        val arr = remoteStatus?.optJSONArray("checks") ?: return ""
        val lines = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val c = arr.optJSONObject(i) ?: continue
            val state = c.optString("state", if (c.optBoolean("ok")) "ok" else "fail")
            if (onlyFailed && state == "ok") continue
            val icon = when (state) { "ok" -> "✔"; "inconclusive" -> "○"; else -> "✖" }
            lines += "$icon ${c.optString("name")}" + c.optString("detail").takeIf { it.isNotBlank() }?.let { " — $it" }.orEmpty()
        }
        return lines.joinToString("\n")
    }

    /** Rapporto completo da incollare a Claude. */
    fun report(): String = buildString {
        appendLine("=== Rapporto Tubetto ${BuildConfig.VERSION_NAME} ===")
        appendLine("Data: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY).format(Date())}")
        appendLine("Dispositivo: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} (Android ${android.os.Build.VERSION.RELEASE})")
        appendLine()
        appendLine("--- Client in uso ---")
        appendLine(Clients.describe())
        appendLine("Configurazione: $configVersion")
        appendLine()
        appendLine("--- Ultimo errore (fallimenti di fila: $consecutiveFailures) ---")
        appendLine(lastError.ifBlank { "nessuno" })
        appendLine()
        appendLine("--- Controllo automatico GitHub ---")
        appendLine(remoteStatus?.toString(2) ?: "non disponibile")
        appendLine()
        appendLine("--- Log ---")
        appendLine(Diagnostics.dump().takeLast(8000))
    }

    /**
     * Salva il rapporto nel repository: reports/<dispositivo>.txt (utile su Fire TV, dove non si può copiare).
     * @return il percorso del file
     */
    suspend fun uploadReport(): String = withContext(Dispatchers.IO) {
        val prefs = UpdatePrefs(app)
        if (!prefs.isConfigured) throw java.io.IOException("Configura prima GitHub nelle impostazioni")
        val name = (android.os.Build.MANUFACTURER + "-" + android.os.Build.MODEL).replace(Regex("[^A-Za-z0-9_-]+"), "_")
        val path = "reports/$name.txt"
        val url = "https://api.github.com/repos/${prefs.repo}/contents/$path"
        fun req() = Request.Builder().url(url)
            .header("Authorization", "Bearer ${prefs.token}")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
        val sha = Http.client.newCall(req().build()).execute().use { r ->
            if (r.isSuccessful) JSONObject(r.body!!.string()).optString("sha").ifBlank { null } else null
        }
        val body = JSONObject()
            .put("message", "Rapporto Tubetto da ${android.os.Build.MODEL}")
            .put("content", android.util.Base64.encodeToString(report().toByteArray(), android.util.Base64.NO_WRAP))
        if (sha != null) body.put("sha", sha)
        Http.client.newCall(
            req().put(body.toString().toRequestBody("application/json".toMediaType())).build()
        ).execute().use { r ->
            if (!r.isSuccessful) throw java.io.IOException("Invio non riuscito (HTTP ${r.code})")
        }
        path
    }

    private fun fmtIso(s: String): String = runCatching {
        val d = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ROOT).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            .parse(s.take(19))
        SimpleDateFormat("dd/MM HH:mm", Locale.ITALY).format(d!!)
    }.getOrDefault(s)
}
