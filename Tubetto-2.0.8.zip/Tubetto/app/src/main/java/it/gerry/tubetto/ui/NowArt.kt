package it.gerry.tubetto.ui

import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.media3.common.MediaItem
import coil.load
import it.gerry.tubetto.R
import it.gerry.tubetto.playback.PlaybackService

/**
 * Copertina di ciò che sta suonando, senza mai lasciare il riquadro vuoto:
 * 1) miniatura del video da YouTube, 2) copertina indicata dal player,
 * 3) copertina della playlist da cui stai ascoltando, 4) logo di Tubetto.
 */
object NowArt {

    /** Copertina della playlist/raccolta da cui è partita la riproduzione. */
    @Volatile var collectionCover: String? = null

    private val YT_ID = Regex("^[A-Za-z0-9_-]{11}$")

    fun candidates(item: MediaItem, hd: Boolean = false): List<String> {
        val id = PlaybackService.videoIdOf(item.mediaId)
        val out = mutableListOf<String>()
        if (YT_ID.matches(id)) {
            if (hd) out += "https://i.ytimg.com/vi/$id/hq720.jpg"
            out += "https://i.ytimg.com/vi/$id/mqdefault.jpg"
        }
        item.mediaMetadata.artworkUri?.toString()?.takeIf { it.isNotBlank() }?.let { out += it }
        collectionCover?.takeIf { it.isNotBlank() }?.let { out += it }
        return out.distinct()
    }

    /** Prova le copertine in ordine; se nessuna si carica mette il logo. */
    fun load(view: ImageView, urls: List<String>, onLoaded: ((Drawable) -> Unit)? = null) {
        val first = urls.firstOrNull()
        if (first == null) {
            view.setImageResource(R.mipmap.ic_launcher)
            return
        }
        view.load(first) {
            crossfade(true)
            allowHardware(false)
            listener(
                onSuccess = { _, r -> onLoaded?.invoke(r.drawable) },
                onError = { _, _ -> load(view, urls.drop(1), onLoaded) },
            )
        }
    }
}
