# Tubetto

Player YouTube per Android senza SDK ufficiale: InnerTube + NewPipeExtractor + Media3.

## Build con GitHub
1. Repo (privato) con `.github/workflows/build.yml` (copia da questa cartella).
2. Carica nella root del repo `Tubetto-X.Y.Z.zip` (cartella interna `Tubetto`).
3. Il workflow compila lo zip con versione più alta e pubblica la release `vX.Y.Z` con `Tubetto-X.Y.Z.apk`.
   La versione dell'app (versionName/versionCode) viene presa dal nome dello zip.

## Aggiornamento dall'app
Impostazioni -> `utente/repo` + token GitHub (fine-grained, permesso Contents: Read-only).
All'avvio controlla l'ultima release; il tasto Aggiorna scarica e installa l'APK.
Tutte le build sono firmate con `keystore/tubetto.jks`: non cambiarlo, altrimenti
l'aggiornamento sopra la versione installata fallisce. Tieni il repo privato.

## Android Auto
- App installata fuori dal Play Store: in Android Auto attiva la modalità sviluppatore
  (Impostazioni → tocca 10 volte "Versione"), poi menu ⋮ → Impostazioni sviluppatore → **Origini sconosciute**.
- In auto: Cronologia, cartelle musica, playlist, ricerca, e voce: "Ok Google, riproduci <brano> su Tubetto".
- In auto la riproduzione è solo audio (Android Auto non permette video alle app di terze parti).

## Interfaccia (1.0)
- Telefono/tablet: barra in basso Home · Cerca · La tua libreria; colori chiari ad alto contrasto (tema scuro se il telefono è in modalità scura).
- Home a scaffali orizzontali come Spotify: I tuoi artisti (icone rotonde), Le tue playlist, Per te, Hit del momento,
  Nuove uscite, Ascoltati di recente, Playlist consigliate, Classifiche; filtro Tutti / Musica / Video.
- Toccando un brano di uno scaffale o di una playlist parte la coda con tutti gli altri.
- Pagina artista: "Dalle più recenti" (uscite e canale ufficiale in ordine di data), poi i più ascoltati e le playlist.
- Fire TV: barra laterale chiara con Home, filtri, ricerca, libreria e menu; scaffali navigabili col telecomando.

## Stesso "account" su telefono, tablet e Fire TV
- Preferiti, playlist, artisti, canali seguiti e cronologia si sincronizzano tramite il repo GitHub privato
  (file `sync/tubetto-library.json`, non avvia build).
- Su ogni dispositivo: stesse Impostazioni GitHub (utente, repo, token) + "Sincronizza tra dispositivi".
- Il token fine-grained deve avere **Contents: Read and write** sul repo.
- Sincronizza all'apertura, dopo le modifiche (entro ~15 s) e all'uscita; manuale: ⋮ → Sincronizza dispositivi.

## Libreria
- ❤ Preferiti, Le mie playlist, Canali seguiti, Cronologia: chip sotto la ricerca (salvati sul telefono).
- Tieni premuto un elemento per: preferiti, aggiungi a playlist, vai al canale, segui canale, trasmetti, condividi.
- Modalità Video / Musica / Playlist / Canali: cambia sia la ricerca sia le proposte "Per te".
- Il player grande compare solo per i video (tasto schermo intero); per l'audio c'è la mini barra in basso.

## Android Auto: schermata "In riproduzione"
- Titolo, artista e copertina (servite all'auto come immagini content://), coda dei brani.
- Pulsanti extra: ❤ preferito e casuale (anche in notifica e schermata di blocco).
- Dalla schermata In riproduzione si torna ai menu e viceversa con l'icona standard di Android Auto.

## Musica: solo canzoni, hit e nuove uscite
- Modalità Musica: "Per te", poi 🔥 Hit del momento in Italia e 🆕 Nuove uscite prese da YouTube Music.
- Filtrati notizie, interviste, reaction, shorts ecc.: solo canzoni.
- Pagina artista: le nuove uscite arrivano solo dal canale ufficiale dell'artista.

## Artisti, classifiche ed eventi
- Modalità **Artisti**: ricerca artisti da YouTube Music (con canale ufficiale).
- Artisti e canali si possono seguire entrambi: dalla pagina artista "☆ Segui canale", dalla pagina canale "☆ Segui come artista".
- ★ Artisti: segui un artista (tieni premuto un brano) → pagina con nuove uscite dell'ultimo mese, brani più ascoltati e playlist.
- Classifiche ed eventi: Top 50 Italia, FIMI, nuove uscite, Sanremo, Eurovision, Top Europa/Mondo, tormentoni.
- In "Musica per te" le nuove uscite degli artisti seguiti compaiono in cima.

## Solo canzoni, niente intro
- Ricerca musica e radio scartano extended, loop di ore, album interi, slowed/sped up, karaoke e brani oltre 9 minuti (salvo richiesta esplicita).
- Intro parlate, parti non musicali dei videoclip, sponsor e titoli di coda vengono saltati in automatico (database SponsorBlock).

## Comandi vocali
- "Ok Google, riproduci <brano/artista> su Tubetto": l'app è registrata per le richieste musicali dell'Assistente.
- In alternativa: in Android Auto apri Tubetto → lente → microfono.

## Audio e notifiche
- Notifiche e suoni brevi non fermano la musica (al massimo la abbassano); telefonate e chiamate VoIP la mettono in pausa e a fine chiamata riparte.

## Audio
- Menu ⋮ → Audio e qualità.
- Qualità: Automatica (massima su Wi-Fi, media ~128 kbps su dati), Alta ~160 kbps, Bilanciata ~70 kbps Opus (~30 MB/ora), Risparmio ~50 kbps.
- Profilo sonoro: Naturale, Auto (bassi e alti più presenti + compressione per volume uniforme), Bassi potenti.

## Riproduzione automatica
- Alla fine di un video continua con video simili (come YouTube); nelle code musicali aggiunge brani simili.
- Si disattiva da ⋮ → Audio e qualità → Riproduzione automatica.

## ✨ Il mio mix
- Composto in automatico da preferiti, canzoni degli artisti seguiti, brani simili (radio dei preferiti) e più ascoltati; nessun doppione
- Voce: "Ok Google, riproduci il mio mix su Tubetto"
  (riconosce la stessa canzone anche da video diversi). Salvabile in "Le mie playlist". Anche in Android Auto.

## Fluidità
- Buffer fino a 2 minuti avanti (30 s indietro); il brano successivo si carica in anticipo.
- Video in DASH adattivo: parte in qualità bassa per avviarsi subito, poi sale; scende da sola se la rete rallenta.
- Video: qualità massima piena su Wi-Fi, 720p su dati mobili.
- Cambio brano/video: quello attuale si ferma subito; i link già risolti restano in cache 20 minuti.

## Per te
- La home mostra brani/video simili a quelli ascoltati più spesso e di recente (cronologia salvata sul telefono).
- Nelle code musicali, quando restano 2 brani, si aggiungono da soli brani simili (radio).

## Telefono, tablet e Fire TV (adattamento automatico)
- Telefono: lista a 1 colonna (2 in orizzontale). Tablet: griglia a 2–3 colonne, testi e miniature più grandi.
- Fire TV / Android TV: barra laterale a sinistra con ricerca, modalità, libreria e menu; a destra griglia a tutta altezza con card grandi, navigazione col telecomando (card evidenziata e
  ingrandita), margini anti-overscan, video subito a schermo intero, tasto ≡ = opzioni dell'elemento.
- Riga "In riproduzione": titolo, artista, visualizzazioni, data, durata e brano successivo (su TV anche descrizione, accanto all'anteprima).
- Su TV il video si vede in anteprima piccola in alto: OK = schermo intero con comandi, Indietro = torna piccola.
- Su TV le code musicali (Musica, playlist, Il mio mix) suonano come videoclip in piena qualità; niente screensaver durante la riproduzione.
- Su TV la ricezione dal telefono è nel menu ⋮ → "📺 Ricevi dal telefono".

## Fire TV e Home Assistant
- Installa lo stesso APK sulla Fire TV: si apre in **modalità ricevitore** (renderer DLNA, porta 49494).
- Dal telefono compare con ★: riceve il link YouTube e lo risolve da sola in piena qualità.
- Home Assistant lo trova con l'integrazione **DLNA Digital Media Renderer**: play/pausa/stop/volume
  e `media_player.play_media` con un link YouTube.
- Il ricevitore resta attivo finché Tubetto è aperto sulla TV.

## TV (DLNA)
- Icona trasmetti in alto o tieni premuto un video → "Trasmetti su TV".
- Fire TV: installa Kodi e abilita il controllo remoto UPnP; TV smart con DLNA compaiono direttamente.
- Il telefono fa da proxy: durante la trasmissione resta attivo un servizio con notifica "In onda su …"
  (Wi-Fi e CPU tenuti svegli). Se YouTube interrompe il link, il proxy lo rinnova e riprende dallo stesso punto.
- Consigliato: Impostazioni Android → App → Tubetto → Batteria → "Senza restrizioni".

## Architettura
- `data/YouTubeApiHelper` — POST a /youtubei/v1/{search,browse,player} con INNERTUBE_CONTEXT.
- `data/StreamParser` — parsing di search/browse e streamingData.adaptiveFormats.
- `data/StreamResolver` — InnerTube diretto, fallback NewPipeExtractor (signature/n-param).
- `playback/YouTubeMediaSourceFactory` — MergingMediaSource video-only + audio-only.
- `playback/PlaybackService` — MediaLibraryService: foreground + notifica + Android Auto.
- `update/Updater` — release GitHub -> download -> installer di sistema.
- `cast/Dlna` + `cast/StreamProxy` — SSDP/SOAP AVTransport e proxy HTTP locale con Range.

## Manutenzione
- Client InnerTube (versioni, User-Agent, ordine): `data/Clients.kt`.
- Se tutti danno 403: aggiorna NewPipeExtractor in `app/build.gradle.kts`.
- Tasto **Log** nell'app: mostra quale sorgente funziona e quale fallisce (HTTP, client c=).
